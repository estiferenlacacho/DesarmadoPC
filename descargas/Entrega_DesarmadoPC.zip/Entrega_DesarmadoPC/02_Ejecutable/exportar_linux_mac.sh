#!/bin/sh
# ============================================================
# Exporta DesarmadoPC como aplicación (Linux o macOS)
# Requiere Processing 4 y la librería "Video Library for Processing 4".
# Uso: sh exportar_linux_mac.sh [variante]
#   variantes: linux-amd64, linux-aarch64, macos-x86_64, macos-aarch64
# processing-java debe estar en el PATH
# (macOS: Processing > Herramientas > Instalar "processing-java").
# ============================================================
DIR=$(cd "$(dirname "$0")" && pwd)
VARIANTE=${1:-linux-amd64}
processing-java --sketch="$DIR/../01_Codigo_Fuente/DesarmadoPC" \
  --output="$DIR/$VARIANTE" --variant="$VARIANTE" --force --export \
  && echo "Listo: $DIR/$VARIANTE"
