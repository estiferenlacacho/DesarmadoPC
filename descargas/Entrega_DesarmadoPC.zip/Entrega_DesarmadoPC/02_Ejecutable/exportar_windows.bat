@echo off
REM ============================================================
REM Exporta DesarmadoPC como aplicación de Windows (64 bits)
REM Requiere Processing 4 y la librería "Video Library for Processing 4".
REM Uso: doble clic, o desde CMD:  exportar_windows.bat "C:\ruta\a\processing-4.x"
REM ============================================================
setlocal
set PROC=%~1
if "%PROC%"=="" set PROC=C:\processing-4.3
set SKETCH=%~dp0..\01_Codigo_Fuente\DesarmadoPC
set SALIDA=%~dp0windows-amd64
"%PROC%\processing-java.exe" --sketch="%SKETCH%" --output="%SALIDA%" --variant=windows-amd64 --force --export
if errorlevel 1 (
  echo No se pudo exportar. Revisa la ruta de Processing y que la libreria Video este instalada.
  pause
  exit /b 1
)
echo Listo: %SALIDA%\DesarmadoPC.exe
pause
