// ============================================================
// RTX · VÉRTICES
// Pasa al fragmento la posición, la normal y los materiales de cada vértice
// para que la luz se calcule en cada píxel (no solo en las esquinas).
// ============================================================

uniform mat4 modelviewMatrix;
uniform mat4 transformMatrix;
uniform mat3 normalMatrix;
uniform mat4 texMatrix;

attribute vec4 position;
attribute vec4 color;
attribute vec3 normal;
attribute vec2 texCoord;
attribute vec4 ambient;
attribute vec4 specular;
attribute vec4 emissive;
attribute float shininess;

varying vec4 vColor;
varying vec4 vAmbient;
varying vec4 vSpecular;
varying vec4 vEmissive;
varying float vShininess;
varying vec3 vPos;
varying vec3 vNormal;
varying vec4 vTexCoord;

void main() {
  // @posición en pantalla y en el espacio de la cámara
  gl_Position = transformMatrix * position;
  vPos = vec3(modelviewMatrix * position);
  vNormal = normalize(normalMatrix * normal);
  vTexCoord = texMatrix * vec4(texCoord, 1.0, 1.0);
  // materiales: color (tint), ambiental (fill), especular y brillo
  vColor = color;
  vAmbient = ambient;
  vSpecular = specular;
  vEmissive = emissive;
  vShininess = shininess;
}
