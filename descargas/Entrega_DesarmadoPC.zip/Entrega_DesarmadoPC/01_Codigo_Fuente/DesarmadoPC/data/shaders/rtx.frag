// ============================================================
// RTX · FRAGMENTOS
// Iluminación por píxel estilo "RTX": difusa y especular (Blinn-Phong) de cada
// luz de Processing, rebote de luz del cielo y de la mesa (hemisférica),
// reflejo en los bordes (Fresnel) y mapeo de tonos filmico (ACES).
// Las pantallas y los LEDs NO pasan por aquí: se dibujan sin luces.
// ============================================================

#ifdef GL_ES
precision mediump float;
precision mediump int;
#endif

#define PROCESSING_TEXLIGHT_SHADER

uniform sampler2D texture;

uniform int lightCount;
uniform vec4 lightPosition[8];
uniform vec3 lightNormal[8];
uniform vec3 lightAmbient[8];
uniform vec3 lightDiffuse[8];
uniform vec3 lightFalloff[8];
uniform vec2 lightSpot[8];

uniform vec3 arriba;           // dirección "arriba" del mundo, vista desde la cámara
uniform vec3 colorCielo;       // luz que rebota desde arriba
uniform vec3 colorSuelo;       // luz que rebota desde la mesa (madera)
uniform float fuerzaRebote;
uniform float fuerzaEspecular;
uniform float fuerzaFresnel;
uniform float exposicion;

varying vec4 vColor;
varying vec4 vAmbient;
varying vec4 vSpecular;
varying vec4 vEmissive;
varying float vShininess;
varying vec3 vPos;
varying vec3 vNormal;
varying vec4 vTexCoord;

// @atenuación por distancia (igual que lightFalloff de Processing)
float atenuacion(vec3 posLuz, vec3 coef) {
  vec3 d = posLuz - vPos;
  float d2 = dot(d, d);
  return 1.0 / (coef.x + coef.y * sqrt(d2) + coef.z * d2);
}

// @cono suave de los focos (spotLight)
float cono(vec3 posLuz, vec3 eje, float cosMin, float concentracion) {
  vec3 l = normalize(posLuz - vPos);
  float c = dot(-eje, l);
  float borde = smoothstep(cosMin, cosMin + 0.04, c);
  return borde * pow(max(c, 0.0), concentracion);
}

// @mapeo de tonos ACES: luces altas suaves, sombras con detalle
vec3 aces(vec3 x) {
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
  vec4 tex = texture2D(texture, vTexCoord.st);
  vec3 albedo = tex.rgb * vColor.rgb;
  vec3 N = normalize(vNormal);
  if (!gl_FrontFacing)
    N = -N;
  vec3 V = normalize(-vPos);

  vec3 ambiente = vec3(0.0);
  vec3 difusa = vec3(0.0);
  vec3 especular = vec3(0.0);
  float brillo = max(vShininess, 1.0);

  // @recorrido de las luces de Processing (ambientLight, directionalLight, pointLight, spotLight)
  for (int i = 0; i < 8; i++) {
    if (i >= lightCount)
      break;
    bool direccional = lightPosition[i].w < 1.0;
    vec3 L;
    float f = 1.0;
    if (direccional) {
      L = -normalize(lightNormal[i]);
    } else {
      L = normalize(lightPosition[i].xyz - vPos);
      f = atenuacion(lightPosition[i].xyz, lightFalloff[i]);
    }
    if (lightSpot[i].y > 0.0)
      f *= cono(lightPosition[i].xyz, normalize(lightNormal[i]), lightSpot[i].x, lightSpot[i].y);
    ambiente += lightAmbient[i] * f;
    float nl = max(dot(N, L), 0.0);
    difusa += lightDiffuse[i] * f * nl;
    vec3 H = normalize(L + V);
    float s = pow(max(dot(N, H), 0.0), brillo) * step(0.0001, nl);
    especular += lightDiffuse[i] * f * s * (brillo + 8.0) / 64.0;
  }

  // @rebote de luz (iluminación global aproximada): cielo arriba, mesa abajo
  float hemi = 0.5 + 0.5 * dot(N, normalize(arriba));
  vec3 rebote = mix(colorSuelo, colorCielo, hemi) * fuerzaRebote;

  // @reflejo en los bordes (Fresnel de Schlick) con el color del entorno
  vec3 R = reflect(-V, N);
  float entorno = 0.5 + 0.5 * dot(R, normalize(arriba));
  float fres = pow(1.0 - max(dot(N, V), 0.0), 5.0);
  float metal = clamp(dot(vSpecular.rgb, vec3(0.333)), 0.0, 1.0);
  vec3 reflejo = mix(colorSuelo, colorCielo, entorno) * fres * fuerzaFresnel * (0.25 + metal);

  vec3 luz = albedo * (ambiente * vAmbient.rgb / max(vColor.rgb, vec3(0.004)) + difusa + rebote)
           + especular * vSpecular.rgb * fuerzaEspecular
           + reflejo
           + vEmissive.rgb * tex.rgb;
  gl_FragColor = vec4(aces(luz * exposicion), tex.a * vColor.a);
}
