// ============================================================
// CÁMARA 3D · órbita suave y rayo del mouse
// ============================================================

// @class Camara3D · Cámara en órbita con movimiento suave (los valores se acercan a su meta en cada cuadro)
class Camara3D {
  float yaw = 0.5, pitch = 0.75, dist = 700;
  float tx = 0, th = 30, tz = 0;
  float yawM, pitchM, distM, txM, thM, tzM;
  float fov = PI / 3.3;
  float ex, eh, ez;

  Camara3D() {
    yawM = yaw;
    pitchM = pitch;
    distM = dist;
  }

  // enfocar(x, h, z, d) · Nueva meta: centro (x, h, z) a distancia d
  void enfocar(float x, float h, float z, float d) {
    txM = x;
    thM = h;
    tzM = z;
    distM = d;
  }

  // vista(yaw, pitch, dist, x, h, z) · Nueva meta completa: ángulos, distancia y centro
  void vista(float yaw, float pitch, float dist, float x, float h, float z) {
    yawM = yaw;
    pitchM = pitch;
    distM = dist;
    txM = x;
    thM = h;
    tzM = z;
  }

  // girar(dx, dy) · Gira la órbita según el arrastre del mouse
  void girar(float dx, float dy) {
    yawM -= dx * 0.008;
    pitchM = constrain(pitchM + dy * 0.008, -0.15, 1.5);
  }

  // desplazar(dx, dy) · Mueve el centro de la órbita en el plano de la pantalla
  void desplazar(float dx, float dy) {
    float k = dist / 900.0;
    txM -= cos(yaw) * dx * k;
    tzM += sin(yaw) * dx * k;
    thM += dy * k;
  }

  // zoom(pasos) · Acerca o aleja (limitado entre 120 y 2600 mm)
  void zoom(float pasos) {
    distM = constrain(distM * (1 + pasos * 0.1), 120, 2600);
  }

  // @aplicar() · Suaviza hacia la meta y coloca la cámara con camera() y perspective()
  void aplicar() {
    yaw = lerp(yaw, yawM, 0.15);
    pitch = lerp(pitch, pitchM, 0.15);
    dist = lerp(dist, distM, 0.15);
    tx = lerp(tx, txM, 0.12);
    th = lerp(th, thM, 0.12);
    tz = lerp(tz, tzM, 0.12);
    ex = tx + sin(yaw) * cos(pitch) * dist;
    ez = tz + cos(yaw) * cos(pitch) * dist;
    eh = max(th + sin(pitch) * dist, 15);
    camera(ex, -eh, ez, tx, -th, tz, 0, 1, 0);
    perspective(fov, width / (float) height, 5, 20000);
  }

  // @rayo(mx, my) · Rayo del mouse en el mundo {x, h, z, dx, dh, dz} para saber qué hay bajo el cursor
  float[] rayo(float mx, float my) {
    PVector e = new PVector(ex, -eh, ez), cc = new PVector(tx, -th, tz);
    PVector f = PVector.sub(cc, e);
    f.normalize();
    PVector up = new PVector(0, 1, 0);
    PVector u = PVector.sub(up, PVector.mult(f, up.dot(f)));
    u.normalize();
    PVector r = f.cross(u);
    float t = tan(fov / 2);
    float nx = (mx - width / 2.0) / (height / 2.0) * t, ny = (my - height / 2.0) / (height / 2.0) * t;
    PVector d = PVector.add(f, PVector.add(PVector.mult(r, nx), PVector.mult(u, ny)));
    d.normalize();
    return new float[] {ex, eh, ez, d.x, -d.y, d.z};
  }
}
