// ============================================================
// MODELOS 3D · primitivas, piezas, laptops, gabinetes, monitor, tornillos y cables
// ============================================================

// ---- Tipos de pieza ----
final static int T_NINGUNO = 0;
final static int T_TAPA_LAPTOP = 1;
final static int T_BATERIA = 2;
final static int T_RAM_SODIMM = 3;
final static int T_M2 = 4;
final static int T_WIFI = 5;
final static int T_DISIPADOR_LAPTOP = 6;
final static int T_CPU = 7;
final static int T_BOCINA = 8;
final static int T_CMOS = 9;
final static int T_PLACA_LAPTOP = 10;
final static int T_PANEL = 11;
final static int T_GPU = 12;
final static int T_RAM_DIMM = 13;
final static int T_COOLER = 14;
final static int T_HDD = 15;
final static int T_VENTILADOR = 16;
final static int T_PSU = 17;
final static int T_PLACA_ATX = 18;
final static int T_HDD25 = 19;
final static int T_OPTICO = 20;
final static int T_RADIADOR = 21;

float giroAspas = 0;

// ---- Primitivas ----
// @c(x, h, z, w, a, d) · Caja centrada con grano teñido del color de relleno (primitiva base)
void c(float x, float h, float z, float w, float a, float d) {
  cajaRep(x, h, z, w, a, d, g.fillColor, texGrano, 60);
}

// c(x, h, z, w, a, d, col) · Igual que c() pero con color
void c(float x, float h, float z, float w, float a, float d, color col) {
  fill(col);
  c(x, h, z, w, a, d);
}

// @cilindro(x, h, z, r, largo, eje, lados, col) · Cilindro con normales y textura (recibe brillo RTX)
void cilindro(float x, float h, float z, float r, float largo, int eje, int lados, color col) {
  // con textura de grano y normales: así el modo RTX le da brillo metálico
  fill(col);
  tint(col);
  specular(120);
  shininess(30);
  textureMode(NORMAL);
  pushMatrix();
  translate(x, -h, z);
  if (eje == 0)
    rotateZ(HALF_PI);
  else if (eje == 2)
    rotateX(HALF_PI);
  beginShape(QUAD_STRIP);
  texture(texGrano);
  for (int i = 0; i <= lados; i++) {
    float a = TWO_PI * i / lados;
    normal(cos(a), 0, sin(a));
    vertex(cos(a) * r, -largo / 2, sin(a) * r, i / (float) lados, 0);
    vertex(cos(a) * r, largo / 2, sin(a) * r, i / (float) lados, 1);
  }
  endShape();
  for (int s = -1; s <= 1; s += 2) {
    beginShape(TRIANGLE_FAN);
    texture(texGrano);
    normal(0, s, 0);
    vertex(0, s * largo / 2, 0, 0.5, 0.5);
    for (int i = 0; i <= lados; i++) {
      float a = TWO_PI * i / lados;
      vertex(cos(a) * r, s * largo / 2, sin(a) * r, 0.5 + cos(a) * 0.5, 0.5 + sin(a) * 0.5);
    }
    endShape();
  }
  popMatrix();
  noTint();
}

// aspas(x, h, z, r, eje, n, col, gira) · Aspas curvas de ventilador (con desenfoque al girar)
void aspas(float x, float h, float z, float r, int eje, int n, color col, boolean gira) {
  pushMatrix();
  translate(x, -h, z);
  if (eje == 0)
    rotateZ(HALF_PI);
  else if (eje == 2)
    rotateX(HALF_PI);
  rotateY(gira ? giroAspas : 0.3);
  noStroke();
  fill(red(col), green(col), blue(col), gira ? 150 : 255);
  for (int i = 0; i < n; i++) {
    pushMatrix();
    rotateY(TWO_PI * i / n);
    beginShape(QUAD_STRIP);
    for (int k = 0; k <= 6; k++) {
      float t = k / 6.0, rr = lerp(r * 0.27, r * 0.97, t);
      float a0 = t * 0.55, a1 = a0 + lerp(0.5, 0.32, t) * 7.0 / n;
      float tor = lerp(0.6, 0.25, t);
      vertex(cos(a0) * rr, -tor, sin(a0) * rr);
      vertex(cos(a1) * rr, tor, sin(a1) * rr);
    }
    endShape();
    popMatrix();
  }
  if (gira) {
    fill(red(col), green(col), blue(col), 70);
    beginShape(TRIANGLE_FAN);
    vertex(0, 0, 0);
    for (int i = 0; i <= 32; i++)
      vertex(cos(TWO_PI * i / 32) * r * 0.96, 0, sin(TWO_PI * i / 32) * r * 0.96);
    endShape();
  }
  popMatrix();
  cilindro(x, h, z, r * 0.27, 2.4, eje, 24, color(22, 23, 26));
}

// chips(w, d, h, n, semilla, lado) · Componentes pequeños al azar sobre una placa
void chips(float w, float d, float h, int n, int semilla, float lado) {
  randomSeed(semilla);
  for (int i = 0; i < n; i++) {
    float cw = random(4, 14), cd = random(4, 12);
    float x = random(-w / 2 + cw, w / 2 - cw), z = random(-d / 2 + cd, d / 2 - cd);
    boolean negro = random(1) < 0.75;
    if (negro)
      cajaT(x, h + lado * 0.8, z, cw, 1.4, cd, color(25, 25, 30), texChip, lado < 0 ? -1 : 1);
    else
      c(x, h + lado * 0.8, z, cw, 1.4, cd, color(150, 120, 60));
  }
}

// pegatina(x, h, z, w, a, d, tex, cara) · Etiqueta con textura sobre una cara
void pegatina(float x, float h, float z, float w, float a, float d, PImage tex, int cara) {
  cajaT(x, h, z, w, a, d, color(225), tex, cara);
}

// ---- Piezas ----
// @dibujarPieza(p, e) · Dibuja una pieza en su lugar según su tipo, su variante y el modelo
void dibujarPieza(Pieza p, Equipo e) {
  noStroke();
  Modelo m = e.modelo;
  float w = p.w, a = p.alto, d = p.d;
  switch (p.tipo) {
  case T_TAPA_LAPTOP:
    cajaT(0, 0, 0, w, a, d, m.chasis, m.texFondo, -1);
    if (m.estilo == 0 || m.estilo == 3)
      for (int i = 0; i < 2; i++)
        c(0, -a / 2 - (m.estilo == 3 ? 2 : 1), (i == 0 ? -1 : 1) * d * 0.43, w * 0.76, m.estilo == 3 ? 4 : 2, m.estilo == 3 ? 12 : 8, color(20, 20, 22));
    else if (m.estilo == 1)
      for (int i = 0; i < 2; i++)
        c(0, -a / 2 - 0.7, (i == 0 ? -1 : 1) * d * 0.4, w * 0.82, 1.4, 4, color(150, 152, 156));
    else
      for (int i = -1; i <= 1; i += 2)
        for (int j = -1; j <= 1; j += 2)
          c(i * (w / 2 - 22), -a / 2 - 1.5, j * (d / 2 - 18), 26, 3, 14, color(18));
    break;
  case T_BATERIA:
    cajaRep(0, 0, 0, w, a, d, color(42, 44, 50), texGrano, 40);
    for (int i = -1; i <= 1; i++)
      c(i * w / 3, -a / 2 - 0.1, 0, 1, 0.3, d - 6, color(60, 62, 70));
    pegatina(-w * 0.15, -a / 2 - 0.2, 0, min(132, w * 0.55), 0.4, min(43, d * 0.6), texEtqBateria, -1);
    c(0, 0, -d / 2 - 2, 20, 2, 4, color(200, 60, 50));
    break;
  case T_RAM_SODIMM:
    cajaT(0, 0, 0, w, a, d, color(20, 90, 55), texSodimm, -1, 0, 1, 1, 0);
    for (int i = 0; i < 4; i++) {
      cajaT(-24 + i * 16, -a / 2 - 0.6, 3, 11, 1.2, 10, color(25), texChip, -1);
      cajaT(-24 + i * 16, a / 2 + 0.6, 3, 11, 1.2, 10, color(25), texChip, 1);
    }
    pegatina(10, -a / 2 - 1.35, 3, 46, 0.3, 12, texEtqRam, -1);
    break;
  case T_M2:
    if (p.d < p.alto) {
      cajaT(0, 0, 0, w, a, d, color(20, 22, 26), texM2, 2);
      cajaT(-20, 0, 1.5, 18, 16, 1.2, color(30), texChip, 2);
      pegatina(15, 0, 1.6, 38, 18, 1, texEtqSSD, 2);
    } else {
      cajaT(0, 0, 0, w, a, d, color(20, 22, 26), texM2, -1, 1, 0, 0, 1);
      cajaT(-20, -a / 2 - 0.6, 0, 16, 1.2, 14, color(30), texChip, -1);
      pegatina(12, -a / 2 - 0.4, 0, 40, 0.5, d - 4, texEtqSSD, -1);
    }
    break;
  case T_WIFI:
    cajaT(0, 0, 0, w, a, d, color(25, 80, 55), texWifi, -1);
    cajaRep(-2, -a / 2 - 0.8, 0, w - 10, 1.6, d - 6, color(200, 203, 210), texCepillado, 30);
    c(w / 2 - 2, 0, 0, 4, a + 0.1, d - 4, color(220, 180, 70));
    break;
  case T_DISIPADOR_LAPTOP:
    cajaRep(-87.5, -1.5, 10, 46, 2.5, 44, color(255), texCobre, 46);
    if (p.variante == 2) {
      cilindro(-35, -2, 9, 2.2, 110, 0, 16, color(205, 125, 80));
      for (int i = 0; i < 14; i++)
        cajaRep(12 + i * 1.2, 0, -10, 0.4, 5.5, 40, color(230), texCepillado, 50);
      cajaRep(55, 0.3, 0, 46, 6, 48, color(30, 31, 35), texGrano, 40);
      cilindro(55, -2.8, 0, 17, 0.5, 1, 28, color(20, 21, 24));
      aspas(55, -2.8, 0, 16, 1, 11, color(45, 46, 52), e.encendido);
    } else {
      cilindro(-20, -2, 6, 2.6, 140, 0, 16, color(205, 125, 80));
      cilindro(-20, -2, 12, 2.6, 140, 0, 16, color(195, 118, 74));
      for (int i = 0; i < 18; i++)
        cajaRep(28 + i * 1.3, 0, -10, 0.45, 7, 46, color(230), texCepillado, 50);
      cajaRep(80, 0.5, 0, 62, 7.5, 64, color(30, 31, 35), texGrano, 40);
      cilindro(80, -3.6, 0, 23, 0.6, 1, 32, color(20, 21, 24));
      aspas(80, -3.6, 0, 22, 1, 13, color(45, 46, 52), e.encendido);
      if (p.variante == 1) {
        cilindro(-150, -2, 14, 2.6, 110, 0, 16, color(205, 125, 80));
        for (int i = 0; i < 14; i++)
          cajaRep(-205 + i * 1.3, 0, -6, 0.45, 7, 46, color(230), texCepillado, 50);
        cajaRep(-140, 0.5, -10, 62, 7.5, 64, color(30, 31, 35), texGrano, 40);
        cilindro(-140, -3.6, -10, 23, 0.6, 1, 32, color(20, 21, 24));
        aspas(-140, -3.6, -10, 22, 1, 13, color(45, 46, 52), e.encendido);
        c(-60, -1.5, -18, 40, 2.5, 30, color(205, 125, 80));
      }
    }
    break;
  case T_CPU:
    if (p.w < 35) {
      cajaRep(0, 0, 0, w, a, d, color(30, 90, 50), texGrano, 30);
      c(0, -a / 2 - 0.4, 0, 14, 0.8, 12, color(48, 52, 62));
    } else {
      cajaRep(0, 0, 0, w, a, d, color(30, 100, 55), texGrano, 30);
      cajaT(0, 0, d / 2 + 0.75, 33, 33, 1.5, color(200, 202, 208), texIHS, 2);
    }
    dibujarPasta(p, e);
    break;
  case T_BOCINA:
    cajaRep(0, 0, 0, w, a, d, color(30, 31, 35), texGrano, 30);
    cajaT(0, -a / 2 - 0.15, 0, w - 4, 0.3, d - 4, color(60), texMalla, -1, 0, 0, (w - 4) / 20, (d - 4) / 20);
    break;
  case T_CMOS:
    if (p.alto < p.w) {
      cilindro(0, 0, 0, w / 2, a, 1, 32, color(205, 208, 214));
      c(0, -a / 2 - 0.1, 0, 6, 0.3, 1.2, color(80));
      c(0, -a / 2 - 0.1, 0, 1.2, 0.3, 6, color(80));
    } else {
      cilindro(0, 0, 0, w / 2, d, 2, 32, color(205, 208, 214));
      c(0, 0, d / 2 + 0.1, 6, 1.2, 0.3, color(80));
      c(0, 0, d / 2 + 0.1, 1.2, 6, 0.3, color(80));
    }
    break;
  case T_PLACA_LAPTOP:
    dibujarPlacaLaptop(p, e);
    break;
  case T_PANEL:
    break;
  case T_GPU: {
    int n = max(1, p.variante);
    color cuerpo = m.estilo == 3 ? color(70, 72, 80) : color(38, 40, 46);
    color acento = m.estilo == 3 ? color(235) : (m.estilo == 2 ? color(255, 170, 90) : color(0, 200, 170));
    cajaRep(0, 0, 0, w, a, d, cuerpo, texGrano, 50);
    cajaRep(0, a / 2 + 0.8, 0, w - 10, 1.6, d - 4, color(70, 72, 80), texCepillado, 120);
    pegatina(10, 0, d / 2 + 0.2, min(w - 40, 260), 6, 0.6, texEtqGPU, 2);
    c(-w * 0.2, a * 0.3, d / 2 + 0.3, w * 0.23, 1.2, 0.4, acento);
    c(w * 0.27, -a * 0.3, d / 2 + 0.3, w * 0.23, 1.2, 0.4, acento);
    float r = min(45, (w - 40) / (2.0 * n) - 3);
    for (int i = 0; i < n; i++) {
      float fx = n == 1 ? 10 : lerp(-w / 2 + 22 + r, w / 2 - 22 - r, i / (float) (n - 1));
      cilindro(fx, -a / 2 - 0.4, 0, r + 3, 0.8, 1, 40, color(18, 19, 22));
      aspas(fx, -a / 2 - 1.5, 0, r, 1, 11, color(50, 52, 58), e.encendido);
    }
    cajaRep(-w / 2 + 2, 0, -6, 4, a + 4, d + 8, color(200, 202, 208), texCepillado, 40);
    c(-w / 2 - 2, 4, -20, 3, 10, 14, color(30));
    c(-w / 2 - 2, -8, 10, 3, 8, 16, color(30));
    c(w / 2 - 45, a / 2 - 4, d / 2 - 3, 22, 9, 6, color(20));
    c(-w / 2 + 90, a / 2 + 1, -d / 2 + 4, min(150, w - 60), 1, 6, color(220, 180, 70));
    break;
  }
  case T_RAM_DIMM:
    cajaT(0, 0, 0, w, a, d, color(20, 90, 55), texDimm, 3);
    color dis = m.estilo == 3 ? color(60, 62, 70) : (m.estilo == 1 ? color(20, 90, 55) : color(185, 40, 48));
    if (m.estilo != 1) {
      cajaRep(-1.6, 0, 3, 1.2, a - 6, d - 6, dis, texCepillado, 60);
      cajaRep(1.6, 0, 3, 1.2, a - 6, d - 6, dis, texCepillado, 60);
      cajaT(2.3, 0, 4, 0.3, 60, 16, color(225), texEtqRamD, 3);
    } else
      for (int i = 0; i < 4; i++)
        cajaT(1.4, -45 + i * 30, 3, 1.2, 18, 12, color(25), texChip, 3);
    c(0, 0, d / 2 - 1, 4, a - 2, 2, color(30));
    break;
  case T_COOLER:
    if (p.variante == 1)
      dibujarCoolerFabrica(p, e);
    else if (p.variante == 2)
      dibujarBomba(p, e);
    else {
      cajaRep(12.5, 0, -66, 50, 50, 16, color(255), texCobre, 50);
      for (int i = 0; i < 4; i++)
        cilindro(-10 + i * 16, 0, -10, 3.2, 110, 1, 16, color(205, 128, 82));
      for (int i = 0; i < 26; i++)
        cajaRep(12.5, -56 + i * 4.5, 10, 110, 0.8, 140, color(235), texCepillado, 140);
      cajaRep(12.5, 60, 10, 112, 3, 142, color(32, 33, 38), texCepillado, 140);
      for (int i = 0; i < 4; i++)
        cilindro(-10 + i * 16, 62, -10, 3.4, 2, 1, 16, color(190, 192, 198));
      c(-55, 0, 10, 25, 124, 124, color(25, 25, 30));
      cilindro(-55, 0, 10, 57, 26, 0, 40, color(40, 41, 46));
      aspas(-68.5, 0, 10, 54, 0, 9, color(95, 96, 106), e.encendido && cooler_conectado(e));
    }
    break;
  case T_RADIADOR:
    dibujarRadiador(p, e);
    break;
  case T_HDD:
    cajaRep(0, 3, 0, w, a - 6, d, color(205, 208, 214), texCepillado, 160);
    cajaT(0, -a / 2 + 3, 0, w - 4, 6, d - 2, color(30, 70, 50), texPlacaATX, -1, 0, 0, 0.3, 0.2);
    pegatina(5, 3 + (a - 6) / 2 + 0.15, 0, 112, 0.3, 80, texEtqHDD, 1);
    break;
  case T_HDD25:
    cajaRep(0, 0, 0, w, a, d, color(150, 153, 160), texCepillado, 80);
    pegatina(0, -a / 2 - 0.2, 0, w - 16, 0.4, d - 14, texEtqSSD25, -1);
    c(-w / 2 - 1.5, 0, 0, 3, a - 1, d - 10, color(30));
    for (int s = -1; s <= 1; s += 2)
      c(0, 0, s * (d / 2 + 1), w + 6, a + 1, 2, color(90, 92, 98));
    break;
  case T_OPTICO:
    cajaRep(0, 0, 0, w, a, d, color(46, 47, 52), texGrano, 50);
    pegatina(-10, a / 2 + 0.2, 0, 96, 0.4, 70, texEtqDVD, 1);
    cajaRep(w / 2 + 4, 0, 0, 8, a + 2, d + 2, color(28, 29, 32), texGrano, 40);
    c(w / 2 + 8.2, 3, 0, 0.6, 1.2, d - 20, color(12));
    c(w / 2 + 8.2, -10, d / 2 - 20, 0.8, 4, 14, color(60));
    c(w / 2 + 8.2, -10, -d / 2 + 30, 0.6, 2, 2, e.encendido ? color(80, 255, 120) : color(30));
    break;
  case T_VENTILADOR:
    c(0, 0, a / 2 - 3, w, a, 6, color(28));
    c(0, 0, -a / 2 + 3, w, a, 6, color(28));
    c(0, a / 2 - 3, 0, w, 6, a, color(28));
    c(0, -a / 2 + 3, 0, w, 6, a, color(28));
    aspas(0, 0, 0, 54, 0, 9, m.estilo == 2 ? color(140, 110, 80) : (m.estilo == 3 ? color(60) : color(80, 140, 220)), e.encendido && conectado(e, p.id));
    break;
  case T_PSU: {
    float r = min(w, d) * 0.39;
    cajaRep(0, 0, 0, w, a, d, color(34, 35, 40), texGrano, 50);
    cilindro(0, -a / 2 - 0.3, 0, r, 0.6, 1, 40, color(18));
    aspas(0, -a / 2 - 1.5, 0, r * 0.9, 1, 9, color(45), e.encendido);
    cajaT(0, -a / 2 - 2.2, 0, r * 2.06, 0.6, r * 2.06, color(60), texMalla, -1, 0, 0, 4, 4);
    pegatina(-w * 0.06, 5, d / 2 + 0.2, w * 0.62, a * 0.65, 0.4, texEtqPSU, 2);
    c(-w / 2 - 0.5, a * 0.23, d * 0.2, 1, a * 0.3, 30, color(20));
    c(-w / 2 - 0.5, -a * 0.12, -d * 0.27, 1, 14, 22, color(200, 40, 40));
    break;
  }
  case T_PLACA_ATX:
    dibujarPlacaATX(p, e);
    break;
  }
}

// ---- Enfriamiento de escritorio ----
// dibujarCoolerFabrica(p, e) · Disipador de fábrica de la PC
void dibujarCoolerFabrica(Pieza p, Equipo e) {
  float d = p.d;
  cilindro(0, 0, -d / 2 + 13, 15, 26, 2, 24, color(205, 125, 80));
  fill(190, 193, 200);
  for (int i = 0; i < 28; i++) {
    pushMatrix();
    rotateZ(TWO_PI * i / 28);
    c(29, 0, -d / 2 + 15, 30, 1.1, 28);
    popMatrix();
  }
  cilindro(0, 0, d / 2 - 9, 47, 6, 2, 40, color(28, 29, 32));
  aspas(0, 0, d / 2 - 5, 42, 2, 7, color(45, 46, 50), e.encendido && cooler_conectado(e));
  cilindro(0, 0, d / 2 - 2, 13, 1, 2, 24, color(150, 152, 158));
  for (int i = -1; i <= 1; i += 2)
    for (int j = -1; j <= 1; j += 2)
      cilindro(i * 37, j * 37, -d / 2 + 8, 4, 16, 2, 12, color(25));
}

// dibujarBomba(p, e) · Bomba del enfriamiento líquido
void dibujarBomba(Pieza p, Equipo e) {
  float d = p.d;
  cajaRep(0, 0, 0, p.w, p.alto, d, color(26, 27, 30), texGrano, 40);
  cilindro(0, 0, d / 2 + 1, 26, 4, 2, 40, color(55, 57, 64));
  cilindro(0, 0, d / 2 + 3.2, 20, 0.6, 2, 40, color(235));
  cilindro(0, 0, -d / 2 - 1, 22, 2, 2, 32, color(205, 125, 80));
  Pieza rad = e.pieza("radiador");
  boolean unidas = p.instalada && p.enReposo() && rad != null && e.puesta("radiador");
  for (int s = -1; s <= 1; s += 2) {
    float[] a = {s * 12, p.alto / 2 + 2, 4}, b = {s * 12, p.alto / 2 + 40, 26};
    tubo(a, b, 5, color(24));
    if (unidas) {
      float[] c = {rad.x - p.x - 120 + s * 14, rad.h - p.h - 14, rad.z - p.z + 30};
      float[] mid = {lerp(b[0], c[0], 0.4), max(b[1], c[1]) - 10, lerp(b[2], c[2], 0.5) + 30};
      tubo(b, mid, 5, color(24));
      tubo(mid, c, 5, color(24));
    }
    cilindro(s * 12, p.alto / 2 + 1, 4, 6.5, 6, 1, 16, color(150, 152, 158));
  }
}

// dibujarRadiador(p, e) · Radiador con sus ventiladores
void dibujarRadiador(Pieza p, Equipo e) {
  float w = p.w, a = p.alto, d = p.d;
  cajaRep(0, a / 2 - 13, 0, w - 24, 26, d - 12, color(42, 43, 48), texCepillado, 30);
  for (int s = -1; s <= 1; s += 2)
    c(s * (w / 2 - 6), a / 2 - 13, 0, 12, 30, d, color(26));
  for (int s = -1; s <= 1; s += 2) {
    float fx = s * 72;
    c(fx, -a / 2 + 12, d / 2 - 4, 138, 24, 8, color(26));
    c(fx, -a / 2 + 12, -d / 2 + 4, 138, 24, 8, color(26));
    c(fx - 65, -a / 2 + 12, 0, 8, 24, d - 8, color(26));
    c(fx + 65, -a / 2 + 12, 0, 8, 24, d - 8, color(26));
    aspas(fx, -a / 2 + 12, 0, 62, 1, 9, color(55, 56, 62), e.encendido && conectado(e, "radiador"));
  }
  for (int s = -1; s <= 1; s += 2)
    cilindro(-120 + s * 14, a / 2 - 26, 30, 6.5, 6, 1, 16, color(150, 152, 158));
}

// tubo(a, b, r, col) · Tubo recto entre dos puntos (mangueras y cables)
void tubo(float[] a, float[] b, float r, color col) {
  float dx = b[0] - a[0], dy = -(b[1] - a[1]), dz = b[2] - a[2];
  float l = sqrt(dx * dx + dy * dy + dz * dz);
  if (l < 0.01)
    return;
  pushMatrix();
  translate((a[0] + b[0]) / 2, -(a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
  rotateY(atan2(dx, dz));
  rotateX(-asin(constrain(dy / l, -1, 1)));
  fill(col);
  beginShape(QUAD_STRIP);
  for (int i = 0; i <= 12; i++) {
    float t = TWO_PI * i / 12;
    normal(cos(t), sin(t), 0);
    vertex(cos(t) * r, sin(t) * r, -l / 2);
    vertex(cos(t) * r, sin(t) * r, l / 2);
  }
  endShape();
  popMatrix();
}

// conectado(e, duenio) · true si el cable de esa pieza está conectado
boolean conectado(Equipo e, String duenio) {
  for (Conector c : e.conectores)
    if (c.duenio.equals(duenio))
      return c.conectado;
  return false;
}

// cooler_conectado(e) · true si el ventilador del disipador está conectado
boolean cooler_conectado(Equipo e) {
  return conectado(e, "cooler");
}

// dibujarPasta(p, e) · Pasta térmica sobre el procesador según su estado
void dibujarPasta(Pieza p, Equipo e) {
  boolean laptop = p.w < 35;
  float top = -p.alto / 2 - 0.9, frente = p.d / 2 + 1.6;
  if (e.pasta == PASTA_VIEJA) {
    fill(150, 150, 155);
    if (laptop)
      c(0, top, 0, 12, 0.4, 10);
    else
      c(0, 0, frente, 26, 22, 0.6);
  } else if (e.pasta == PASTA_NUEVA && !e.puesta(laptop ? "disipador" : "cooler")) {
    fill(205);
    if (laptop)
      c(0, top - 0.5, 0, 5, 1.2, 5);
    else
      c(0, 0, frente + 0.5, 7, 7, 1.6);
  }
}

// ---- Placas madre ----
// dibujarPlacaLaptop(p, e) · Placa madre de laptop
void dibujarPlacaLaptop(Pieza p, Equipo e) {
  float a = p.alto, sx = e.modelo.W / 340, sz = e.modelo.D / 234;
  cajaT(0, 0, 0, p.w, a, p.d, color(22, 24, 28), texPlacaLaptop, -1);
  chips(p.w, p.d, -a / 2 - 0.2, e.modelo.ramSoldada ? 34 : 26, 7, -1);
  if (e.modelo.ramSoldada)
    for (int i = 0; i < 4; i++)
      cajaT((40 + i * 16) * sx, -a / 2 - 0.7, 12 * sz, 12, 1.2, 14, color(25), texChip, -1);
  else
    c(65 * sx, -4.5, 15 * sz, 74, 7, 5, color(30));
  c(-30 * sx, -1.5, 49.5 * sz, 6, 2, 22, color(30));
  c(10 * sx, -1.5, 57.5 * sz, 6, 2, 22, color(30));
  c(0, -a / 2 - 0.6, -22.5 * sz, 30, 1.2, 26, color(30, 90, 50));
  c(0, -a / 2 - 1.4, -22.5 * sz, 14, 0.8, 12, color(48, 52, 62));
  Pieza cpu = e.pieza("cpu");
  if (cpu != null && !e.puesta("disipador")) {
    pushMatrix();
    translate(0, a / 2 + 0.6, -22.5 * sz);
    dibujarPasta(cpu, e);
    popMatrix();
  }
}

// dibujarPlacaATX(p, e) · Placa madre de escritorio (ATX, mATX o ITX)
void dibujarPlacaATX(Pieza p, Equipo e) {
  float f = p.d / 2, bw = p.w, bh = p.alto;
  boolean itx = p.variante == 2;
  float L = -bw / 2, T = bh / 2;
  cajaT(0, 0, 0, bw, bh, p.d, color(30, 32, 38), texPlacaATX, 2, 0, 0, bw / 244, bh / 305);
  float sx = L + (itx ? 85 : 120), sh = T - (itx ? 70 : 95);
  c(sx, sh, f + 1.5, 52, 52, 3, color(220, 210, 180));
  c(sx, sh, f + 3.2, 40, 40, 0.6, color(170, 145, 75));
  c(sx + 26, sh, f + 2, 2, 46, 2, color(190));
  cajaRep(sx - 60, sh + 62, f + 6, 30, 50, 12, color(95, 98, 108), texCepillado, 50);
  if (!itx)
    cajaRep(sx - 28, sh + 82, f + 6, 70, 18, 12, color(95, 98, 108), texCepillado, 50);
  cajaRep(L + 14, T - 42, f + 10, 26, 70, 20, color(60, 62, 70), texCepillado, 50);
  int slots = itx ? 2 : (p.variante == 1 ? 2 : 4);
  float r0 = itx ? 140 : (slots == 2 ? 185 : 173);
  for (int i = 0; i < slots; i++) {
    float rx = L + r0 + i * 12 - 6 + 6;
    c(rx, T - 92.5 + (itx ? 6 : 0), f + 3, 5, 136, 6, i % 2 == 0 ? color(30) : color(60, 60, 66));
    c(rx, T - 22.5 + (itx ? 6 : 0), f + 4, 5, 6, 7, color(200));
  }
  float slotRy = itx ? 150 : (p.variante == 1 ? 150 : 180);
  cajaRep(L + 60, T - slotRy, f + 3, 90, 7, 6, color(180, 182, 190), texCepillado, 40);
  if (p.variante == 0)
    c(L + 60, T - 237.5, f + 3, 90, 7, 6, color(30));
  if (p.variante == 1)
    c(L + 60, T - 200, f + 3, 60, 7, 6, color(30));
  float m2x = itx ? 45 : 95, m2y = itx ? 112 : (p.variante == 1 ? 215 : 264);
  if (!itx)
    cajaRep(L + m2x, T - m2y, f + 1, 84, 24, 1, color(70, 72, 80), texCepillado, 50);
  if (!itx)
    cajaT(L + 182, T - (p.variante == 1 ? 200 : 252.5), f + 4, 34, 34, 8, color(70, 72, 80), texChip, 2);
  c(L + bw - 7, T - (itx ? 60 : 95), f + 4, 8, 52, 8, color(225));
  c(L + 25, T - 7, f + 4, 16, 8, 8, color(225));
  float cmx = itx ? 22 : 195, cmy = itx ? 22 : bh - 20;
  cilindro(L + cmx, T - cmy, f + 1, 11, 1.5, 2, 24, color(50));
}

// ---- Mesa y tapete ----
// @dibujarMesa(laptop) · Mesa de madera y tapete antiestático
void dibujarMesa(boolean laptop) {
  noStroke();
  cajaRep(0, -15.2, 0, 1800, 30, 900, color(255), texMadera, 700);
  planoMalla(-900, -450, 900, 450, 0, texMadera, 1800 / 700.0, 900 / 700.0, 36, 18, color(255));
  float mw = laptop ? 1100 : 1500;
  c(0, 0.6, 30, mw, 1.2, 700, color(45, 100, 116));
  planoMalla(-mw / 2, -320, mw / 2, 380, 1.22, texTapete, 1, 1, 44, 28, color(255));
}

// planoMalla(x0, z0, x1, z1, h, tex, ru, rv, nx, nz, tinte) · Plano dividido en cuadros (mejor luz por vértice)
void planoMalla(float x0, float z0, float x1, float z1, float h, PImage tex, float ru, float rv, int nx, int nz, color tinte) {
  noStroke();
  textureMode(NORMAL);
  tint(tinte);
  fill(tinte);
  material(tex);
  for (int j = 0; j < nz; j++) {
    float za = lerp(z0, z1, j / (float) nz), zb = lerp(z0, z1, (j + 1) / (float) nz);
    beginShape(QUAD_STRIP);
    texture(tex);
    normal(0, -1, 0);
    for (int i = 0; i <= nx; i++) {
      float x = lerp(x0, x1, i / (float) nx), u = ru * i / nx;
      vertex(x, -h, za, u, rv * j / nz);
      vertex(x, -h, zb, u, rv * (j + 1) / nz);
    }
    endShape();
  }
  noTint();
}

// ---- Cuerpos: laptop, gabinete, panel, monitor y cargador ----
// @dibujarCuerpoLaptop(e) · Base con teclado y tapa con pantalla, según el estilo del modelo
void dibujarCuerpoLaptop(Equipo e) {
  Modelo m = e.modelo;
  MT = m;
  float W = m.W, D = m.D, H = m.H, hw = W / 2, hd = D / 2;
  float deck = min(5.4, 0.27 * H - 0.2);
  noStroke();
  cajaT(0, H - deck / 2, 0, W, deck, D, m.chasis, m.texTeclado, 1);
  c(0, H - deck - 0.2, 0, W - 4, 0.4, D - 4, lerpColor(m.chasis, color(0), 0.45));
  float in = m.estilo == 1 ? 2.5 : 0, ph = H - deck - 2, pc = 2 + ph / 2;
  color pared = m.estilo == 1 ? lerpColor(m.chasis, color(0), 0.08) : m.chasis;
  c(-hw + 1 + in, pc, 0, 2, ph, D - 2 * in, pared);
  c(hw - 1 - in, pc, 0, 2, ph, D - 2 * in, pared);
  c(0, pc, -hd + 1 + in, W - 2 * in, ph, 2, pared);
  c(0, pc, hd - 1 - in, W - 2 * in, ph, 2, pared);
  if (m.estilo == 0) {
    for (int i = 0; i < 44; i++)
      c(-129 + i * 6, H * 0.52, -hd - 0.15, 3.6, H * 0.21, 0.4, color(12, 12, 14));
  } else if (m.estilo == 2) {
    for (int i = 0; i < 30; i++)
      c(-90 + i * 6, H * 0.5, -hd - 0.15, 3.6, H * 0.3, 0.4, color(12));
    c(-hw - 0.2, H * 0.45, 20, 0.6, 6, 28, color(25));
  } else if (m.estilo == 3) {
    for (int s = -1; s <= 1; s += 2) {
      for (int i = 0; i < 12; i++)
        c(s * (hw - 52) + (i - 6) * 7, H * 0.5, -hd - 0.15, 4.5, H * 0.6, 0.4, color(10));
      for (int i = 0; i < 9; i++)
        c(s * (hw + 0.15), H * 0.5, -hd + 20 + i * 7, 0.4, H * 0.5, 4.5, color(10));
    }
    c(0, H - deck - 1.2, hd + 0.2, W - 60, 1, 0.4, m.acento);
  }
  for (int i = 0; i < 9 && m.estilo != 1; i++) {
    c(-hw - 0.2, H * 0.5, -60 * m.D / 234 + i * 6, 0.4, 3.6, 3.6, color(12));
    c(hw + 0.2, H * 0.5, -60 * m.D / 234 + i * 6, 0.4, 3.6, 3.6, color(12));
  }
  float alto = m.estilo == 1 ? 0.8 : 1.2;
  for (float[] t : m.teclas) {
    float u0 = txX(t[0]) / 1024, u1 = txX(t[2]) / 1024, v0 = txZ(t[1]) / 704, v1 = txZ(t[3]) / 704;
    cajaT((t[0] + t[2]) / 2, H + alto / 2, (t[1] + t[3]) / 2, t[2] - t[0] - 0.4, alto, t[3] - t[1] - 0.4, lerpColor(m.tecla, color(0), 0.2), m.texTeclado, 1, u0, v0, u1, v1);
  }
  float ph2 = H * 0.42;
  c(-hw - 0.2, ph2, -30, 0.6, 3.2, 9, color(20));
  c(-hw - 0.2, ph2, -15, 0.6, 3, 9, color(20));
  c(hw + 0.2, ph2, -40, 0.6, 4, 12, color(20));
  c(hw + 0.2, ph2, -20, 0.6, 3, 9, color(20));
  cilindro(hw + 0.2, ph2, 0, 1.8, 0.8, 0, 12, color(15));
  if (m.estilo != 1) {
    c(-hw - 0.2, ph2, 0, 0.6, 4, 12, color(20));
    c(-hw - 0.2, ph2, 18, 0.6, 3, 9, color(20));
  }
  if (m.estilo == 2 || m.estilo == 3)
    c(-hw - 0.2, ph2 + 1, 40, 0.6, min(H * 0.55, 11), 15, color(20));
  float T = m.tapaGrosor;
  pushMatrix();
  translate(0, -H, -hd);
  rotateX(e.aperturaTapa());
  if (m.estilo == 2)
    cajaT(0, T / 2, hd, W, T, D, m.chasis, m.texTapa, 1, 1, 1, 0, 0);
  else
    cajaT(0, T / 2, hd, W, T, D, m.chasis, m.texTapa, 1);
  c(0, -0.1, hd, W - 10, 0.4, D - 10, color(14, 14, 16));
  float bx = m.estilo == 1 ? 0.475 : 0.456, bz0 = m.estilo == 1 ? 0.05 : 0.094, bz1 = m.estilo == 1 ? 0.95 : 0.93;
  boolean on = e.encendido && monitor.hayImagen();
  if (on)
    pantallaTexturizada(-W * bx, D * bz1, W * bx, D * bz0, -0.4, true);
  else {
    c(0, -0.3, D * (bz0 + bz1) / 2, W * bx * 2, 0.2, D * (bz1 - bz0), color(8, 9, 12));
    fill(255, 10);
    beginShape(QUADS);
    vertex(-W * 0.44, 0.45, D * 0.13);
    vertex(-W * 0.12, 0.45, D * 0.13);
    vertex(W * 0.18, 0.45, D * 0.9);
    vertex(-W * 0.15, 0.45, D * 0.9);
    endShape();
  }
  float cz = D * (bz1 + (1 - bz1) / 2);
  cilindro(0, -0.4, cz, 2, 0.6, 1, 12, color(5));
  cilindro(8, -0.4, cz, 1, 0.6, 1, 8, monitor.camaraActiva() ? color(80, 255, 120) : color(30));
  if (m.estilo == 2)
    c(-6, -0.8, cz, 9, 0.6, 4, color(60, 62, 68));
  if (m.estilo == 0)
    dibujarEmblema(e);
  else if (m.estilo == 3)
    dibujarLucesTapaTitan(e);
  else if (m.estilo == 2 && e.encendido) {
    sinLuces();
    c(-W / 2 + 70 * W / 1024 + 32, T + 0.1, D - 98 * D / 704, 3, 0.3, 3, color(255));
    restaurarLuces();
  }
  popMatrix();
  if (m.estilo == 1)
    cilindro(0, H, -hd + 3, 4, W * 0.7, 0, 20, lerpColor(m.chasis, color(0), 0.15));
  else if (m.estilo == 2)
    for (int s = -1; s <= 1; s += 2)
      c(s * W * 0.33, H, -hd + 5, 40, 10, 10, color(30, 31, 34));
  else if (m.estilo == 3)
    for (int s = -1; s <= 1; s += 2)
      c(s * W * 0.3, H + 1, -hd + 6, 56, 12, 12, color(24, 25, 28));
  else
    for (int s = -1; s <= 1; s += 2)
      cilindro(s * 110, H, -hd + 3, 4.5, 50, 0, 16, color(45, 47, 52));
  if (m.estilo == 0)
    dibujarBarraTrasera(e);
  if (m.estilo == 3)
    dibujarTiraFrontal(e);
  dibujarRetroiluminacion(e);
}

// @pantallaTexturizada(x0, z0, x1, z1, h, enTapa) · Imagen de la pantalla sin luces ni shader: siempre se ve nítida
void pantallaTexturizada(float x0, float z0, float x1, float z1, float h, boolean enTapa) {
  if (modoSombra)
    return;
  PImage img = monitor.imagen();
  textureMode(NORMAL);
  noStroke();
  sinLuces();
  noTint();
  beginShape(QUADS);
  texture(img);
  if (enTapa) {
    vertex(x0, -h, z0, 0, 0);
    vertex(x1, -h, z0, 1, 0);
    vertex(x1, -h, z1, 1, 1);
    vertex(x0, -h, z1, 0, 1);
  } else {
    vertex(x0, -z0, h, 0, 0);
    vertex(x1, -z0, h, 1, 0);
    vertex(x1, -z1, h, 1, 1);
    vertex(x0, -z1, h, 0, 1);
  }
  endShape();
  restaurarLuces();
}

// @dibujarGabinete(e) · Gabinete sin el panel lateral; el frente cambia con el modelo
void dibujarGabinete(Equipo e) {
  Modelo m = e.modelo;
  float W = m.W, H = m.H, D = m.D, x0 = -W / 2, x1 = W / 2, zb = -D / 2;
  noStroke();
  color cuerpo = m.chasis, bandeja = lerpColor(m.chasis, color(255), 0.05);
  PImage piel = m.estilo == 2 ? texCepillado : texGrano;
  float rep = m.estilo == 2 ? 200 : 60;
  cajaRep(0, H / 2, zb + 2, W, H, 4, bandeja, piel, rep);
  cajaRep(x0 + 2, H / 2, 0, 4, H, D, cuerpo, piel, rep);
  cajaRep(0, H - 2, 0, W, 4, D, cuerpo, piel, rep);
  cajaRep(0, 2, 0, W, 4, D, cuerpo, piel, rep);
  c(0, H, zb - 0.5, W, 4, 4, cuerpo);
  float btop = H - (m.cooler == 2 ? 110 : 35);
  int ranuras = m.placa == 2 ? 2 : (m.placa == 1 ? 4 : 7);
  for (int i = 0; i < ranuras; i++)
    cajaRep(x0 - 0.4, btop - 180 + (m.placa == 2 ? 30 : 0) - i * 22, -20, 0.6, 14, 110, i < 2 && e.puesta("gpu") ? color(170) : color(80), texCepillado, 40);
  c(x0 - 0.3, btop - 40, zb + 40, 0.6, 50, 22, color(15));
  if (m.discos > 0) {
    c(x1 - 95, 14, -52, 150, 2, 4, color(60));
    c(x1 - 95, 14, 52, 150, 2, 4, color(60));
  }
  if (m.estilo == 0) {
    cajaT(x1 + 0.6, H / 2 + 2, 0, 1.2, H - 24, D - 14, color(55), texMalla, 3, 0, 0, (D - 14) / 40.0, (H - 24) / 40.0);
    c(x1 + 1.3, H / 2 + 2, -D / 2 + 5, 1, H - 24, 4, color(18));
    c(x1 + 1.3, H / 2 + 2, D / 2 - 5, 1, H - 24, 4, color(18));
    if (e.encendido) {
      sinLuces();
      c(x1 + 1.6, H / 2 + 2, -D / 2 + 9, 0.6, H - 60, 1.5, color(60, 200, 255));
      restaurarLuces();
    }
    cilindro(x1 - 45, H + 1, D / 2 - 35, 6, 3, 1, 24, e.encendido ? color(80, 200, 255) : color(70));
  } else if (m.estilo == 1) {
    color frente = color(36, 37, 41);
    float bh0 = H - 50 - 22, bh1 = H - 50 + 22, bz = 74;
    c(x1 - 4, bh0 / 2, 0, 8, bh0, D, frente);
    c(x1 - 4, (bh1 + H) / 2, 0, 8, H - bh1, D, frente);
    c(x1 - 4, H - 50, bz + (D / 2 - bz) / 2, 8, 44, D / 2 - bz, frente);
    c(x1 - 4, H - 50, -bz - (D / 2 - bz) / 2, 8, 44, D / 2 - bz, frente);
    c(x1 - 9, H - 50, 0, 1, 44, 2 * bz, color(10));
    cilindro(x1 + 1, H - 110, 45, 9, 3, 0, 24, color(50, 52, 58));
    cilindro(x1 + 1.8, H - 110, 45, 10.5, 1, 0, 24, e.encendido ? color(80, 160, 255) : color(70));
    for (int i = 0; i < 2; i++)
      c(x1 + 0.2, H - 150, -20 + i * 18, 0.6, 5, 12, color(15));
    c(x1 + 0.2, H - 170, -14, 0.6, 6, 6, color(15));
    for (int i = 0; i < 12; i++)
      c(x1 + 0.2, 30 + i * 6, 0, 0.6, 2.5, D - 60, color(16));
    c(x1 + 0.3, H - 125, 0, 0.6, 2, D - 20, color(170, 172, 178));
  } else if (m.estilo == 2) {
    cajaRep(x1 + 4, H / 2, 0, 8, H, D, color(255), texMadera, 160);
    c(x1 + 8.2, 16, 0, 0.6, 2.5, D - 40, e.encendido ? m.acento : color(60, 50, 40));
    cilindro(x1 + 8.4, H - 26, 0, 5, 1.2, 0, 24, e.encendido ? color(255, 220, 170) : color(110, 90, 70));
    for (int s = -1; s <= 1; s += 2)
      c(0, -2.5, s * (D / 2 - 20), W - 40, 5, 14, color(20));
  } else {
    cajaRep(x1 + 4, H / 2, 0, 8, H, D, color(62, 64, 70), texCepillado, 200);
    for (int s = -1; s <= 1; s += 2)
      cajaT(x1 + 8.2, H / 2, s * (D / 2 - 20), 0.6, H - 60, 22, color(40), texMalla, 3, 0, 0, 0.6, (H - 60) / 40.0);
    c(x1 + 8.4, H - 40, 0, 0.6, 3, 70, e.encendido ? color(235, 240, 255) : color(90));
    cajaT(0, H + 0.4, 0, W - 140, 0.8, D - 50, color(50), texMalla, 1, 0, 0, (W - 140) / 40.0, (D - 50) / 40.0);
    for (int s = -1; s <= 1; s += 2) {
      float hx = s * (W / 2 - 45);
      c(hx, H + 14, -D / 2 + 40, 14, 28, 14, color(30));
      c(hx, H + 14, D / 2 - 40, 14, 28, 14, color(30));
      cajaRep(hx, H + 30, 0, 14, 8, D - 66, color(150, 152, 158), texCepillado, 80);
    }
    for (int i = -1; i <= 1; i += 2)
      for (int j = -1; j <= 1; j += 2)
        c(i * (W / 2 - 40), -3, j * (D / 2 - 25), 50, 6, 30, color(15));
  }
  if (m.estilo != 2 && m.estilo != 3)
    for (int i = -1; i <= 1; i += 2)
      for (int j = -1; j <= 1; j += 2)
        c(i * (W / 2 - 35), -1, j * (D / 2 - 20), 30, 2, 20, color(15));
}

// dibujarPanelVidrio(p, enEquipo) · Panel lateral de vidrio templado (transparente)
void dibujarPanelVidrio(Pieza p, boolean enEquipo) {
  noStroke();
  Modelo m = equipo.laptop ? null : equipo.modelo;
  color marco = p.variante == 1 ? (m != null ? m.chasis : color(50)) : color(25, 25, 28);
  if (p.variante == 1) {
    cajaRep(0, 0, 0, p.w, p.alto, p.d, marco, texGrano, 60);
    cajaT(-p.w * 0.18, p.alto * 0.2, p.d / 2 + 0.15, 130, 130, 0.3, color(40), texMalla, 2, 0, 0, 4, 4);
    return;
  }
  fill(marco);
  c(0, p.alto / 2 - 4, 0, p.w, 8, p.d + 1);
  c(0, -p.alto / 2 + 4, 0, p.w, 8, p.d + 1);
  c(-p.w / 2 + 4, 0, 0, 8, p.alto, p.d + 1);
  c(p.w / 2 - 4, 0, 0, 8, p.alto, p.d + 1);
  if (p.variante == 2) {
    cajaT(0, 0, p.d / 2 - 0.5, p.w - 16, p.alto - 16, 0.4, color(190, 192, 198, 165), texMallaVer, 2, 0, 0, (p.w - 16) / 22.0, (p.alto - 16) / 22.0);
    return;
  }
  fill(120, 150, 175, 45);
  box(p.w - 16, p.alto - 16, p.d);
  fill(255, 22);
  float zf = p.d / 2 + 0.3, hw = p.w / 2 - 8, ha = p.alto / 2 - 8;
  beginShape(QUADS);
  vertex(-hw + 40, -ha, zf);
  vertex(-hw + 110, -ha, zf);
  vertex(-hw + 10, ha, zf);
  vertex(-hw - 60 + 50, ha, zf);
  vertex(-hw + 150, -ha, zf);
  vertex(-hw + 175, -ha, zf);
  vertex(-hw + 75, ha, zf);
  vertex(-hw + 50, ha, zf);
  endShape();
}

// @dibujarMonitor(e) · Monitor de la PC con la imagen de la pantalla simulada
void dibujarMonitor(Equipo e) {
  pushMatrix();
  translate(470, 0, -230);
  rotateY(-0.42);
  noStroke();
  cajaRep(0, 4, 0, 220, 8, 160, color(150, 152, 160), texCepillado, 120);
  cajaRep(0, 70, -40, 50, 130, 20, color(150, 152, 160), texCepillado, 120);
  c(0, 285, -6, 560, 330, 20, color(25, 26, 30));
  c(0, 285, -18, 300, 180, 10, color(32, 33, 38));
  boolean on = e.encendido && monitor.hayImagen();
  if (on)
    pantallaTexturizada(-268, 440, 268, 130, 4.2, false);
  else {
    c(0, 285, 4.1, 536, 310, 0.4, color(8, 9, 12));
    fill(255, 10);
    beginShape(QUADS);
    vertex(-250, -430, 4.5);
    vertex(-120, -430, 4.5);
    vertex(60, -140, 4.5);
    vertex(-70, -140, 4.5);
    endShape();
  }
  c(0, 457, 0, 70, 16, 22, color(20));
  cilindro(0, 457, 11.5, 5, 1.5, 2, 16, color(10, 20, 40));
  cilindro(18, 457, 11.5, 1.5, 1.5, 2, 8, monitor.camaraActiva() ? color(80, 255, 120) : color(40));
  popMatrix();
}

// dibujarCargador() · Cargador de la laptop sobre la mesa
void dibujarCargador() {
  cajaRep(-430, 14, -250, 110, 28, 60, color(30, 31, 35), texGrano, 40);
  pegatina(-430, 28.25, -250, 70, 0.3, 36, texEtqCargador, 1);
}

// ---- Tornillos, conectores y selección ----
// dibujarTornillo(t, resaltado) · Tornillo puesto o su hueco vacío
void dibujarTornillo(Tornillo t, boolean resaltado) {
  float sale = t.puesto ? t.anim * 10 : (t.anim > 0 ? (1 - t.anim) * 10 : 0);
  if (!t.puesto && t.anim <= 0) {
    fill(15);
    float s = t.grande ? 7 : 3.5;
    c(t.x + t.nx * 0.3, t.h + t.nh * 0.3, t.z + t.nz * 0.3, abs(t.nx) > 0.5 ? 0.4 : s, abs(t.nh) > 0.5 ? 0.4 : s, abs(t.nz) > 0.5 ? 0.4 : s);
    return;
  }
  float s = t.grande ? 12 : 5, g = t.grande ? 6 : 1.4;
  float x = t.x + t.nx * (g / 2 + sale), h = t.h + t.nh * (g / 2 + sale), z = t.z + t.nz * (g / 2 + sale);
  fill(resaltado ? color(255, 230, 80) : (t.grande ? color(40) : color(150, 152, 160)));
  c(x, h, z, abs(t.nx) > 0.5 ? g : s, abs(t.nh) > 0.5 ? g : s, abs(t.nz) > 0.5 ? g : s);
  fill(40);
  float r = t.grande ? 0 : 0.4;
  if (r > 0) {
    float ox = t.nx * (g / 2 + 0.1), oh = t.nh * (g / 2 + 0.1), oz = t.nz * (g / 2 + 0.1);
    c(x + ox, h + oh, z + oz, abs(t.nx) > 0.5 ? 0.3 : (abs(t.nh) > 0.5 ? 3.6 : 3.6), abs(t.nh) > 0.5 ? 0.3 : 0.8, abs(t.nz) > 0.5 ? 0.3 : 0.8);
    c(x + ox, h + oh, z + oz, abs(t.nx) > 0.5 ? 0.3 : 0.8, abs(t.nh) > 0.5 ? 0.3 : 3.6, abs(t.nz) > 0.5 ? 0.3 : 3.6);
  }
}

// dibujarConector(k, e, resaltado) · Enchufe y su cable
void dibujarConector(Conector k, Equipo e, boolean resaltado) {
  float s = k.separacion();
  if (!e.puesta(k.destino))
    s = 25;
  float x = k.x + k.nx * s, h = k.h + k.nh * s, z = k.z + k.nz * s;
  noStroke();
  fill(resaltado ? color(255, 230, 80) : k.col);
  c(x, h, z, k.w, k.alto, k.d);
  if (k.cable.length >= 3) {
    stroke(k.colCable);
    strokeWeight(k.grosor);
    noFill();
    float px = x, ph = h, pz = z;
    for (int i = 0; i + 2 < k.cable.length; i += 3) {
      line(px, -ph, pz, k.cable[i], -k.cable[i + 1], k.cable[i + 2]);
      px = k.cable[i];
      ph = k.cable[i + 1];
      pz = k.cable[i + 2];
    }
    noStroke();
  }
}

// marcoSeleccion(x, h, z, w, a, d) · Marco de líneas alrededor de una caja
void marcoSeleccion(float x, float h, float z, float w, float a, float d) {
  pushMatrix();
  translate(x, -h, z);
  noFill();
  stroke(255, 225, 60);
  strokeWeight(2);
  box(w + 2, a + 2, d + 2);
  noStroke();
  popMatrix();
}
