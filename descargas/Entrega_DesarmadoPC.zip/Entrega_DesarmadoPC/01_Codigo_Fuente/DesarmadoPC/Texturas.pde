// ============================================================
// TEXTURAS · generadas por código al iniciar; cajas con textura, sombras y fondo
// ============================================================

// ---- Texturas comunes ----
PImage texGrano, texMadera, texTapete, texAluminio, texCepillado, texCobre, texMalla, texChip;
PImage texSombra, texBrillo, texMallaVer;
PImage texPlacaLaptop, texPlacaATX, texSodimm, texDimm, texM2, texWifi;
PImage texEtqRamD, texEtqCargador, texIHS, texEtqSSD25, texEtqDVD;
PImage texEtqBateria, texEtqRam, texEtqSSD, texEtqHDD, texEtqPSU, texEtqGPU;

// @crearTexturas() · Genera todas las texturas al iniciar (madera, tapete, metales, PCB, etiquetas...)
void crearTexturas() {
  noiseSeed(5);
  randomSeed(5);
  texGrano = generar(128, 128, 0);
  texMadera = generar(512, 256, 1);
  texAluminio = generar(256, 256, 2);
  texCepillado = generar(256, 128, 3);
  texCobre = generar(128, 64, 4);
  texMalla = generar(128, 128, 5);
  texMallaVer = generar(128, 128, 8);
  texSombra = generar(128, 128, 6);
  texBrillo = generar(64, 64, 7);
  texChip = pintarChip();
  texTapete = pintarTapete();
  texPlacaLaptop = pintarPCB(960, 580, color(22, 24, 28), 11, true);
  texPlacaATX = pintarPCB(732, 915, color(30, 32, 38), 12, false);
  texSodimm = pintarModuloRAM(280, 120, 13, false);
  texDimm = pintarModuloRAM(132, 532, 14, true);
  texM2 = pintarM2();
  texWifi = pintarPCB(120, 88, color(25, 80, 55), 16, true);
  texEtqBateria = etiqueta(440, 144, color(30, 32, 36), color(225), "BATERÍA DE IONES DE LITIO", "76 Wh · 15.4 V · 4 celdas", "No perforar · No quemar · Reciclar", color(230, 170, 40));
  texEtqRam = etiqueta(176, 48, color(235), color(30), "DDR5 SO-DIMM 16 GB", "4800 MT/s · 1.1 V", "", color(40, 110, 200));
  texEtqSSD = etiqueta(240, 72, color(235), color(30), "SSD NVMe 1 TB", "PCIe 4.0 x4 · M.2 2280", "", color(200, 60, 50));
  texEtqHDD = etiqueta(320, 200, color(225, 227, 230), color(35), "DISCO DURO 3.5\"", "2 TB · 7200 RPM · SATA 6 Gb/s", "No abrir: anula la garantía", color(40, 90, 170));
  texEtqPSU = etiqueta(360, 200, color(230, 231, 234), color(30), "FUENTE DE PODER ATX", "750 W · Eficiencia Oro · 100-240 V~", "Peligro: alto voltaje en el interior", color(200, 40, 40));
  texEtqRamD = etiqueta(240, 64, color(235), color(30), "DDR5 16 GB · 6000", "1.35 V · CL30", "", color(185, 40, 48));
  texEtqCargador = etiqueta(280, 144, color(40, 41, 46), color(210), "ADAPTADOR DE CA", "Entrada 100-240 V~ · Salida 20 V DC 12 A", "Solo para uso en interiores", color(120, 200, 255));
  texEtqSSD25 = etiqueta(300, 200, color(30, 32, 36), color(225), "SSD SATA 2.5\"", "1 TB · 6 Gb/s · 7 mm", "Manéjalo por los bordes", color(70, 150, 255));
  texEtqDVD = etiqueta(300, 220, color(225, 227, 230), color(35), "UNIDAD ÓPTICA DVD±RW", "SATA · 24x · 5.25\"", "Producto láser clase 1", color(200, 60, 50));
  texIHS = etiqueta(160, 160, color(200, 202, 208), color(70), "TL-8800X", "8 núcleos · 4.6 GHz", "Hecho para el Taller", color(170));
  texEtqGPU = etiqueta(300, 40, color(18, 19, 22), color(0, 200, 170), "TARJETA GRÁFICA · 12 GB", "", "", color(0, 200, 170));
}

// ---- Texturas por píxel (ruido de Perlin) ----
// @generar(w, h, tipo) · Textura por píxel con ruido de Perlin
PImage generar(int w, int h, int tipo) {
  PImage img = createImage(w, h, ARGB);
  img.loadPixels();
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++)
      img.pixels[y * w + x] = pixelTextura(tipo, x / (float) w, y / (float) h, x, y, w, h);
  img.updatePixels();
  return img;
}

// ruidoC(u, v, esc) · Ruido que se repite sin costura
float ruidoC(float u, float v, float esc) {
  float a = noise(u * esc, v * esc), b = noise((u - 1) * esc, v * esc);
  float c = noise(u * esc, (v - 1) * esc), d = noise((u - 1) * esc, (v - 1) * esc);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

// pixelTextura(tipo, u, v, x, y, w, h) · Color de un píxel según el tipo de material
color pixelTextura(int tipo, float u, float v, int x, int y, int w, int h) {
  switch (tipo) {
  case 0: {
    float n = ruidoC(u, v, 24) * 0.6 + ruidoC(u, v, 80) * 0.4;
    float g = 222 + n * 33;
    return color(g, g, g);
  }
  case 1: {
    float vet = ruidoC(u * 0.25, v, 5) * 9;
    float anillo = (sin((v * 14 + vet) * PI) + 1) / 2;
    float fino = ruidoC(u, v, 48);
    color c = lerpColor(color(96, 62, 38), color(158, 112, 72), anillo * 0.55 + fino * 0.45);
    return lerpColor(c, color(60, 38, 24), ruidoC(u, v, 2.5) * 0.25);
  }
  case 2: {
    float n = ruidoC(u, v, 40) * 0.5 + ruidoC(u, v, 160) * 0.5;
    float g = 200 + n * 40 + (random(1) < 0.015 ? 25 : 0);
    return color(g, g, g + 6);
  }
  case 3: {
    float n = ruidoC(u * 0.04, v, 90) * 0.7 + ruidoC(u, v, 10) * 0.3;
    float g = 175 + n * 80;
    return color(g, g, g + 4);
  }
  case 4: {
    float n = ruidoC(u * 0.1, v, 30);
    float brillo = pow(sin(v * PI), 3);
    return lerpColor(color(150, 78, 40), color(245, 170, 115), constrain(brillo * 0.7 + n * 0.3, 0, 1));
  }
  case 5: {
    float cx = (x % 16) - 8, cy = (y % 14) - 7;
    if ((y / 14) % 2 == 1)
      cx = ((x + 8) % 16) - 8;
    boolean hueco = cx * cx + cy * cy < 22;
    return hueco ? color(8, 8, 10, 255) : color(70, 72, 78);
  }
  case 6: {
    float dx = max(abs(u - 0.5) * 2 - 0.55, 0) / 0.45, dy = max(abs(v - 0.5) * 2 - 0.55, 0) / 0.45;
    float d = constrain(sqrt(dx * dx + dy * dy), 0, 1);
    float a = pow(1 - d, 2.2);
    return color(0, 0, 0, a * 255);
  }
  case 8: {
    float cx = (x % 16) - 8, cy = (y % 14) - 7;
    if ((y / 14) % 2 == 1)
      cx = ((x + 8) % 16) - 8;
    boolean hueco = cx * cx + cy * cy < 30;
    return hueco ? color(8, 8, 10, 0) : color(150, 152, 158, 255);
  }
  default: {
    float d = dist(u, v, 0.5, 0.5) * 2;
    float a = pow(constrain(1 - d, 0, 1), 2);
    return color(255, 255, 255, a * 255);
  }
  }
}

// ---- Texturas dibujadas ----
// lienzo(w, h) · PGraphics nuevo para pintar una textura
PGraphics lienzo(int w, int h) {
  PGraphics g = createGraphics(w, h, P2D);
  g.smooth(8);
  g.beginDraw();
  g.noStroke();
  return g;
}

// fondoRuido(g, t, tinte, escala) · Rellena un lienzo repitiendo una textura teñida
void fondoRuido(PGraphics g, PImage t, color tinte, float escala) {
  g.tint(tinte);
  for (float y = 0; y < g.height; y += t.height * escala)
    for (float x = 0; x < g.width; x += t.width * escala)
      g.image(t, x, y, t.width * escala, t.height * escala);
  g.noTint();
}

// pintarTapete() · Tapete antiestático con cuadrícula y reglas
PImage pintarTapete() {
  PGraphics g = lienzo(1024, 652);
  fondoRuido(g, texGrano, color(52, 112, 128), 2);
  float k = 1024 / 1100.0;
  for (int i = 0; i <= 110; i++) {
    g.stroke(110, 175, 190, i % 5 == 0 ? 110 : 45);
    g.strokeWeight(i % 5 == 0 ? 1.4 : 0.8);
    g.line(i * 10 * k, 0, i * 10 * k, g.height);
  }
  for (int j = 0; j <= 70; j++) {
    g.stroke(110, 175, 190, j % 5 == 0 ? 110 : 45);
    g.strokeWeight(j % 5 == 0 ? 1.4 : 0.8);
    g.line(0, j * 10 * k, g.width, j * 10 * k);
  }
  g.stroke(225, 240, 245, 200);
  g.strokeWeight(1);
  for (int i = 0; i < 1100; i += 5) {
    float l = i % 50 == 0 ? 14 : (i % 10 == 0 ? 9 : 5);
    g.line(i * k, 0, i * k, l);
    g.line(i * k, g.height, i * k, g.height - l);
  }
  g.noStroke();
  g.fill(225, 240, 245, 210);
  g.textFont(fuente, 11);
  g.textAlign(CENTER, TOP);
  for (int i = 50; i < 1100; i += 50)
    g.text(i / 10, i * k, 16);
  g.noFill();
  g.stroke(225, 240, 245, 150);
  g.strokeWeight(1.5);
  for (int i = 0; i < 6; i++) {
    g.ellipse(70 + i * 62, g.height - 70, 48, 48);
    g.ellipse(70 + i * 62, g.height - 70, 4, 4);
  }
  g.noStroke();
  g.fill(225, 240, 245, 200);
  g.textFont(fuente, 13);
  g.textAlign(LEFT, CENTER);
  g.text("TORNILLOS · ordénalos por paso", 50, g.height - 112);
  g.textAlign(RIGHT, BOTTOM);
  g.textFont(fuente, 16);
  g.text("TAPETE ANTIESTÁTICO · conéctalo a tierra", g.width - 30, g.height - 26);
  g.fill(190, 195, 200);
  g.ellipse(g.width - 34, 40, 22, 22);
  g.fill(120);
  g.ellipse(g.width - 34, 40, 9, 9);
  g.endDraw();
  return g;
}

// ---- Texturas de cada laptop: teclado, fondo y tapa ----
Modelo MT;
// txX(x) · Coordenada x de la laptop a píxel de su textura
float txX(float x) {
  return (x + MT.W / 2) / MT.W * 1024;
}
// txZ(z) · Coordenada z de la laptop a píxel de su textura
float txZ(float z) {
  return (z + MT.D / 2) / MT.D * 704;
}
// fdX(x) · Coordenada x a píxel de la textura del fondo (vista de abajo)
float fdX(float x) {
  return (MT.W / 2 - x) / MT.W * 1024;
}

// crearTexturasModelo(m) · Texturas propias del modelo: teclado, fondo y tapa
void crearTexturasModelo(Modelo m) {
  MT = m;
  definirTeclado(m);
  m.texTeclado = pintarTeclado(m, false);
  m.texLeyendas = pintarTeclado(m, true);
  m.texFondo = pintarFondoLaptop(m);
  m.texTapa = pintarTapaExterior(m);
}

// definirTeclado(m) · Teclas en español (con teclado numérico si el modelo lo trae)
void definirTeclado(Modelo m) {
  String[][] filas = {
    {"Esc", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "Impr", "Supr"},
    {"º", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "'", "¡", "←"},
    {"Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "`", "+", "Intro"},
    {"Bloq", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Ñ", "´", "Ç", ""},
    {"Mayús", "<", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "-", "Mayús"},
    {"Ctrl", "Fn", "Sis", "Alt", "", "AltGr", "Ctrl", "←", "↑", "↓", "→"}};
  float[][] anchos = {
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2},
    {1.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.5},
    {1.75, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1.25},
    {1.25, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2.75},
    {1.25, 1, 1, 1, 5.5, 1, 1, 0.8, 0.8, 0.8, 0.8}};
  String[][] numFilas = {{"Inicio", "Fin", "RePág", "AvPág"}, {"Num", "/", "*", "-"}, {"7", "8", "9", "+"}, {"4", "5", "6", ""}, {"1", "2", "3", "Intro"}, {"0", "", ".", ""}};
  float unidades = m.numpad ? 19.4 : 15;
  float u = min(18.6, (m.W - (m.numpad ? 40 : 58)) / unidades);
  float x0 = -unidades * u / 2, z = -m.D / 2 + m.D * 0.13;
  if (m.estilo == 1)
    z = -m.D / 2 + m.D * 0.1;
  ArrayList<float[]> lista = new ArrayList<float[]>();
  ArrayList<String> letras = new ArrayList<String>();
  for (int f = 0; f < filas.length; f++) {
    float alto = f == 0 ? u * 0.6 : u;
    float x = x0;
    for (int i = 0; i < filas[f].length; i++) {
      float w = anchos[f][i] * u;
      lista.add(new float[] {x + 1.4, z + 1.4, x + w - 1.4, z + alto - 1.4});
      letras.add(filas[f][i]);
      x += w;
    }
    if (m.numpad) {
      x = x0 + 15.4 * u;
      for (int i = 0; i < 4; i++) {
        String l = numFilas[f][i];
        if (f == 5 && (i == 1 || i == 3))
          continue;
        float w = (f == 5 && i == 0) ? 2 * u : u;
        lista.add(new float[] {x + i * u + 1.4, z + 1.4, x + i * u + w - 1.4, z + alto - 1.4});
        letras.add(l);
      }
    }
    z += alto + (f == 0 ? 2 : 0);
  }
  float abajo = z;
  float px = m.numpad ? x0 + unidades * u - 12 : x0 + unidades * u + 1.5, pz = -m.D / 2 + m.D * 0.13 - (m.numpad ? 14 : -1.4);
  if (m.estilo == 1)
    pz = -m.D / 2 + m.D * 0.1 + 1.4;
  lista.add(new float[] {px, pz, px + 11, pz + u * 0.6 - 2.8});
  letras.add("");
  m.teclas = lista.toArray(new float[0][]);
  m.letras = letras.toArray(new String[0]);
  float tw = m.estilo == 1 ? m.W * 0.44 : (m.estilo == 2 ? m.W * 0.3 : m.W * 0.36);
  float tc = x0 + 7.5 * u;
  m.tpX0 = tc - tw / 2;
  m.tpX1 = tc + tw / 2;
  m.tpZ0 = abajo + m.D * 0.08;
  m.tpZ1 = m.D / 2 - m.D * (m.estilo == 2 ? 0.12 : 0.04);
}

// pintarTeclado(m, leyendas) · Teclado o solo sus leyendas (para la retroiluminación)
PImage pintarTeclado(Modelo m, boolean leyendas) {
  MT = m;
  PGraphics g = lienzo(1024, 704);
  float u = (txX(m.teclas[1][2]) - txX(m.teclas[1][0]));
  if (!leyendas) {
    fondoRuido(g, texAluminio, m.estilo == 1 ? color(200, 203, 208) : m.chasis, 1);
    if (m.estilo == 2) {
      g.fill(0, 40);
      g.rect(0, 0, g.width, g.height);
    }
    g.fill(m.estilo == 1 ? color(60, 62, 68) : color(14, 14, 18));
    if (m.estilo == 1) {
      for (int s = -1; s <= 1; s += 2)
        for (int i = 0; i < 26; i++)
          for (int j = 0; j < 4; j++)
            g.ellipse(txX(s * (m.W / 2 - 12) - s * j * 3.2), txZ(-m.D / 2 + 26 + i * 3.6), 3.4, 3.4);
    } else {
      float zf = m.teclas[0][1] - 9;
      int n = int((m.W - 60) / 4.75);
      for (int i = 0; i < n; i++)
        for (int j = 0; j < (m.estilo == 3 ? 2 : 4); j++)
          g.ellipse(txX(-m.W / 2 + 30 + i * 4.75 + (j % 2) * 2.4), txZ(zf - 6 + j * 3.4), 4.2, 4.2);
    }
    float[] a = m.teclas[0], b = m.teclas[m.teclas.length - 2];
    float kx0 = 100000, kx1 = -100000, kz0 = 100000, kz1 = -100000;
    for (float[] t : m.teclas) {
      kx0 = min(kx0, t[0]);
      kx1 = max(kx1, t[2]);
      kz0 = min(kz0, t[1]);
      kz1 = max(kz1, t[3]);
    }
    g.fill(m.estilo == 1 ? color(120, 123, 128) : color(14, 14, 17));
    g.rect(txX(kx0 - 3), txZ(kz0 - 3), txX(kx1 + 3) - txX(kx0 - 3), txZ(kz1 + 3) - txZ(kz0 - 3), 8);
    float tx0 = txX(m.tpX0), tz0 = txZ(m.tpZ0), tw = txX(m.tpX1) - tx0, th = txZ(m.tpZ1) - tz0;
    color tpA = m.estilo == 1 ? color(214, 217, 222) : lerpColor(m.chasis, color(255), 0.06);
    color tpB = m.estilo == 1 ? color(190, 193, 198) : lerpColor(m.chasis, color(0), 0.2);
    g.fill(lerpColor(tpB, color(0), 0.3));
    g.rect(tx0 - 2, tz0 - 2, tw + 4, th + 4, 10);
    for (int i = 0; i < th; i++) {
      g.fill(lerpColor(tpA, tpB, i / th));
      g.rect(tx0, tz0 + i, tw, 1);
    }
    g.fill(255, 18);
    g.rect(tx0, tz0, tw, 3, 10, 10, 0, 0);
    if (m.estilo == 2) {
      float by = tz0 + th + 6;
      g.fill(26);
      g.rect(tx0, by, tw / 2 - 2, 26, 4);
      g.rect(tx0 + tw / 2 + 2, by, tw / 2 - 2, 26, 4);
      g.fill(18);
      g.rect(txX(m.W / 2 - 58), txZ(m.tpZ0 + 6), 48, 48, 8);
      g.fill(70);
      g.rect(txX(m.W / 2 - 58) + 6, txZ(m.tpZ0 + 6) + 6, 36, 36, 6);
      for (int i = 0; i < 3; i++) {
        g.fill(40);
        g.ellipse(txX(-m.W / 2 + 22 + i * 8), txZ(m.D / 2 - 10), 6, 6);
      }
    }
    if (m.estilo == 3) {
      g.fill(m.acento);
      g.rect(tx0 - 14, tz0, 3, th);
      g.rect(tx0 + tw + 11, tz0, 3, th);
    }
    g.fill(m.estilo == 1 ? color(235) : lerpColor(m.chasis, color(255), 0.4));
    g.rect(0, g.height - 4, g.width, 4);
  } else
    g.clear();
  for (int i = 0; i < m.teclas.length; i++) {
    float[] t = m.teclas[i];
    float x = txX(t[0]), z = txZ(t[1]), w = txX(t[2]) - x, h = txZ(t[3]) - z;
    String l = m.letras[i];
    boolean wasd = m.estilo == 3 && (l.equals("W") || l.equals("A") || l.equals("S") || l.equals("D"));
    if (!leyendas) {
      g.fill(lerpColor(m.tecla, color(0), 0.3));
      g.rect(x, z, w, h, 5);
      g.fill(m.tecla);
      g.rect(x + 3, z + 2, w - 6, h - 6, 4);
      g.fill(255, m.estilo == 1 ? 40 : 14);
      g.rect(x + 3, z + 2, w - 6, 3, 4, 4, 0, 0);
      if (wasd) {
        g.noFill();
        g.stroke(m.acento);
        g.strokeWeight(2);
        g.rect(x + 3, z + 2, w - 6, h - 6, 4);
        g.noStroke();
      }
    } else {
      g.noFill();
      for (int k = 0; k < 4; k++) {
        g.stroke(255, 32 - k * 7);
        g.strokeWeight(2 + k * 2);
        g.rect(x - 1, z - 1, w + 2, h + 2, 6);
      }
      g.noStroke();
    }
    if (i == m.teclas.length - 1) {
      g.noFill();
      g.stroke(leyendas ? color(255) : m.leyenda);
      g.strokeWeight(2);
      g.arc(x + w / 2, z + h / 2, h * 0.5, h * 0.5, -PI / 2 + 0.6, 3 * PI / 2 - 0.6);
      g.line(x + w / 2, z + h / 2 - h * 0.3, x + w / 2, z + h / 2);
      g.noStroke();
      continue;
    }
    if (l.length() == 0)
      continue;
    g.fill(leyendas ? color(255) : (wasd ? m.acento : m.leyenda));
    float tam = u * 0.31;
    g.textFont(fuente, l.length() > 2 ? tam * 0.72 : tam);
    g.textAlign(l.length() > 2 ? LEFT : CENTER, l.length() > 2 ? BOTTOM : CENTER);
    if (l.length() > 2)
      g.text(l, x + 6, z + h - 8);
    else
      g.text(l, x + w / 2, z + h / 2 - 2);
  }
  g.endDraw();
  return g;
}

// pintarFondoLaptop(m) · Tapa inferior con rejillas, patas y etiqueta
PImage pintarFondoLaptop(Modelo m) {
  MT = m;
  PGraphics g = lienzo(1024, 704);
  fondoRuido(g, texAluminio, m.estilo == 1 ? color(186, 189, 194) : lerpColor(m.chasis, color(0), 0.1), 1);
  float sx = m.W / 340, sz = m.D / 234;
  if (m.estilo == 0) {
    float[][] zonas = {{127 * sx, -70 * sz, 70}, {-40 * sx, -70 * sz, 64}};
    for (float[] zn : zonas)
      for (float a = -zn[2] / 2; a <= zn[2] / 2; a += 4.2)
        for (float b = -28; b <= 28; b += 3.8) {
          float px = zn[0] + a + (round(b / 3.8) % 2 == 0 ? 0 : 2.1);
          if (abs(px - zn[0]) > zn[2] / 2)
            continue;
          g.fill(10, 10, 12);
          hexagono(g, fdX(px), txZ(zn[1] + b), 5.2);
        }
  } else if (m.estilo == 1) {
    g.fill(70, 72, 78);
    for (int i = 0; i < 46; i++)
      g.rect(fdX(-110 * sx + i * 4.6 * sx), txZ(-m.D / 2 + 18), 5, 34, 2);
    g.fill(60, 62, 66);
    g.textFont(fuente, 13);
    g.textAlign(CENTER, CENTER);
    g.text("Aero 13 · Diseñada en el Taller", fdX(0), txZ(m.D / 2 - 30));
  } else if (m.estilo == 2) {
    g.noFill();
    g.stroke(20);
    g.strokeWeight(2);
    g.rect(fdX(m.W / 2 - 14), txZ(-m.D / 2 + 14), fdX(-m.W / 2 + 14) - fdX(m.W / 2 - 14), txZ(m.D / 2 - 40) - txZ(-m.D / 2 + 14), 10);
    g.noStroke();
    g.fill(12);
    for (int i = 0; i < 14; i++)
      for (int j = 0; j < 9; j++)
        g.rect(fdX(80 * sx + i * 6) - 2, txZ(-90 * sz + j * 7), 8, 12, 2);
    g.fill(25);
    g.rect(fdX(20), txZ(m.D / 2 - 30), 60, 18, 4);
    g.fill(60);
    g.textFont(fuente, 12);
    g.textAlign(LEFT, CENTER);
    g.text("BASE", fdX(20) + 70, txZ(m.D / 2 - 30) + 9);
  } else {
    g.fill(10);
    for (int i = 0; i < 30; i++)
      for (int j = 0; j < 12; j++)
        g.rect(fdX(-150 * sx + i * 10.5 * sx) - 3, txZ(-100 * sz + j * 9), 6 * sx * 2, 20, 3);
    g.fill(m.acento);
    g.rect(fdX(m.W / 2 - 12), txZ(m.D / 2 - 26), fdX(-m.W / 2 + 12) - fdX(m.W / 2 - 12), 4);
  }
  if (m.estilo != 1) {
    g.fill(12);
    int n = int((m.W - 40) / 7.6);
    for (int i = 0; i < n; i++)
      g.rect(fdX(-m.W / 2 + 20 + i * 7.6), txZ(-m.D / 2 + 3), 10, 22, 3);
  }
  g.fill(35);
  float[][] t = {{-160, -105}, {-55, -105}, {55, -105}, {160, -105}, {-160, 105}, {-55, 105}, {55, 105}, {160, 105}, {0, 0}, {-110, 0}};
  for (float[] p : t)
    g.ellipse(fdX(p[0] * sx), txZ(p[1] * sz), 16, 16);
  float ex = fdX(-40 * sx), ez = txZ(28 * sz);
  g.fill(m.estilo == 1 ? color(200, 203, 208) : color(215, 218, 222));
  g.rect(ex, ez, 190, 92, 4);
  g.fill(40);
  g.textFont(fuente, 13);
  g.textAlign(LEFT, TOP);
  g.text(m.nombre + " · " + m.clase, ex + 10, ez + 8, 180, 20);
  g.textFont(fuente, 10);
  g.text("Modelo TL-" + m.id.toUpperCase() + " · 20 V DC\nN/S: TL4G-0087-2Q61\nHecha para el Taller", ex + 10, ez + 28);
  for (int i = 0; i < 40; i++) {
    g.fill(i % 3 == 0 ? 255 : 30);
    g.rect(ex + 120 + i * 1.6, ez + 64, 1.6, 20);
  }
  g.endDraw();
  return g;
}

// pintarTapaExterior(m) · Cubierta exterior de la pantalla
PImage pintarTapaExterior(Modelo m) {
  MT = m;
  PGraphics g = lienzo(1024, 704);
  float cx = g.width / 2, cy = g.height / 2;
  if (m.estilo == 0) {
    fondoRuido(g, texAluminio, m.chasis, 1);
    for (int r = 190; r > 0; r -= 2) {
      float n = noise(r * 0.15) * 30;
      g.fill(70 + n, 72 + n, 80 + n, 70);
      g.ellipse(cx, cy, r * 2, r * 2);
    }
    g.fill(40, 42, 46);
    g.rect(cx - 300, 30, 3, g.height - 60);
    g.rect(cx + 297, 30, 3, g.height - 60);
  } else if (m.estilo == 1) {
    fondoRuido(g, texCepillado, color(205, 208, 213), 2);
    g.fill(235, 238, 242);
    g.ellipse(cx, cy, 96, 96);
    g.fill(170, 174, 180);
    g.ellipse(cx, cy, 84, 84);
    g.fill(240, 243, 247);
    g.triangle(cx, cy - 28, cx - 24, cy + 22, cx + 24, cy + 22);
    g.fill(170, 174, 180);
    g.triangle(cx, cy - 8, cx - 11, cy + 22, cx + 11, cy + 22);
  } else if (m.estilo == 2) {
    fondoRuido(g, texGrano, m.chasis, 1);
    g.fill(0, 30);
    g.rect(0, 0, g.width, g.height);
    g.fill(70, 72, 78);
    g.rect(70, g.height - 120, 150, 46, 6);
    g.fill(175);
    g.textFont(fuente, 26);
    g.textAlign(CENTER, CENTER);
    g.text("OFIX", 145, g.height - 98);
  } else {
    fondoRuido(g, texAluminio, m.chasis, 1);
    g.fill(lerpColor(m.chasis, color(255), 0.05));
    g.quad(0, 0, cx - 60, g.height, cx + 60, g.height, g.width, 0);
    g.fill(lerpColor(m.chasis, color(0), 0.25));
    g.quad(0, 0, 60, 0, cx - 10, g.height - 40, cx - 60, g.height);
    g.quad(g.width - 60, 0, g.width, 0, cx + 60, g.height, cx + 10, g.height - 40);
    g.fill(m.acento);
    g.triangle(cx, cy + 40, cx - 34, cy - 30, cx + 34, cy - 30);
    g.fill(lerpColor(m.chasis, color(0), 0.2));
    g.triangle(cx, cy + 18, cx - 18, cy - 18, cx + 18, cy - 18);
  }
  g.endDraw();
  return g;
}

// hexagono(g, x, y, r) · Hexágono en un lienzo
void hexagono(PGraphics g, float x, float y, float r) {
  g.beginShape();
  for (int i = 0; i < 6; i++)
    g.vertex(x + cos(TWO_PI * i / 6 + PI / 6) * r / 2, y + sin(TWO_PI * i / 6 + PI / 6) * r / 2);
  g.endShape(CLOSE);
}

// ---- Placas de circuito y etiquetas ----
// pintarPCB(w, h, base, semilla, fin) · Placa de circuito con pistas y componentes
PImage pintarPCB(int w, int h, color base, int semilla, boolean fina) {
  randomSeed(semilla);
  PGraphics g = lienzo(w, h);
  fondoRuido(g, texGrano, base, 1);
  color pista = lerpColor(base, color(255), 0.12);
  g.noFill();
  int n = (w * h) / (fina ? 900 : 1300);
  for (int i = 0; i < n; i++) {
    g.stroke(pista);
    g.strokeWeight(random(1) < 0.8 ? 1.2 : 2.6);
    float x = random(w), y = random(h);
    g.beginShape();
    g.vertex(x, y);
    int pasos = 2 + int(random(4));
    for (int k = 0; k < pasos; k++) {
      int dir = int(random(8));
      float l = random(10, 70);
      x += round(cos(dir * QUARTER_PI)) * l;
      y += round(sin(dir * QUARTER_PI)) * l;
      g.vertex(x, y);
    }
    g.endShape();
    g.noStroke();
    g.fill(190, 160, 90);
    g.ellipse(x, y, 4.5, 4.5);
    g.fill(base);
    g.ellipse(x, y, 1.8, 1.8);
    g.noFill();
  }
  g.noStroke();
  g.textFont(fuente, 9);
  for (int i = 0; i < n / 16; i++) {
    float x = random(w - 40), y = random(h - 20), cw = random(8, 30), ch = random(6, 18);
    g.noFill();
    g.stroke(225, 225, 215, 110);
    g.strokeWeight(1);
    g.rect(x, y, cw, ch);
    g.noStroke();
    g.fill(225, 225, 215, 130);
    String[] pre = {"C", "R", "U", "L", "Q", "D"};
    g.text(pre[int(random(pre.length))] + int(random(1, 400)), x, y - 2);
  }
  for (int i = 0; i < n / 5; i++) {
    float x = random(w), y = random(h);
    boolean vertical = random(1) < 0.5;
    float a = vertical ? 3 : 6, b = vertical ? 6 : 3;
    g.fill(random(1) < 0.5 ? color(150, 120, 80) : color(30));
    g.rect(x, y, a, b);
    g.fill(150, 150, 155);
    if (vertical) {
      g.rect(x, y, a, 1.4);
      g.rect(x, y + b - 1.4, a, 1.4);
    } else {
      g.rect(x, y, 1.4, b);
      g.rect(x + a - 1.4, y, 1.4, b);
    }
  }
  float[][] hs = {{0.04, 0.06}, {0.96, 0.06}, {0.04, 0.94}, {0.96, 0.94}};
  for (float[] p : hs) {
    g.fill(200, 165, 90);
    g.ellipse(p[0] * w, p[1] * h, 18, 18);
    g.fill(20);
    g.ellipse(p[0] * w, p[1] * h, 9, 9);
  }
  g.endDraw();
  return g;
}

// pintarModuloRAM(w, h, semilla, escritorio) · Módulo de memoria
PImage pintarModuloRAM(int w, int h, int semilla, boolean escritorio) {
  PImage base = pintarPCB(w, h, color(22, 90, 55), semilla, true);
  PGraphics g = lienzo(w, h);
  g.image(base, 0, 0);
  float paso = (escritorio ? h : w) / 70.0;
  for (int i = 1; i < 69; i++) {
    if (i == (escritorio ? 30 : 38))
      continue;
    g.fill(215, 175, 70);
    if (escritorio)
      g.rect(w - w * 0.1, i * paso, w * 0.1, paso * 0.7);
    else
      g.rect(i * paso, h - h * 0.14, paso * 0.7, h * 0.14);
  }
  g.endDraw();
  return g;
}

// pintarM2() · SSD M.2
PImage pintarM2() {
  PImage base = pintarPCB(320, 88, color(20, 22, 26), 15, true);
  PGraphics g = lienzo(320, 88);
  g.image(base, 0, 0);
  g.fill(215, 175, 70);
  for (int i = 0; i < 30; i++)
    if (i != 7)
      g.rect(320 - 14, 6 + i * 2.6, 14, 1.6);
  g.fill(10);
  g.ellipse(10, 44, 16, 16);
  g.endDraw();
  return g;
}

// pintarChip() · Encapsulado de chip
PImage pintarChip() {
  PGraphics g = lienzo(128, 128);
  fondoRuido(g, texGrano, color(30, 31, 36), 1);
  g.fill(150);
  g.textFont(fuente, 13);
  g.textAlign(LEFT, TOP);
  g.text("TLX 4A7\n2341 KR\nQ8F2", 12, 30);
  g.fill(60);
  g.ellipse(18, 18, 8, 8);
  g.endDraw();
  return g;
}

// etiqueta(w, h, fondo, tinta, tit, ...) · Etiqueta con texto
PImage etiqueta(int w, int h, color fondo, color tinta, String titulo, String linea2, String linea3, color acento) {
  PGraphics g = lienzo(w, h);
  fondoRuido(g, texGrano, fondo, 1);
  g.fill(acento);
  g.rect(0, 0, w, max(4, h * 0.08));
  g.fill(tinta);
  g.textAlign(LEFT, TOP);
  g.textFont(fuente, constrain(h * 0.18, 9, 22));
  g.text(titulo, w * 0.05, h * 0.16);
  g.textFont(fuente, constrain(h * 0.12, 8, 15));
  g.text(linea2, w * 0.05, h * 0.46);
  g.fill(lerpColor(tinta, fondo, 0.3));
  g.text(linea3, w * 0.05, h * 0.7);
  if (h > 60) {
    for (int i = 0; i < 46; i++) {
      g.fill(i % 2 == 0 || random(1) < 0.3 ? tinta : fondo);
      g.rect(w * 0.68 + i * w * 0.006, h * 0.72, w * 0.006, h * 0.2);
    }
  }
  g.endDraw();
  return g;
}

// ---- Cajas con textura ----
// @cajaT(x, h, z, w, a, d, lados, tex, cara) · Caja con textura en una cara (1 arriba, -1 abajo, 2 frente, -2 atrás, 3 der., -3 izq.)
void cajaT(float x, float h, float z, float w, float a, float d, color lados, PImage tex, int cara) {
  cajaT(x, h, z, w, a, d, lados, tex, cara, 0, 0, 1, 1);
}

// cajaT(..., u0, v0, u1, v1) · Igual, con la parte de la textura que se usa; fill() = tint() porque la luz ambiental usa el relleno
void cajaT(float x, float h, float z, float w, float a, float d, color lados, PImage tex, int cara, float u0, float v0, float u1, float v1) {
  pushMatrix();
  translate(x, -h, z);
  noStroke();
  float hw = w / 2, ha = a / 2, hd = d / 2;
  textureMode(NORMAL);
  tint(lados);
  fill(lados);
  material(tex);
  float gu = w / 60, ga = a / 60, gd = d / 60;
  beginShape(QUADS);
  texture(texGrano);
  for (int f = -3; f <= 3; f++)
    if (f != 0 && f != cara)
      caraCaja(f, hw, ha, hd, 0, 0, abs(f) == 3 ? gd : gu, abs(f) == 1 ? gd : ga);
  endShape();
  if (cara != 0) {
    tint(255, alpha(lados));
    fill(255, alpha(lados));
    beginShape(QUADS);
    texture(tex);
    caraCaja(cara, hw, ha, hd, u0, v0, u1, v1);
    endShape();
  }
  noTint();
  popMatrix();
}

// caraCaja(f, hw, ha, hd, u0, v0, u1, v1) · Una cara de la caja con su normal
void caraCaja(int f, float hw, float ha, float hd, float u0, float v0, float u1, float v1) {
  if (f == 1) {
    normal(0, -1, 0);
    vertex(-hw, -ha, -hd, u0, v0);
    vertex(hw, -ha, -hd, u1, v0);
    vertex(hw, -ha, hd, u1, v1);
    vertex(-hw, -ha, hd, u0, v1);
  } else if (f == -1) {
    normal(0, 1, 0);
    vertex(-hw, ha, -hd, u1, v0);
    vertex(hw, ha, -hd, u0, v0);
    vertex(hw, ha, hd, u0, v1);
    vertex(-hw, ha, hd, u1, v1);
  } else if (f == 2) {
    normal(0, 0, 1);
    vertex(-hw, -ha, hd, u0, v0);
    vertex(hw, -ha, hd, u1, v0);
    vertex(hw, ha, hd, u1, v1);
    vertex(-hw, ha, hd, u0, v1);
  } else if (f == -2) {
    normal(0, 0, -1);
    vertex(hw, -ha, -hd, u0, v0);
    vertex(-hw, -ha, -hd, u1, v0);
    vertex(-hw, ha, -hd, u1, v1);
    vertex(hw, ha, -hd, u0, v1);
  } else if (f == 3) {
    normal(1, 0, 0);
    vertex(hw, -ha, hd, u0, v0);
    vertex(hw, -ha, -hd, u1, v0);
    vertex(hw, ha, -hd, u1, v1);
    vertex(hw, ha, hd, u0, v1);
  } else {
    normal(-1, 0, 0);
    vertex(-hw, -ha, -hd, u0, v0);
    vertex(-hw, -ha, hd, u1, v0);
    vertex(-hw, ha, hd, u1, v1);
    vertex(-hw, ha, -hd, u0, v1);
  }
}

// cajaRep(x, h, z, w, a, d, tinte, tex, rep) · Caja con la textura repetida en todas las caras
void cajaRep(float x, float h, float z, float w, float a, float d, color tinte, PImage tex, float rep) {
  pushMatrix();
  translate(x, -h, z);
  noStroke();
  textureMode(NORMAL);
  tint(tinte);
  fill(tinte);
  material(tex);
  float hw = w / 2, ha = a / 2, hd = d / 2;
  beginShape(QUADS);
  texture(tex);
  for (int f = -3; f <= 3; f++)
    if (f != 0)
      caraCaja(f, hw, ha, hd, 0, 0, (abs(f) == 3 ? d : w) / rep, (abs(f) == 1 ? d : a) / rep);
  endShape();
  noTint();
  popMatrix();
}

// @sombra(x, z, w, d, fuerza) · Sombra suave de contacto sobre el tapete
void sombra(float x, float z, float w, float d, float fuerza) {
  if (modoSombra)
    return;
  // con RTX la sombra real es la proyectada: esta queda como sombra de contacto
  if (rtx && rtxDisponible && sombrasRTX)
    fuerza *= 0.6;
  sinLuces();
  noStroke();
  hint(DISABLE_DEPTH_MASK);
  textureMode(NORMAL);
  tint(255, 255 * fuerza);
  beginShape(QUADS);
  texture(texSombra);
  normal(0, -1, 0);
  vertex(x - w / 2, -1.35, z - d / 2, 0, 0);
  vertex(x + w / 2, -1.35, z - d / 2, 1, 0);
  vertex(x + w / 2, -1.35, z + d / 2, 1, 1);
  vertex(x - w / 2, -1.35, z + d / 2, 0, 1);
  endShape();
  noTint();
  hint(ENABLE_DEPTH_MASK);
  restaurarLuces();
}

// fondoEstudio() · Fondo degradado detrás de la escena
void fondoEstudio() {
  hint(DISABLE_DEPTH_TEST);
  camera();
  perspective();
  sinLuces();
  noStroke();
  for (int y = 0; y < height; y += 4) {
    float k = y / (float) height;
    fill(lerpColor(color(46, 50, 60), color(18, 19, 24), pow(k, 0.8)));
    rect(0, y, width, 4);
  }
  hint(ENABLE_DEPTH_TEST);
}
