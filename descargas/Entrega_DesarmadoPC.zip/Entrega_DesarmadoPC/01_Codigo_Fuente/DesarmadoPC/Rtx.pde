// ============================================================
// RTX · iluminación por píxel, sombras proyectadas, luz de LEDs y pantallas
// ============================================================

// ---- Estado ----
PShader rtxShader;
boolean rtx = true, rtxDisponible = false, sombrasRTX = true;
boolean modoSombra = false;
float alfaSombra = 0;
color colorPantalla = color(120, 160, 220);

// @prepararRTX() · Carga data/shaders y los prueba; si la tarjeta no los acepta sigue con la iluminación clásica
void prepararRTX() {
  try {
    rtxShader = loadShader("shaders/rtx.frag", "shaders/rtx.vert");
    if (rtxShader == null)
      throw new RuntimeException("no se encontraron los shaders en data/shaders");
    pushMatrix();
    lights();
    shader(rtxShader);
    noStroke();
    textureMode(NORMAL);
    beginShape(QUADS);
    texture(texGrano);
    normal(0, 0, 1);
    vertex(0, 0, 0, 0, 0);
    vertex(1, 0, 0, 1, 0);
    vertex(1, 1, 0, 1, 1);
    vertex(0, 1, 0, 0, 1);
    endShape();
    flush();
    resetShader();
    noLights();
    popMatrix();
    rtxDisponible = true;
  }
  catch (Exception ex) {
    rtxDisponible = false;
    rtx = false;
    println("RTX no disponible, se usa la iluminación clásica: " + ex.getMessage());
  }
}

// alternarRTX() · Tecla X: cambia entre RTX y la iluminación clásica de Processing
void alternarRTX() {
  if (!rtxDisponible) {
    avisar("Tu tarjeta de video no aceptó los shaders RTX: se usa la iluminación clásica", AVISO);
    return;
  }
  rtx = !rtx;
  avisar(rtx ? "Iluminación RTX: luz por píxel, brillos, rebote de luz y sombras reales" : "Iluminación clásica de Processing (por vértice)", INFO);
}

// @activarRTX() · Pone el shader y le pasa los uniforms del entorno (lo llama luces())
void activarRTX() {
  if (!rtx || !rtxDisponible || modoSombra || matVista == null)
    return;
  PVector o = matVista.mult(new PVector(0, 0, 0), null), u = matVista.mult(new PVector(0, -1, 0), null);
  rtxShader.set("arriba", u.x - o.x, u.y - o.y, u.z - o.z);
  color cielo = colorTemperatura(min(1, luzTemp + 0.15));
  float a = luzAmbiente, k = luzFuerza;
  rtxShader.set("colorCielo", red(cielo) / 255 * 0.34 * a, green(cielo) / 255 * 0.34 * a, blue(cielo) / 255 * 0.36 * a);
  rtxShader.set("colorSuelo", 0.30 * (0.4 * a + 0.6 * k), 0.20 * (0.4 * a + 0.6 * k), 0.13 * (0.4 * a + 0.6 * k));
  rtxShader.set("fuerzaRebote", 0.9);
  rtxShader.set("fuerzaEspecular", 0.9);
  rtxShader.set("fuerzaFresnel", 0.55);
  rtxShader.set("exposicion", 1.05);
  shader(rtxShader);
}

// sinRTX() · Quita el shader antes de dibujar algo con brillo propio
void sinRTX() {
  if (rtxDisponible)
    resetShader();
}

// @material(tex) · Brillo especular según la superficie: metal, madera, tapete o plástico
void material(PImage tex) {
  if (tex == texCepillado || tex == texCobre) {
    specular(190);
    shininess(48);
  } else if (tex == texAluminio || tex == texMadera) {
    specular(95);
    shininess(26);
  } else if (tex == texTapete) {
    specular(20);
    shininess(6);
  } else {
    specular(55);
    shininess(14);
  }
}

// ---- Luces extra: LEDs y pantallas ----

// @lucesDeEquipo(usadas) · Los LEDs RGB o la pantalla encendida iluminan lo que tienen cerca (máx. 8 luces)
void lucesDeEquipo(int usadas) {
  if (usadas >= 8 || modo != TALLER)
    return;
  Equipo e = equipo;
  Modelo m = e.modelo;
  boolean deDia = e.laptop && e.enUso && e.volteo > 0.95;
  if (deDia && m.rgb && e.brilloLed > 0.05 && modoLuz != L_APAGADA) {
    color c = colorLed(e, SEGMENTOS / 2, SEGMENTOS, false);
    float k = 1.6 * e.brilloLed;
    float zl = m.estilo == 3 ? m.D / 2 + 40 : -m.D / 2 - 40;
    lightFalloff(1, 0.006, 0.00003);
    pointLight(red(c) * k, green(c) * k, blue(c) * k, 0, -m.H * 0.3, zl);
    lightFalloff(1, 0, 0);
  } else if (monitor.hayImagen()) {
    float k = 0.85;
    lightFalloff(1, 0.0025, 0.00001);
    if (e.laptop && deDia) {
      float a = e.aperturaTapa(), hd = m.D / 2;
      pointLight(red(colorPantalla) * k, green(colorPantalla) * k, blue(colorPantalla) * k,
        0, -(m.H + hd * sin(a)) + 90 * cos(a), -hd + hd * cos(a) + 90 * sin(a));
    } else if (!e.laptop)
      pointLight(red(colorPantalla) * k, green(colorPantalla) * k, blue(colorPantalla) * k, 427, -285, -135);
    lightFalloff(1, 0, 0);
  }
}

// actualizarColorPantalla() · Promedio del color de la pantalla cada 20 cuadros
void actualizarColorPantalla() {
  if (frameCount % 20 != 0 || !monitor.hayImagen())
    return;
  PImage img = monitor.imagen();
  img.loadPixels();
  if (img.pixels == null || img.pixels.length == 0)
    return;
  float r = 0, g = 0, b = 0;
  int n = 0;
  for (int y = 1; y < 5; y++)
    for (int x = 1; x < 5; x++) {
      color c = img.pixels[(y * img.height / 5) * img.width + x * img.width / 5];
      r += red(c);
      g += green(c);
      b += blue(c);
      n++;
    }
  colorPantalla = color(r / n, g / n, b / n);
}

// ---- Sombras proyectadas ----

// @dibujarSombrasRTX(e, conMesa) · Proyecta el equipo sobre la mesa desde la luz principal
void dibujarSombrasRTX(Equipo e, boolean conMesa) {
  if (!rtx || !sombrasRTX)
    return;
  float[] L = dirLuz();
  if (L[1] < 0.18)
    return;
  float y0 = -1.45;
  alfaSombra = 160 * constrain(luzFuerza / 1.2, 0, 1) * (1 - 0.35 * constrain(luzAmbiente - 0.6, 0, 1)) * constrain((L[1] - 0.18) * 4, 0, 1);
  if (alfaSombra < 4)
    return;
  sinRTX();
  noLights();
  empezarStencil();
  hint(DISABLE_DEPTH_MASK);
  modoSombra = true;
  pushMatrix();
  // matriz de proyección sobre el plano y = y0 en la dirección de la luz
  applyMatrix(1, -L[0] / L[1], 0, y0 * L[0] / L[1],
    0, 0, 0, y0,
    0, -L[2] / L[1], 1, y0 * L[2] / L[1],
    0, 0, 0, 1);
  dibujarEquipo(e, null);
  dibujarPiezasFuera(e, null);
  if (conMesa) {
    if (e.laptop)
      dibujarCargador();
    else
      dibujarMonitor(e);
  }
  popMatrix();
  modoSombra = false;
  hint(ENABLE_DEPTH_MASK);
  terminarStencil();
  restaurarLuces();
}

// @empezarStencil() · Esténcil: cada píxel de sombra se oscurece una sola vez
void empezarStencil() {
  PGL pgl = beginPGL();
  pgl.clearStencil(0);
  pgl.clear(PGL.STENCIL_BUFFER_BIT);
  pgl.enable(PGL.STENCIL_TEST);
  pgl.stencilFunc(PGL.EQUAL, 0, 0xFF);
  pgl.stencilOp(PGL.KEEP, PGL.KEEP, PGL.INCR);
  endPGL();
}

// terminarStencil() · Apaga la prueba de esténcil
void terminarStencil() {
  PGL pgl = beginPGL();
  pgl.disable(PGL.STENCIL_TEST);
  endPGL();
}

// ---- Color durante la pasada de sombra ----
// fill(), tint() y stroke() · En la pasada de sombra todo se pinta negro translúcido

// fill(c) · En la pasada de sombra pinta negro translúcido
public void fill(int c) {
  if (modoSombra) super.fill(0, alfaSombra);
  else super.fill(c);
}
// fill(c, a) · Igual, con alfa
public void fill(int c, float a) {
  if (modoSombra) super.fill(0, alfaSombra);
  else super.fill(c, a);
}
// fill(v) · Igual, en gris
public void fill(float v) {
  if (modoSombra) super.fill(0, alfaSombra);
  else super.fill(v);
}
// fill(v, a) · Igual, en gris con alfa
public void fill(float v, float a) {
  if (modoSombra) super.fill(0, alfaSombra);
  else super.fill(v, a);
}
// fill(r, g, b) · Igual, en RGB
public void fill(float r, float g, float b) {
  if (modoSombra) super.fill(0, alfaSombra);
  else super.fill(r, g, b);
}
// fill(r, g, b, a) · Igual, en RGBA
public void fill(float r, float g, float b, float a) {
  if (modoSombra) super.fill(0, alfaSombra);
  else super.fill(r, g, b, a);
}
// tint(c) · En la pasada de sombra tiñe las texturas de negro translúcido
public void tint(int c) {
  if (modoSombra) super.tint(0, alfaSombra);
  else super.tint(c);
}
// tint(c, a) · Igual, con alfa
public void tint(int c, float a) {
  if (modoSombra) super.tint(0, alfaSombra);
  else super.tint(c, a);
}
// tint(v) · Igual, en gris
public void tint(float v) {
  if (modoSombra) super.tint(0, alfaSombra);
  else super.tint(v);
}
// tint(v, a) · Igual, en gris con alfa
public void tint(float v, float a) {
  if (modoSombra) super.tint(0, alfaSombra);
  else super.tint(v, a);
}
// tint(r, g, b) · Igual, en RGB
public void tint(float r, float g, float b) {
  if (modoSombra) super.tint(0, alfaSombra);
  else super.tint(r, g, b);
}
// tint(r, g, b, a) · Igual, en RGBA
public void tint(float r, float g, float b, float a) {
  if (modoSombra) super.tint(0, alfaSombra);
  else super.tint(r, g, b, a);
}
// stroke(c) · En la pasada de sombra las líneas también son sombra
public void stroke(int c) {
  if (modoSombra) super.stroke(0, alfaSombra);
  else super.stroke(c);
}
// stroke(c, a) · Igual, con alfa
public void stroke(int c, float a) {
  if (modoSombra) super.stroke(0, alfaSombra);
  else super.stroke(c, a);
}
// stroke(v) · Igual, en gris
public void stroke(float v) {
  if (modoSombra) super.stroke(0, alfaSombra);
  else super.stroke(v);
}
// stroke(v, a) · Igual, en gris con alfa
public void stroke(float v, float a) {
  if (modoSombra) super.stroke(0, alfaSombra);
  else super.stroke(v, a);
}
// stroke(r, g, b) · Igual, en RGB
public void stroke(float r, float g, float b) {
  if (modoSombra) super.stroke(0, alfaSombra);
  else super.stroke(r, g, b);
}
// stroke(r, g, b, a) · Igual, en RGBA
public void stroke(float r, float g, float b, float a) {
  if (modoSombra) super.stroke(0, alfaSombra);
  else super.stroke(r, g, b, a);
}
