// ============================================================
// ILUMINACIÓN INTERACTIVA · ambientes, domo, linterna, luz de aro y lámpara de trabajo
// ============================================================

// ---- Estado ----
float luzFuerza = 1, luzAmbiente = 1, luzTemp = 0.5;
float luzGiro = 0.675, luzAltura = 0.93;
boolean linterna = false, luzAro = false, panelLuz = false, luzTrabajo = true;
int presetLuz = 0, controlLuz = -1;
String[] PRESETS_LUZ = {"Estudio", "Taller", "Atardecer", "Noche", "Exposición"};
float PANEL_LUZ_W = 284, PANEL_LUZ_H = 530;

// panelLuzX() · Posición x del panel de iluminación
float panelLuzX() {
  return width - 320 - PANEL_LUZ_W - 10;
}
// panelLuzY() · Posición y del panel de iluminación
float panelLuzY() {
  return 56;
}

// sobrePanelLuz(x, y) · true si el mouse está sobre el panel
boolean sobrePanelLuz(float x, float y) {
  return panelLuz && x > panelLuzX() && x < panelLuzX() + PANEL_LUZ_W && y > panelLuzY() && y < panelLuzY() + PANEL_LUZ_H;
}

// @aplicarPreset(i) · Ambientes: Estudio, Taller, Atardecer, Noche y Exposición
void aplicarPreset(int i) {
  presetLuz = i;
  float[][] p = {
    {1.0, 1.0, 0.5, 0.675, 0.93, 0},
    {1.12, 1.15, 0.66, 0.2, 1.4, 0},
    {0.95, 0.6, 0.04, 1.9, 0.28, 0},
    {0.12, 0.3, 0.85, 0.6, 0.9, 0},
    {1.35, 0.45, 0.5, -0.6, 1.15, 1}};
  luzFuerza = p[i][0];
  luzAmbiente = p[i][1];
  luzTemp = p[i][2];
  luzGiro = p[i][3];
  luzAltura = p[i][4];
  luzAro = p[i][5] > 0;
  if (i == 3 && !linterna)
    avisar("Ambiente de noche: prueba la linterna (tecla T) o enciende el equipo para ver sus luces", INFO);
}

// colorTemperatura(t) · Color de la luz de cálida (0) a fría (1)
color colorTemperatura(float t) {
  color calida = color(255, 178, 110), neutra = color(255, 246, 236), fria = color(196, 218, 255);
  return t < 0.5 ? lerpColor(calida, neutra, t * 2) : lerpColor(neutra, fria, (t - 0.5) * 2);
}

// @dirLuz() · Dirección de la luz principal según el giro y la altura del domo
float[] dirLuz() {
  float fx = cos(luzAltura) * sin(luzGiro), fh = sin(luzAltura), fz = cos(luzAltura) * cos(luzGiro);
  return new float[] {-fx, fh, -fz};
}

// ---- Luces de la escena ----
// @luces() · Luces de cada cuadro: ambiental, 3 direccionales, lámpara, aro, linterna, LEDs/pantalla y shader RTX
void luces() {
  color ct = colorTemperatura(luzTemp);
  float a = luzAmbiente, k = luzFuerza;
  // con RTX parte de la luz ambiental la aporta el rebote del shader
  float amb = rtx && rtxDisponible ? 0.55 : 1;
  ambientLight(86 * a * amb, 88 * a * amb, 96 * a * amb);
  float[] d = dirLuz();
  directionalLight(red(ct) * 0.8 * k, green(ct) * 0.8 * k, blue(ct) * 0.8 * k, d[0], d[1], d[2]);
  directionalLight(58 * a, 68 * a, 90 * a, -d[0] * 0.8, 0.35, -d[2] * 0.8);
  directionalLight(46 * k, 48 * k, 58 * k, 0.1, 0.35, -1);
  if (modo != TALLER) {
    activarRTX();
    return;
  }
  int usadas = 4;
  if (luzTrabajo) {
    usadas++;
    Modelo m = equipo.modelo;
    color cw = colorTemperatura(min(1, luzTemp + 0.1));
    float kw = 0.75 + 0.25 * luzFuerza;
    lightFalloff(1, 0.0011, 0);
    if (equipo.laptop)
      pointLight(red(cw) * 0.75 * kw, green(cw) * 0.75 * kw, blue(cw) * 0.75 * kw, -m.W * 0.2, -330, m.D * 0.9);
    else
      pointLight(red(cw) * 1.3 * kw, green(cw) * 1.3 * kw, blue(cw) * 1.3 * kw, m.W * 0.12, -m.H * 0.72, m.D / 2 + 240);
    lightFalloff(1, 0, 0);
  }
  if (luzAro) {
    usadas++;
    lightFalloff(1, 0, 0);
    pointLight(105, 105, 110, cam.ex, -cam.eh, cam.ez);
  }
  if (linterna) {
    usadas++;
    float[] r = cam.rayo(mouseX, mouseY);
    lightFalloff(1, 0.00025, 0.0000005);
    spotLight(400, 390, 360, cam.ex, -cam.eh, cam.ez, r[3], -r[4], r[5], PI / 10, 14);
    lightFalloff(1, 0, 0);
  }
  lucesDeEquipo(usadas);
  activarRTX();
}

// dibujarIndicadorLuz() · Sol y línea punteada que marcan de dónde viene la luz principal
void dibujarIndicadorLuz() {
  if (!panelLuz)
    return;
  float fx = cos(luzAltura) * sin(luzGiro), fh = sin(luzAltura), fz = cos(luzAltura) * cos(luzGiro);
  float r = equipo.laptop ? 650 : 900;
  sinLuces();
  color ct = colorTemperatura(luzTemp);
  stroke(red(ct), green(ct), blue(ct), 90);
  strokeWeight(1.5);
  for (int i = 0; i < 20; i += 2)
    line(fx * r * i / 20, -fh * r * i / 20 - 60, fz * r * i / 20, fx * r * (i + 1) / 20, -fh * r * (i + 1) / 20 - 60, fz * r * (i + 1) / 20);
  noStroke();
  pushMatrix();
  translate(fx * r, -fh * r - 60, fz * r);
  fill(ct);
  sphere(16);
  fill(red(ct), green(ct), blue(ct), 60);
  sphere(28);
  popMatrix();
  restaurarLuces();
}

// ---- Panel ----
// mousePresionadoLuz() · Detecta qué control del panel se tomó (domo o deslizadores)
void mousePresionadoLuz() {
  controlLuz = -1;
  if (!panelLuz || !sobrePanelLuz(mouseX, mouseY))
    return;
  float x = panelLuzX(), y = panelLuzY();
  if (dist(mouseX, mouseY, x + 72, y + 178) < 64)
    controlLuz = 0;
  for (int i = 0; i < 3; i++)
    if (mouseY > y + 264 + i * 46 && mouseY < y + 294 + i * 46 && mouseX > x + 14 && mouseX < x + PANEL_LUZ_W - 14)
      controlLuz = 1 + i;
}

// @dibujarPanelLuz() · Panel 2D: ambientes, domo, intensidad, ambiente, temperatura y botones de luces y RTX
void dibujarPanelLuz() {
  if (!panelLuz)
    return;
  float x = panelLuzX(), y = panelLuzY(), w = PANEL_LUZ_W;
  if (mousePressed && controlLuz >= 0) {
    if (controlLuz == 0) {
      float dx = mouseX - (x + 72), dy = mouseY - (y + 178);
      float rr = constrain(dist(0, 0, dx, dy) / 58, 0, 1);
      luzGiro = atan2(dx, dy);
      luzAltura = HALF_PI * (1 - rr) * 0.98 + 0.05;
    } else {
      float v = constrain((mouseX - (x + 16)) / (w - 32), 0, 1);
      if (controlLuz == 1)
        luzFuerza = v * 1.6;
      else if (controlLuz == 2)
        luzAmbiente = v * 1.6;
      else
        luzTemp = v;
    }
    presetLuz = -1;
  }
  noStroke();
  fill(20, 24, 32, 238);
  rect(x, y, w, PANEL_LUZ_H, 8);
  fill(240);
  textAlign(LEFT, CENTER);
  textSize(14);
  text("Iluminación", x + 12, y + 16);
  if (ui.boton("×", x + w - 34, y + 5, 24, 22, false, 0))
    panelLuz = false;
  for (int i = 0; i < PRESETS_LUZ.length; i++) {
    float bx = x + 10 + (i % 3) * 89, by = y + 36 + (i / 3) * 30;
    if (ui.boton(PRESETS_LUZ[i], bx, by, 85, 26, presetLuz == i, color(255, 205, 80)))
      aplicarPreset(i);
  }
  float cx = x + 72, cy = y + 178;
  fill(12, 15, 22);
  ellipse(cx, cy, 124, 124);
  noFill();
  stroke(255, 40);
  ellipse(cx, cy, 80, 80);
  ellipse(cx, cy, 40, 40);
  line(cx - 62, cy, cx + 62, cy);
  line(cx, cy - 62, cx, cy + 62);
  noStroke();
  fill(150);
  textSize(10);
  textAlign(CENTER, CENTER);
  text("atrás", cx, cy - 70);
  text("frente", cx, cy + 70);
  float rr = (1 - (luzAltura - 0.05) / (HALF_PI * 0.98)) * 58;
  float px = cx + sin(luzGiro) * rr, py = cy + cos(luzGiro) * rr;
  color ct = colorTemperatura(luzTemp);
  fill(red(ct), green(ct), blue(ct), 70);
  ellipse(px, py, 26, 26);
  fill(ct);
  ellipse(px, py, 13, 13);
  fill(220);
  textAlign(LEFT, TOP);
  textSize(12);
  text("Arrastra el punto\npara mover la luz\nprincipal.", x + 150, y + 126);
  fill(170);
  text("Giro: " + round(degrees(luzGiro)) + "°\nAltura: " + round(degrees(luzAltura)) + "°", x + 150, y + 184);
  String[] nombres = {"Intensidad", "Luz ambiental", "Temperatura"};
  float[] valores = {luzFuerza / 1.6, luzAmbiente / 1.6, luzTemp};
  String[] textos = {round(luzFuerza * 100) + " %", round(luzAmbiente * 100) + " %", luzTemp < 0.35 ? "cálida" : (luzTemp > 0.65 ? "fría" : "neutra")};
  for (int i = 0; i < 3; i++) {
    float sy = y + 264 + i * 46;
    fill(220);
    textAlign(LEFT, BOTTOM);
    text(nombres[i], x + 16, sy + 8);
    textAlign(RIGHT, BOTTOM);
    fill(170);
    text(textos[i], x + w - 16, sy + 8);
    float by = sy + 16;
    if (i == 2) {
      for (int k = 0; k < w - 32; k += 2) {
        fill(colorTemperatura(k / (w - 32)));
        rect(x + 16 + k, by - 3, 2, 6);
      }
    } else {
      fill(60, 66, 80);
      rect(x + 16, by - 3, w - 32, 6, 3);
      fill(255, 205, 80);
      rect(x + 16, by - 3, (w - 32) * valores[i], 6, 3);
    }
    fill(255);
    ellipse(x + 16 + (w - 32) * valores[i], by, 14, 14);
  }
  if (ui.boton("T Linterna", x + 10, y + 406, 86, 28, linterna, color(255, 235, 150)))
    linterna = !linterna;
  if (ui.boton("O Aro", x + 99, y + 406, 86, 28, luzAro, color(200, 220, 255)))
    luzAro = !luzAro;
  if (ui.boton("K Trabajo", x + 188, y + 406, 86, 28, luzTrabajo, color(255, 215, 160)))
    luzTrabajo = !luzTrabajo;
  fill(150);
  textAlign(LEFT, TOP);
  textSize(11);
  text("Linterna: sigue al mouse · Aro: luz desde la cámara · Trabajo: lámpara que alumbra el interior.", x + 12, y + 438, w - 24, 30);
  if (ui.boton("X RTX", x + 10, y + 474, 131, 28, rtx, color(120, 230, 160)))
    alternarRTX();
  if (ui.boton("Sombras", x + 144, y + 474, 130, 28, sombrasRTX && rtx, color(170, 190, 255)) && rtx)
    sombrasRTX = !sombrasRTX;
  fill(150);
  textSize(11);
  text(rtxDisponible ? "RTX: luz por píxel, brillos, rebote y sombras" : "RTX no disponible en esta tarjeta de video", x + 12, y + 506, w - 24, 20);
}
