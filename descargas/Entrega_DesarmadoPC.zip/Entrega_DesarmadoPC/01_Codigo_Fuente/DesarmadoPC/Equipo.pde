// ============================================================
// EQUIPO · reglas para quitar y poner piezas, volteo de la laptop y selección con el mouse
// ============================================================

// ---- Constantes ----
final static int OBJ_PIEZA = 0;
final static int OBJ_TORNILLO = 1;
final static int OBJ_CONECTOR = 2;
final static int OBJ_BANDEJA = 3;

final static int PASTA_BUENA = 0;
final static int PASTA_VIEJA = 1;
final static int PASTA_LIMPIA = 2;
final static int PASTA_NUEVA = 3;

// class Objetivo · Lo que está bajo el mouse: tornillo, conector, pieza o lugar en la mesa
class Objetivo {
  int tipo;
  Pieza p;
  Tornillo t;
  Conector c;
  float dist;
  Objetivo(int tipo, Pieza p, Tornillo t, Conector c, float dist) {
    this.tipo = tipo;
    this.p = p;
    this.t = t;
    this.c = c;
    this.dist = dist;
  }
}

// ---- Equipo ----
// @class Equipo · Estado de un equipo y reglas para quitar y poner piezas
class Equipo {
  String nombre;
  Modelo modelo;
  boolean laptop;
  ArrayList<Pieza> piezas = new ArrayList<Pieza>();
  ArrayList<Conector> conectores = new ArrayList<Conector>();
  HashMap<String, Pieza> porId = new HashMap<String, Pieza>();
  HashMap<String, String[]> bases = new HashMap<String, String[]>();
  String[] orden = {};
  int pasta = PASTA_BUENA;
  boolean encendido = false;
  boolean demoLuces = false, ledActivo = false;
  float brilloLed = 0;
  int inicioLed = 0;

  float volteo = 0;
  boolean enUso = false;

  Equipo(String nombre, boolean laptop) {
    this.nombre = nombre;
    this.laptop = laptop;
  }

  // agregar(p) · Registra una pieza
  Pieza agregar(Pieza p) {
    piezas.add(p);
    porId.put(p.id, p);
    return p;
  }

  // agregar(c) · Registra un conector
  Conector agregar(Conector c) {
    conectores.add(c);
    return c;
  }

  // base(id, b...) · Piezas sobre las que se apoya id (para saber dónde se coloca)
  void base(String id, String... b) {
    bases.put(id, b);
  }

  // pieza(id) · Busca una pieza por su id
  Pieza pieza(String id) {
    return porId.get(id);
  }

  // puesta(id) · true si la pieza está instalada y quieta
  boolean puesta(String id) {
    if (id.equals(""))
      return true;
    Pieza p = porId.get(id);
    return p != null && p.instalada && p.enReposo();
  }

  // libre(ids) · true si ya se quitaron todas las piezas que estorban
  boolean libre(String[] ids) {
    for (String r : ids) {
      Pieza q = porId.get(r);
      if (q != null && q.instalada)
        return false;
    }
    return true;
  }

  // trabajando() · true si se puede trabajar (PC siempre; laptop boca abajo)
  boolean trabajando() {
    return !laptop || (volteo == 0 && !enUso);
  }

  // accesible(p) · true si la pieza se puede tocar ahora
  boolean accesible(Pieza p) {
    return trabajando() && p.instalada && p.enReposo() && libre(p.requiere);
  }

  // conectorAccesible(c) · true si el cable se puede conectar o desconectar ahora
  boolean conectorAccesible(Conector c) {
    if (!puesta(c.duenio) || !puesta(c.destino))
      return false;
    if (c.id.equals("cargador") || c.id.equals("corriente"))
      return volteo == 0 || volteo == 1;
    return trabajando() && libre(c.requiere);
  }

  // ---- Reglas ----
  // @razonNoQuitar(p) · Por qué no se puede quitar la pieza (null = sí se puede)
  String razonNoQuitar(Pieza p) {
    if (!p.removible)
      return p.nombre + " no se quita: " + p.comoQuitar;
    if (encendido)
      return "Apaga el equipo antes de quitar piezas";
    for (String r : p.requiere)
      if (porId.get(r).instalada)
        return "Primero quita: " + porId.get(r).nombre;
    int n = p.tornillosPuestos();
    if (n > 0)
      return "Faltan " + n + (n == 1 ? " tornillo" : " tornillos") + " (usa el destornillador)";
    for (Conector c : conectores)
      if (c.conectado && (c.duenio.equals(p.id) || c.destino.equals(p.id)))
        return "Desconecta primero: " + c.nombre;
    if (p.herramienta == PUA && herramienta != PUA)
      return "Usa la púa de plástico (tecla 3) para liberar los clips";
    return null;
  }

  // @razonNoPoner(p) · Por qué no se puede colocar la pieza (null = sí se puede)
  String razonNoPoner(Pieza p) {
    if (encendido)
      return "Apaga el equipo antes de colocar piezas";
    if (!trabajando())
      return "Voltea la laptop boca abajo para trabajar (tecla V)";
    for (String r : p.requiere)
      if (porId.get(r).instalada)
        return "Para colocarla, primero quita: " + porId.get(r).nombre;
    String[] b = bases.get(p.id);
    if (b != null)
      for (String r : b)
        if (!porId.get(r).instalada)
          return "Primero coloca: " + porId.get(r).nombre;
    return null;
  }

  // @quitar(p) · Manda la pieza a la mesa con animación (separar el disipador estropea la pasta)
  void quitar(Pieza p) {
    float[] m = localAMundo(p.x, p.h, p.z);
    p.sx = m[0];
    p.sh = m[1];
    p.sz = m[2];
    p.instalada = false;
    p.haciaBandeja = true;
    p.anim = 0;
    if (p.tipo == T_DISIPADOR_LAPTOP || p.tipo == T_COOLER) {
      if (pasta == PASTA_BUENA || pasta == PASTA_NUEVA) {
        pasta = PASTA_VIEJA;
        avisar("Al separar el disipador la pasta térmica se rompe: límpiala y aplica nueva (tecla 4)", AVISO);
      }
    }
    if (p.tipo == T_CPU)
      pasta = PASTA_LIMPIA;
  }

  // @poner(p) · Regresa la pieza de la mesa a su lugar con animación
  void poner(Pieza p) {
    float[] t = posBandeja(p);
    p.sx = t[0];
    p.sh = t[1];
    p.sz = t[2];
    p.instalada = true;
    p.haciaBandeja = false;
    p.anim = 0;
    for (Tornillo s : p.tornillos) {
      s.puesto = false;
      s.anim = 0;
    }
  }

  // posBandeja(p) · Posición de la pieza en la mesa
  float[] posBandeja(Pieza p) {
    return new float[] {p.bx, p.tamBandeja()[1] / 2 + 1, p.bz};
  }

  // retiradas() · Cuántas piezas están fuera
  int retiradas() {
    int n = 0;
    for (Pieza p : piezas)
      if (p.removible && !p.instalada)
        n++;
    return n;
  }

  // removibles() · Cuántas piezas se pueden quitar
  int removibles() {
    int n = 0;
    for (Pieza p : piezas)
      if (p.removible)
        n++;
    return n;
  }

  // ---- Animación ----
  // @actualizar() · Animación de piezas, del volteo y de la tapa en cada cuadro
  void actualizar() {
    for (Pieza p : piezas) {
      if (p.anim < 1)
        p.anim = min(1, p.anim + 0.025);
      for (Tornillo t : p.tornillos)
        if (t.anim > 0)
          t.anim = max(0, t.anim - 0.06);
    }
    if (laptop) {
      float meta = enUso ? 1 : 0;
      if (volteo != meta)
        volteo = abs(meta - volteo) < 0.012 ? meta : volteo + (meta > volteo ? 0.012 : -0.012);
      Pieza cpu = porId.get("cpu");
      if (cpu != null)
        cpu.instalada = porId.get("placa").instalada;
    }
  }

  // ---- Volteo y apertura de la laptop ----
  // anguloVolteo() · Ángulo de giro de la laptop al voltearla
  float anguloVolteo() {
    float s = constrain(volteo / 0.6, 0, 1);
    return PI * (1 - s * s * (3 - 2 * s));
  }
  // elevacion() · Altura a la que sube la laptop mientras se voltea
  float elevacion() {
    float s = constrain(volteo / 0.6, 0, 1);
    return sin(PI * s) * 110;
  }
  // aperturaTapa() · Ángulo de la tapa abierta (radianes)
  float aperturaTapa() {
    float s = constrain((volteo - 0.6) / 0.4, 0, 1);
    return radians(112) * s * s * (3 - 2 * s);
  }

  // @transformar() · Aplica translate() y rotateZ() del volteo de la laptop
  void transformar() {
    if (!laptop)
      return;
    translate(0, -13 - elevacion(), 0);
    rotateZ(-anguloVolteo());
    translate(0, 13, 0);
  }

  // localAMundo(x, h, z) · Convierte coordenadas del equipo a coordenadas del mundo
  float[] localAMundo(float x, float h, float z) {
    if (!laptop)
      return new float[] {x, h, z};
    float a = anguloVolteo();
    float rx = x * cos(a) - (h - 13) * sin(a);
    float rh = 13 + x * sin(a) + (h - 13) * cos(a) + elevacion();
    return new float[] {rx, rh, z};
  }

  // rayoALocal(r) · Convierte el rayo del mouse a coordenadas del equipo
  float[] rayoALocal(float[] r) {
    if (!laptop)
      return r;
    float a = -anguloVolteo();
    float ox = r[0], oh = r[1] - elevacion() - 13;
    return new float[] {ox * cos(a) - oh * sin(a), 13 + ox * sin(a) + oh * cos(a), r[2],
      r[3] * cos(a) - r[4] * sin(a), r[3] * sin(a) + r[4] * cos(a), r[5]};
  }

  // ---- Selección con el mouse ----
  // @buscar(rm) · Lo más cercano que toca el rayo: tornillos, conectores, piezas o mesa
  Objetivo buscar(float[] rm) {
    Objetivo mejor = null;
    float[] rl = rayoALocal(rm);
    boolean quieto = !laptop || volteo == 0 || volteo == 1;
    if (quieto) {
      HashMap<Pieza, Objetivo> tornilloDe = new HashMap<Pieza, Objetivo>();
      for (Pieza p : piezas) {
        if (!accesible(p))
          continue;
        for (Tornillo t : p.tornillos) {
          float d = rayoCaja(rl, t.x + t.nx * 2, t.h + t.nh * 2, t.z + t.nz * 2, 10, 10, 10);
          if (d < 0)
            continue;
          Objetivo o = new Objetivo(OBJ_TORNILLO, p, t, null, d - 8);
          if (tornilloDe.get(p) == null || o.dist < tornilloDe.get(p).dist)
            tornilloDe.put(p, o);
          if (mejor == null || o.dist < mejor.dist)
            mejor = o;
        }
      }
      for (Conector c : conectores) {
        if (!conectorAccesible(c))
          continue;
        float s = c.separacion();
        float d = rayoCaja(rl, c.x + c.nx * s, c.h + c.nh * s, c.z + c.nz * s, c.w + 6, c.alto + 6, c.d + 6);
        if (d >= 0 && (mejor == null || d - 8 < mejor.dist))
          mejor = new Objetivo(OBJ_CONECTOR, null, null, c, d - 8);
      }
      for (Pieza p : piezas) {
        if (!accesible(p))
          continue;
        float d = rayoCaja(rl, p.x, p.h, p.z, p.w, p.alto, p.d);
        if (d >= 0 && (mejor == null || d < mejor.dist))
          mejor = new Objetivo(OBJ_PIEZA, p, null, null, d);
      }
      if (mejor != null && mejor.tipo == OBJ_PIEZA && herramienta == DESTORNILLADOR && tornilloDe.get(mejor.p) != null)
        mejor = tornilloDe.get(mejor.p);
    }
    for (Pieza p : piezas) {
      if (p.instalada || !p.enReposo() || !p.removible)
        continue;
      float[] b = posBandeja(p), s = p.tamBandeja();
      float d = rayoCaja(rm, b[0], b[1], b[2], s[0] + 6, s[1] + 6, s[2] + 6);
      if (d >= 0 && (mejor == null || d < mejor.dist))
        mejor = new Objetivo(OBJ_BANDEJA, p, null, null, d);
    }
    return mejor;
  }

  // ---- Acciones del clic ----
  // @usar(o) · Acción del clic según la herramienta y lo que está bajo el mouse
  void usar(Objetivo o) {
    if (o == null)
      return;
    if (o.tipo == OBJ_TORNILLO)
      usarEnTornillo(o.p, o.t);
    else if (o.tipo == OBJ_CONECTOR)
      usarEnConector(o.c);
    else if (o.tipo == OBJ_BANDEJA)
      intentarPoner(o.p);
    else
      usarEnPieza(o.p);
  }

  // usarEnTornillo(p, t) · Quita o pone un tornillo con el destornillador
  void usarEnTornillo(Pieza p, Tornillo t) {
    if (herramienta != DESTORNILLADOR) {
      avisar("Para los tornillos usa el destornillador (tecla 2)", INFO);
      return;
    }
    if (encendido) {
      avisar("Apaga el equipo antes de usar el destornillador", ERROR_);
      return;
    }
    t.puesto = !t.puesto;
    t.anim = 1;
    sonido(t.puesto ? "atornillar" : "desatornillar");
    if (!t.puesto && p.tornillosPuestos() == 0)
      avisar(p.nombre + ": sin tornillos. " + (p.herramienta == PUA ? "Ahora usa la púa." : "Ya puedes retirarla con la mano."), BIEN);
    else if (t.puesto && p.tornillosPuestos() == p.tornillos.size())
      avisar(p.nombre + ": todos los tornillos puestos", BIEN);
  }

  // usarEnConector(c) · Conecta o desconecta un cable con la mano
  void usarEnConector(Conector c) {
    if (herramienta != MANO) {
      avisar("Los cables se conectan y desconectan con la mano (tecla 1)", INFO);
      return;
    }
    boolean energia = c.id.equals("cargador") || c.id.equals("corriente") || c.id.equals("bateria");
    if (encendido && !energia) {
      avisar("Apaga el equipo antes de mover cables", ERROR_);
      return;
    }
    c.conectado = !c.conectado;
    sonido("clic");
    avisar((c.conectado ? "Conectaste: " : "Desconectaste: ") + c.nombre, c.conectado ? BIEN : INFO);
    if (energia && encendido)
      monitor.revisarEnergia();
  }

  // usarEnPieza(p) · Quita la pieza, libera clips con la púa o aplica pasta
  void usarEnPieza(Pieza p) {
    if (herramienta == PASTA) {
      usarPasta(p);
      return;
    }
    if (herramienta == DESTORNILLADOR) {
      int n = p.tornillosPuestos();
      avisar(n > 0 ? "Haz clic en cada tornillo de " + p.nombre + " (" + n + " restantes)" : p.nombre + " ya no tiene tornillos: usa la mano (tecla 1)", INFO);
      return;
    }
    String r = razonNoQuitar(p);
    if (r != null) {
      avisar(r, ERROR_);
      sonido("error");
      return;
    }
    revisarSeguridad(p);
    quitar(p);
    sonido("quitar");
    avisar("Retiraste: " + p.nombre, BIEN);
  }

  // intentarPoner(p) · Coloca una pieza de la mesa si se cumplen las reglas
  void intentarPoner(Pieza p) {
    if (herramienta != MANO) {
      avisar("Para colocar piezas usa la mano (tecla 1)", INFO);
      return;
    }
    String r = razonNoPoner(p);
    if (r != null) {
      avisar(r, ERROR_);
      sonido("error");
      return;
    }
    revisarSeguridad(p);
    poner(p);
    sonido("poner");
    String extra = p.tornillos.size() > 0 ? " Ahora atorníllala (" + p.tornillos.size() + ")." : "";
    for (Conector c : conectores)
      if (!c.conectado && (c.duenio.equals(p.id) || c.destino.equals(p.id)) && puesta(c.duenio) && puesta(c.destino)) {
        extra += " Conecta: " + c.nombre + ".";
        break;
      }
    avisar("Colocaste: " + p.nombre + "." + extra, BIEN);
    if ((p.tipo == T_DISIPADOR_LAPTOP || p.tipo == T_COOLER) && pasta != PASTA_NUEVA && pasta != PASTA_BUENA)
      avisar("Pusiste el disipador sin pasta térmica nueva: el procesador se calentará", AVISO);
  }

  // usarPasta(p) · Limpia la pasta vieja o aplica nueva sobre el procesador
  void usarPasta(Pieza p) {
    if (p.tipo != T_CPU) {
      avisar("La pasta térmica va sobre el procesador (CPU)", INFO);
      return;
    }
    if (pasta == PASTA_VIEJA) {
      pasta = PASTA_LIMPIA;
      avisar("Limpiaste la pasta vieja con alcohol isopropílico", BIEN);
    } else if (pasta == PASTA_LIMPIA) {
      pasta = PASTA_NUEVA;
      avisar("Aplicaste pasta térmica nueva (una gota del tamaño de un chícharo)", BIEN);
    } else
      avisar("El procesador ya tiene pasta térmica nueva", INFO);
    sonido("clic");
  }

  // revisarSeguridad(p) · Advertencias de seguridad (no bloquean, solo cuentan)
  void revisarSeguridad(Pieza p) {
    if (p.sensible && !pulsera) {
      advertencias++;
      avisar("Sin pulsera antiestática (tecla U): podrías dañar " + p.nombre + " con estática", AVISO);
    }
    if (laptop && !p.id.equals("tapa") && !p.id.equals("bateria")) {
      for (Conector c : conectores)
        if (c.id.equals("bateria") && c.conectado) {
          advertencias++;
          avisar("La batería sigue conectada: desconéctala antes de tocar otras piezas", AVISO);
        }
    }
    if (!laptop && !p.id.equals("panel")) {
      for (Conector c : conectores)
        if (c.id.equals("corriente") && c.conectado) {
          advertencias++;
          avisar("El equipo sigue conectado a la corriente: desconecta el cable de la fuente", AVISO);
        }
    }
  }

  // @siguientePaso(armando) · Siguiente pieza según el orden de desarmado o armado
  Pieza siguientePaso(boolean armando) {
    if (!armando) {
      for (String id : orden) {
        Pieza p = porId.get(id);
        if (p != null && p.instalada && p.removible && libre(p.requiere))
          return p;
      }
    } else {
      for (int i = orden.length - 1; i >= 0; i--) {
        Pieza p = porId.get(orden[i]);
        if (p != null && !p.instalada && p.removible)
          return p;
      }
    }
    return null;
  }

  // conectorPendiente(p) · Cable que todavía sujeta a la pieza
  Conector conectorPendiente(Pieza p) {
    for (Conector c : conectores)
      if (c.conectado && (c.duenio.equals(p.id) || c.destino.equals(p.id)))
        return c;
    return null;
  }
}

// rayoCaja(r, ...) · Distancia de intersección de un rayo con una caja (-1 si no la toca)
float rayoCaja(float[] r, float cx, float ch, float cz, float sx, float sh, float sz) {
  float[] mn = {cx - sx / 2, ch - sh / 2, cz - sz / 2}, mx = {cx + sx / 2, ch + sh / 2, cz + sz / 2};
  float t0 = -1000000000.0, t1 = 1000000000.0;
  for (int i = 0; i < 3; i++) {
    float o = r[i], d = r[i + 3];
    if (abs(d) < 0.000001) {
      if (o < mn[i] || o > mx[i])
        return -1;
    } else {
      float a = (mn[i] - o) / d, b = (mx[i] - o) / d;
      t0 = max(t0, min(a, b));
      t1 = min(t1, max(a, b));
    }
  }
  return t1 >= t0 && t1 > 0 ? max(t0, 0) : -1;
}
