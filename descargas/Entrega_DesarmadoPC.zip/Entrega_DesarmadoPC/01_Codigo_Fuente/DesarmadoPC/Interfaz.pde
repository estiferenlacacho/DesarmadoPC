// ============================================================
// INTERFAZ 2D · barra, lista de piezas, información, pasos, mensajes y ayuda
// ============================================================

// ---- Mensajes ----
// class Mensaje · Aviso temporal con color según su tipo
class Mensaje {
  String texto;
  int tipo, nacido;
  Mensaje(String texto, int tipo) {
    this.texto = texto;
    this.tipo = tipo;
    nacido = frameCount;
  }
}

ArrayList<Mensaje> mensajes = new ArrayList<Mensaje>();

// @avisar(t, tipo) · Muestra un aviso (INFO, BIEN, AVISO o ERROR_)
void avisar(String t, int tipo) {
  if (mensajes.size() > 0 && mensajes.get(mensajes.size() - 1).texto.equals(t)) {
    mensajes.get(mensajes.size() - 1).nacido = frameCount;
    return;
  }
  mensajes.add(new Mensaje(t, tipo));
  if (mensajes.size() > 4)
    mensajes.remove(0);
}

// colorTipo(tipo) · Color de cada tipo de aviso
color colorTipo(int tipo) {
  if (tipo == BIEN)
    return color(120, 230, 140);
  if (tipo == AVISO)
    return color(255, 200, 70);
  if (tipo == ERROR_)
    return color(255, 110, 100);
  return color(200, 220, 255);
}

// ---- Interfaz ----
// @class Interfaz · Capa 2D dibujada encima de la escena 3D
class Interfaz {
  float izqX = 10, izqY = 56, izqW = 250;
  float derW = 310;
  Pieza seleccion;
  boolean armando = false;
  String[] nombresHerr = {"Mano", "Destornillador", "Púa", "Pasta térmica"};

  // sobrePanel(x, y) · true si el mouse está sobre algún panel 2D (bloquea el clic en 3D)
  boolean sobrePanel(float x, float y) {
    if (y < 46 || sobrePanelLuz(x, y))
      return true;
    if (x > izqX && x < izqX + izqW && y > izqY && y < izqY + altoIzq())
      return true;
    if (x > width - derW - 10 && y > izqY && y < izqY + altoDer())
      return true;
    return false;
  }

  // altoIzq() · Alto del panel de piezas
  float altoIzq() {
    return 92 + equipo.piezas.size() * 22 + 60;
  }

  // altoInfo() · Alto del panel de información
  float altoInfo() {
    if (hover != null && hover.tipo == OBJ_CONECTOR)
      return 170;
    return seleccion != null ? 290 : 64;
  }

  // hayEstado() · true si hay que mostrar el estado de la pantalla
  boolean hayEstado() {
    return equipo.encendido || monitor.diagnostico.length() > 0;
  }

  // altoDer() · Alto total del panel derecho
  float altoDer() {
    return altoInfo() + (hayEstado() ? 110 : 0);
  }

  // @dibujar() · Dibuja toda la interfaz: barra, paneles, paso, avisos, tooltip, ayuda y panel de luz
  void dibujar() {
    if (hover != null && hover.p != null)
      seleccion = hover.p;
    textFont(fuente);
    barraSuperior();
    panelPiezas();
    panelInfo();
    pasoYMensajes();
    dibujarPanelLuz();
    if (!sobrePanelLuz(mouseX, mouseY))
      tooltip();
    if (mostrarAyuda)
      ayuda();
  }

  // @boton(t, x, y, w, h, activo, acento) · Botón inmediato: devuelve true si se le hizo clic en este cuadro
  boolean boton(String t, float x, float y, float w, float h, boolean activo, color acento) {
    boolean sobre = mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;
    noStroke();
    fill(activo ? acento : (sobre ? color(70, 80, 100) : color(45, 52, 66)));
    rect(x, y, w, h, 6);
    fill(activo ? color(15, 20, 30) : color(230));
    textAlign(CENTER, CENTER);
    textSize(13);
    text(t, x + w / 2, y + h / 2 - 1);
    return sobre && clic;
  }

  // barraSuperior() · Herramientas y botones de acción
  void barraSuperior() {
    noStroke();
    fill(20, 24, 32, 235);
    rect(0, 0, width, 46);
    fill(240);
    textAlign(LEFT, CENTER);
    textSize(15);
    text("Taller · " + equipo.nombre, 14, 23);
    float x = 232;
    float[] anchos = {84, 124, 70, 116};
    for (int i = 0; i < 4; i++) {
      if (boton((i + 1) + " " + nombresHerr[i], x, 7, anchos[i], 32, herramienta == i, color(255, 205, 80)))
        herramienta = i;
      x += anchos[i] + 5;
    }
    x += 8;
    if (boton("U Pulsera: " + (pulsera ? "sí" : "no"), x, 7, 118, 32, pulsera, color(120, 220, 150)))
      alternarPulsera();
    x += 123;
    if (equipo.laptop) {
      if (boton(equipo.enUso ? "V Voltear" : "V Abrir", x, 7, 82, 32, false, 0))
        voltear();
      x += 87;
    }
    if (boton(equipo.encendido ? "E Apagar" : "E Encender", x, 7, 98, 32, equipo.encendido, color(120, 200, 255)))
      encenderApagar();
    x += 103;
    if (equipo.laptop && equipo.modelo.rgb) {
      if (boton("L RGB", x, 7, 64, 32, modoLuz != L_APAGADA, color(200, 150, 255)))
        cambiarModoLuz();
      x += 69;
    }
    if (boton("I Iluminación", x, 7, 108, 32, panelLuz, color(255, 235, 150)))
      panelLuz = !panelLuz;
    if (boton("M Menú", width - 80, 7, 70, 32, false, 0))
      irAlMenu();
  }

  // panelPiezas() · Lista de piezas con su estado
  void panelPiezas() {
    noStroke();
    fill(20, 24, 32, 215);
    rect(izqX, izqY, izqW, altoIzq(), 8);
    fill(240);
    textAlign(LEFT, CENTER);
    textSize(14);
    text("Piezas", izqX + 12, izqY + 16);
    if (boton(armando ? "Objetivo: armar" : "Objetivo: desarmar", izqX + izqW - 134, izqY + 5, 124, 22, armando, color(255, 205, 80)))
      armando = !armando;
    float y = izqY + 40;
    for (String id : equipo.orden) {
      Pieza p = equipo.pieza(id);
      boolean sobre = mouseX > izqX && mouseX < izqX + izqW && mouseY > y - 11 && mouseY < y + 11;
      if (sobre) {
        fill(255, 25);
        rect(izqX + 4, y - 11, izqW - 8, 22, 4);
        if (clic)
          enfocar(p);
      }
      if (p == seleccion) {
        fill(255, 225, 60, 40);
        rect(izqX + 4, y - 11, izqW - 8, 22, 4);
      }
      int n = p.tornillosPuestos();
      color estado = !p.instalada ? color(120, 125, 135) : (n < p.tornillos.size() ? color(255, 200, 70) : color(110, 220, 130));
      fill(estado);
      ellipse(izqX + 16, y, 9, 9);
      fill(p.instalada ? color(235) : color(150));
      textAlign(LEFT, CENTER);
      textSize(12);
      text(p.nombre, izqX + 28, y);
      textAlign(RIGHT, CENTER);
      fill(170);
      text(!p.instalada ? "en la mesa" : (p.tornillos.size() > 0 ? n + "/" + p.tornillos.size() + " torn." : "puesta"), izqX + izqW - 10, y);
      y += 22;
    }
    y += 6;
    stroke(255, 40);
    line(izqX + 10, y, izqX + izqW - 10, y);
    noStroke();
    textAlign(LEFT, CENTER);
    textSize(12);
    fill(220);
    text("Retiradas: " + equipo.retiradas() + " / " + equipo.removibles(), izqX + 12, y + 16);
    fill(advertencias > 0 ? color(255, 200, 70) : color(220));
    text("Advertencias: " + advertencias, izqX + 130, y + 16);
    String[] pastas = {"en buen estado", "vieja (cámbiala)", "limpia, sin pasta", "nueva"};
    fill(equipo.pasta == PASTA_BUENA || equipo.pasta == PASTA_NUEVA ? color(220) : color(255, 200, 70));
    text("Pasta térmica: " + pastas[equipo.pasta], izqX + 12, y + 36);
  }

  // panelInfo() · Información de lo que está bajo el mouse y estado del equipo
  void panelInfo() {
    float x = width - derW - 10, y = izqY;
    noStroke();
    fill(20, 24, 32, 215);
    rect(x, y, derW, altoDer(), 8);
    float yy = y + 14;
    textAlign(LEFT, TOP);
    if (hover != null && hover.tipo == OBJ_CONECTOR) {
      Conector k = hover.c;
      fill(255, 225, 90);
      textSize(15);
      text(k.nombre, x + 12, yy, derW - 24, 40);
      fill(220);
      textSize(12);
      text((k.conectado ? "Conectado. " : "Desconectado. ") + (k.info != null ? k.info : "Se conecta y desconecta con la mano."), x + 12, yy + 44, derW - 24, 120);
    } else if (seleccion != null) {
      Pieza p = seleccion;
      fill(255, 225, 90);
      textSize(15);
      text(p.nombre, x + 12, yy, derW - 24, 40);
      fill(220);
      textSize(12);
      text(p.info, x + 12, yy + 26, derW - 24, 70);
      fill(150, 200, 255);
      text(p.removible ? "Cómo se quita:" : "Nota:", x + 12, yy + 98);
      fill(220);
      text(p.removible ? p.comoQuitar : "Este componente " + p.comoQuitar, x + 12, yy + 116, derW - 24, 90);
      if (p.removible) {
        float ry = yy + 210;
        String r = p.instalada ? equipo.razonNoQuitar(p) : equipo.razonNoPoner(p);
        fill(r == null ? color(120, 230, 140) : color(255, 200, 70));
        text(r == null ? (p.instalada ? "Lista para retirarse (clic con la mano)" : "Lista para colocarse (clic en ella)") : r, x + 12, ry, derW - 24, 40);
        if (p.sensible) {
          fill(170);
          text("Sensible a la estática: usa la pulsera.", x + 12, ry + 40);
        }
      }
    } else {
      fill(220);
      textSize(13);
      text("Pasa el mouse sobre una pieza, tornillo o cable para ver qué es y cómo se quita.", x + 12, yy, derW - 24, 50);
    }
    if (hayEstado()) {
      float sy = y + altoInfo() + 10;
      stroke(255, 40);
      line(x + 10, sy - 10, x + derW - 10, sy - 10);
      noStroke();
      fill(equipo.encendido ? color(120, 230, 140) : color(255, 160, 120));
      textSize(14);
      text(equipo.encendido ? "Encendido · " + monitor.diagnostico : monitor.diagnostico, x + 12, sy);
      fill(210);
      textSize(12);
      text(monitor.detalle, x + 12, sy + 20, derW - 24, 34);
      if (equipo.encendido) {
        float tt = monitor.temp;
        fill(60);
        rect(x + 12, sy + 60, derW - 24, 10, 4);
        fill(tt < 70 ? color(110, 220, 130) : (tt < 88 ? color(255, 200, 70) : color(255, 90, 80)));
        rect(x + 12, sy + 60, (derW - 24) * constrain(tt / 105.0, 0, 1), 10, 4);
        fill(230);
        text("CPU " + round(tt) + " °C   ·   Ventilador " + round(monitor.rpm) + " RPM", x + 12, sy + 76);
      }
    }
  }

  // sugerencia() · Texto del siguiente paso según la situación
  String sugerencia() {
    Equipo e = equipo;
    if (e.encendido)
      return "Equipo encendido. Apágalo (E) antes de seguir trabajando.";
    if (e.laptop && (e.enUso || e.volteo > 0))
      return "Pulsa V para voltear la laptop boca abajo y trabajar en ella.";
    if (!e.laptop && conectorConectado("corriente") && !armando)
      return "Primero desconecta el cable de corriente (parte trasera de la fuente).";
    if (!pulsera)
      return "Ponte la pulsera antiestática (U) antes de tocar componentes.";
    if (!armando) {
      Pieza p = e.siguientePaso(false);
      if (p == null) {
        return "¡Desarmaste todo! Cambia el objetivo a «armar» y vuelve a montarlo.";
      }
      if (e.laptop && !p.id.equals("tapa") && conectorConectado("bateria"))
        return "Desconecta el cable de la batería de la placa (mano).";
      if (p.tornillosPuestos() > 0)
        return "Quita los " + p.tornillosPuestos() + " tornillos de: " + p.nombre + " (destornillador).";
      Conector k = e.conectorPendiente(p);
      if (k != null)
        return "Desconecta: " + k.nombre + " (mano).";
      if (p.herramienta == PUA)
        return "Libera los clips de " + p.nombre + " con la púa (3).";
      return "Retira con la mano: " + p.nombre + ".";
    }
    if (e.puesta("placa") && !e.puesta(e.laptop ? "disipador" : "cooler") && e.puesta(e.laptop ? "placa" : "cpu") && e.pasta != PASTA_NUEVA)
      return e.pasta == PASTA_VIEJA ? "Limpia la pasta vieja del procesador (4 y clic en el CPU)." : "Aplica pasta térmica nueva al procesador (4 y clic en el CPU).";
    for (int i = e.orden.length - 1; i >= 0; i--) {
      Pieza p = e.pieza(e.orden[i]);
      if (!p.instalada)
        continue;
      if (p.tornillosPuestos() < p.tornillos.size())
        return "Atornilla " + p.nombre + " (" + (p.tornillos.size() - p.tornillosPuestos()) + " tornillos).";
    }
    Pieza p = e.siguientePaso(true);
    if (p != null && e.razonNoPoner(p) == null)
      return "Coloca: " + p.nombre + " (clic en ella sobre la mesa).";
    for (Conector k : e.conectores)
      if (!k.conectado && e.puesta(k.duenio) && e.puesta(k.destino) && !k.id.equals("cargador"))
        return "Conecta: " + k.nombre + ".";
    if (p != null)
      return "Coloca: " + p.nombre + ". " + e.razonNoPoner(p);
    return "¡Equipo armado! Enciéndelo con E.";
  }

  // pasoYMensajes() · Siguiente paso y avisos que se desvanecen
  void pasoYMensajes() {
    String s = sugerencia();
    textSize(14);
    float w = textWidth("Siguiente paso: " + s) + 40;
    float x = width / 2 - w / 2, y = height - 46;
    noStroke();
    fill(20, 24, 32, 225);
    rect(x, y, w, 34, 8);
    fill(255, 205, 80);
    textAlign(LEFT, CENTER);
    text("Siguiente paso: ", x + 20, y + 16);
    fill(240);
    text(s, x + 20 + textWidth("Siguiente paso: "), y + 16);
    float my = y - 12;
    textSize(13);
    for (int i = mensajes.size() - 1; i >= 0; i--) {
      Mensaje m = mensajes.get(i);
      float edad = frameCount - m.nacido;
      if (edad > 420)
        continue;
      float a = edad > 360 ? map(edad, 360, 420, 255, 0) : 255;
      float mw = textWidth(m.texto) + 28;
      my -= 28;
      fill(15, 18, 26, 200 * a / 255);
      rect(width / 2 - mw / 2, my, mw, 24, 6);
      fill(colorTipo(m.tipo), a);
      textAlign(CENTER, CENTER);
      text(m.texto, width / 2, my + 11);
    }
  }

  // tooltip() · Etiqueta junto al cursor
  void tooltip() {
    if (hover == null || mostrarAyuda)
      return;
    String t, accion;
    if (hover.tipo == OBJ_TORNILLO) {
      t = "Tornillo de " + hover.p.nombre;
      accion = herramienta == DESTORNILLADOR ? (hover.t.puesto ? "clic: quitar" : "clic: atornillar") : "usa el destornillador (2)";
    } else if (hover.tipo == OBJ_CONECTOR) {
      t = hover.c.nombre;
      accion = herramienta == MANO ? (hover.c.conectado ? "clic: desconectar" : "clic: conectar") : "usa la mano (1)";
    } else if (hover.tipo == OBJ_BANDEJA) {
      t = hover.p.nombre + " (en la mesa)";
      accion = herramienta == MANO ? "clic: colocar en el equipo" : "usa la mano (1)";
    } else {
      t = hover.p.nombre;
      if (herramienta == PASTA)
        accion = hover.p.tipo == T_CPU ? "clic: limpiar / aplicar pasta" : "la pasta va en el CPU";
      else if (herramienta == DESTORNILLADOR)
        accion = "haz clic en sus tornillos";
      else
        accion = hover.p.removible ? "clic: retirar" : "no se retira";
    }
    textSize(13);
    float w = max(textWidth(t), textWidth(accion)) + 20;
    float x = min(mouseX + 16, width - w - 4), y = mouseY + 18;
    noStroke();
    fill(15, 18, 26, 230);
    rect(x, y, w, 42, 6);
    fill(255, 225, 90);
    textAlign(LEFT, TOP);
    text(t, x + 10, y + 5);
    fill(220);
    text(accion, x + 10, y + 23);
  }

  // ayuda() · Ventana de controles (tecla H)
  void ayuda() {
    noStroke();
    fill(10, 12, 18, 225);
    rect(width / 2 - 330, 80, 660, 540, 12);
    fill(255, 205, 80);
    textAlign(CENTER, TOP);
    textSize(20);
    text("Controles", width / 2, 108);
    String[] l = {
      "Clic izquierdo ............ usar la herramienta en lo que está bajo el mouse",
      "Arrastrar (izq. o der.) ... girar la cámara alrededor del equipo",
      "Shift + arrastrar ......... desplazar la cámara (también botón central)",
      "Rueda ..................... acercar / alejar",
      "1 Mano .................... retirar y colocar piezas, conectar cables",
      "2 Destornillador .......... quitar y poner tornillos",
      "3 Púa de plástico ......... liberar los clips de la tapa de la laptop",
      "4 Pasta térmica ........... limpiar la pasta vieja y aplicar nueva al CPU",
      "U ......................... pulsera antiestática",
      "V ......................... voltear / abrir la laptop",
      "E ......................... encender / apagar",
      "F ......................... enfocar la pieza del siguiente paso",
      "R ......................... cámara inicial",
      "H ......................... mostrar u ocultar esta ayuda",
      "M ......................... volver al menú",
      "L ......................... luces RGB (laptops de juegos)",
      "I · T · O · K ......... iluminación · linterna · luz de aro · lámpara de trabajo",
      "X ......................... iluminación RTX (por píxel, con sombras)",
      "N ......................... activar / silenciar los sonidos"};
    fill(230);
    textAlign(LEFT, TOP);
    textFont(fuenteMono);
    textSize(13);
    for (int i = 0; i < l.length; i++)
      text(l[i], width / 2 - 300, 150 + i * 24);
    textFont(fuente);
    if (clic)
      mostrarAyuda = false;
  }
}
