// ============================================================
// ESCENA · mesa, equipo, piezas en movimiento, sombras y selección
// ============================================================

// @dibujarEscena(e, o, conMesa) · Dibuja todo en orden: mesa, sombras, equipo, piezas fuera y panel
void dibujarEscena(Equipo e, Objetivo o, boolean conMesa) {
  if (conMesa) {
    dibujarMesa(e.laptop);
    if (e.laptop) {
      sombra(-430, -250, 150, 95, 0.7);
      dibujarCargador();
    } else {
      sombra(470, -235, 300, 230, 0.6);
      dibujarMonitor(e);
    }
  }
  if (e.laptop)
    sombra(0, 0, e.modelo.W * 1.24, e.modelo.D * 1.28, 0.75 * (1 - e.elevacion() / 160));
  else
    sombra(0, 0, e.modelo.W + 90, e.modelo.D + 80, 0.8);
  dibujarSombrasRTX(e, conMesa);
  dibujarEquipo(e, o);
  dibujarPiezasFuera(e, o);
  dibujarPanelInstalado(e, o);
}

// @dibujarEquipo(e, o) · Cuerpo, piezas instaladas, tornillos, conectores y cables (también para la sombra)
void dibujarEquipo(Equipo e, Objetivo o) {
  pushMatrix();
  e.transformar();
  if (e.laptop)
    dibujarCuerpoLaptop(e);
  else
    dibujarGabinete(e);
  for (Pieza p : e.piezas) {
    if (!p.instalada || !p.enReposo() || !p.removible || p.tipo == T_PANEL)
      continue;
    pushMatrix();
    translate(p.x, -p.h, p.z);
    dibujarPieza(p, e);
    popMatrix();
  }
  for (Pieza p : e.piezas) {
    if (!p.instalada || !p.enReposo())
      continue;
    for (Tornillo t : p.tornillos)
      dibujarTornillo(t, o != null && o.t == t);
  }
  for (Conector k : e.conectores) {
    if (k.id.equals("cargador") || k.id.equals("corriente"))
      continue;
    if (e.puesta(k.duenio))
      dibujarConector(k, e, o != null && o.c == k);
  }
  dibujarCablesEnergia(e, o);
  if (o != null && o.tipo != OBJ_BANDEJA)
    resaltar(o);
  popMatrix();
}

// dibujarPiezasFuera(e, o) · Piezas que viajan con el mouse o descansan en la mesa
void dibujarPiezasFuera(Equipo e, Objetivo o) {
  for (Pieza p : e.piezas) {
    if (!p.removible || p.instalada && p.enReposo())
      continue;
    float[] w = posicionMundo(e, p);
    if (p.enReposo() && !p.instalada) {
      float[] s = p.tamBandeja();
      sombra(w[0], w[2], s[0] * 1.15 + 14, s[2] * 1.15 + 14, 0.55);
    }
    pushMatrix();
    translate(w[0], -w[1], w[2]);
    orientarEnMundo(e, p);
    if (p.tipo == T_PANEL)
      dibujarPanelVidrio(p, false);
    else
      dibujarPieza(p, e);
    popMatrix();
    if (o != null && o.tipo == OBJ_BANDEJA && o.p == p) {
      float[] s = p.tamBandeja(), b = e.posBandeja(p);
      marcoSeleccion(b[0], b[1], b[2], s[0], s[1], s[2]);
    }
  }
}

// dibujarPanelInstalado(e, o) · El panel de vidrio va al final porque es transparente
void dibujarPanelInstalado(Equipo e, Objetivo o) {
  Pieza panel = e.pieza("panel");
  if (panel != null && panel.instalada && panel.enReposo()) {
    pushMatrix();
    translate(panel.x, -panel.h, panel.z);
    dibujarPanelVidrio(panel, true);
    popMatrix();
    for (Tornillo t : panel.tornillos)
      dibujarTornillo(t, o != null && o.t == t);
  }
}

// dibujarCablesEnergia(e, o) · Cable del cargador o de corriente (termina fuera del equipo)
void dibujarCablesEnergia(Equipo e, Objetivo o) {
  for (Conector k : e.conectores) {
    if (!k.id.equals("cargador") && !k.id.equals("corriente"))
      continue;
    if (k.id.equals("corriente") && !e.puesta("psu"))
      continue;
    float s = k.conectado ? 0 : 40;
    float x = k.x + k.nx * s, h = k.h + k.nh * s, z = k.z + k.nz * s;
    noStroke();
    fill(o != null && o.c == k ? color(255, 230, 80) : k.col);
    c(x, h, z, k.w, k.alto, k.d);
    if (k.id.equals("cargador")) {
      popMatrix();
      float[] m = e.localAMundo(x, h, z);
      stroke(25);
      strokeWeight(4);
      line(m[0], -m[1], m[2], -330, -3, -200);
      line(-330, -3, -200, -375, -3, -250);
      noStroke();
      pushMatrix();
      e.transformar();
    } else {
      stroke(k.colCable);
      strokeWeight(k.grosor);
      float px = x, ph = h, pz = z;
      for (int i = 0; i + 2 < k.cable.length; i += 3) {
        line(px, -ph, pz, k.cable[i], -k.cable[i + 1], k.cable[i + 2]);
        px = k.cable[i];
        ph = k.cable[i + 1];
        pz = k.cable[i + 2];
      }
      noStroke();
    }
  }
}

// resaltar(o) · Marco de color alrededor de lo que está bajo el mouse
void resaltar(Objetivo o) {
  if (o.tipo == OBJ_PIEZA)
    marcoSeleccion(o.p.x, o.p.h, o.p.z, o.p.w, o.p.alto, o.p.d);
  else if (o.tipo == OBJ_TORNILLO)
    marcoSeleccion(o.t.x + o.t.nx * 2, o.t.h + o.t.nh * 2, o.t.z + o.t.nz * 2, 8, 8, 8);
  else if (o.tipo == OBJ_CONECTOR) {
    float s = o.c.separacion();
    marcoSeleccion(o.c.x + o.c.nx * s, o.c.h + o.c.nh * s, o.c.z + o.c.nz * s, o.c.w, o.c.alto, o.c.d);
  }
}

// ---- Piezas que viajan entre el equipo y la mesa ----
// posicionMundo(e, p) · Posición de una pieza que viaja entre el equipo y la mesa
float[] posicionMundo(Equipo e, Pieza p) {
  float[] dentro = e.localAMundo(p.x, p.h, p.z), fuera = e.posBandeja(p);
  float[] desde = {p.sx, p.sh, p.sz}, hasta = p.haciaBandeja ? fuera : dentro;
  if (p.enReposo())
    return p.instalada ? dentro : fuera;
  float t = p.anim, k = t * t * (3 - 2 * t);
  float arco = sin(PI * t) * 140;
  return new float[] {lerp(desde[0], hasta[0], k), lerp(desde[1], hasta[1], k) + arco, lerp(desde[2], hasta[2], k)};
}

// orientarEnMundo(e, p) · Gira la pieza mientras viaja para que quede plana en la mesa
void orientarEnMundo(Equipo e, Pieza p) {
  float t = p.anim, k = t * t * (3 - 2 * t);
  float giro = p.enReposo() ? 1 : (p.haciaBandeja ? k : 1 - k);
  if (e.laptop)
    rotateZ(-PI);
  else if (p.acostar)
    rotateX(HALF_PI * giro);
  else if (p.deLado)
    rotateZ(HALF_PI * giro);
}
