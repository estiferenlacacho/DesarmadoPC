// ============================================================
// DESARMADO PC · Taller de computadoras en 3D (Processing 4, P3D)
// PROGRAMA PRINCIPAL · estado global, ciclo de dibujo, menú y entrada
// ============================================================
// Mapa de pestañas:
//   DesarmadoPC  inicio, draw(), menú, mouse, teclado y sonido
//   Camara3D     cámara en órbita y rayo del mouse
//   Catalogo     los 8 modelos y la construcción de cada equipo
//   Equipo       reglas para quitar y poner piezas, volteo y selección
//   Pieza        clases Tornillo, Conector y Pieza
//   Escena       orden de dibujo de la escena 3D
//   Modelos      primitivas y modelos 3D (piezas, laptops, gabinetes, monitor)
//   Texturas     texturas generadas por código, cajas con textura y sombras
//   Iluminacion  luces de la escena y panel de iluminación
//   Rtx          shader RTX, materiales, sombras proyectadas y luz de LEDs/pantalla
//   Luces        LEDs RGB y brillo aditivo
//   Pantalla     pantalla simulada: POST, sistema, temperatura y cámara
//   Interfaz     capa 2D: barra, paneles, avisos y ayuda
//   data/        shaders/rtx.vert, shaders/rtx.frag y sonidos/*.wav
// Busca "// @" para ir a las funciones importantes.
// ============================================================

import processing.video.*;
import processing.opengl.*;
import javax.sound.sampled.*;
import java.io.File;

// ---- Constantes y estado global ----
final static int INFO = 0;
final static int BIEN = 1;
final static int AVISO = 2;
final static int ERROR_ = 3;
final static int MENU = 0;
final static int TALLER = 1;

int modo = MENU;
Equipo equipo, menuLaptop, menuTorre;
Equipo[] menuLaptops, menuTorres;
int menuSelL = 0, menuSelD = 0;
Camara3D cam;
Pantalla monitor;
Interfaz ui;
Objetivo hover;
int herramienta = MANO;
boolean pulsera = false, mostrarAyuda = false, encenderAlAbrir = false;
int advertencias = 0;
PFont fuente, fuenteMono;
boolean clic = false, shift = false, arrastrando = false;
float pressX, pressY;
int botonPresionado;

Capture camara;
boolean camaraLista = false;
String estadoCamara = "La cámara se abre al terminar de arrancar";

// ---- Inicio y ciclo de dibujo ----
// @setup() · Inicializa el contexto gráfico P3D (1280x720), fuentes, texturas, catálogo, cámara, interfaz, equipos del menú, pantalla y shaders RTX
void setup() {
  size(1280, 720, P3D);
  smooth(8);
  fuente = createFont("SansSerif", 14);
  fuenteMono = createFont("Monospaced", 15);
  textFont(fuente);
  textureWrap(REPEAT);
  crearTexturas();
  crearCatalogo();
  cam = new Camara3D();
  ui = new Interfaz();
  menuLaptops = new Equipo[LAPTOPS.length];
  menuTorres = new Equipo[ESCRITORIOS.length];
  for (int i = 0; i < LAPTOPS.length; i++) {
    menuLaptops[i] = crearLaptop(LAPTOPS[i]);
    menuLaptops[i].enUso = true;
    menuLaptops[i].volteo = 1;
    menuLaptops[i].demoLuces = true;
  }
  for (int i = 0; i < ESCRITORIOS.length; i++)
    menuTorres[i] = crearEscritorio(ESCRITORIOS[i]);
  menuLaptop = menuLaptops[0];
  menuTorre = menuTorres[0];
  equipo = menuLaptop;
  monitor = new Pantalla();
  prepararRTX();
}

// @draw() · Ciclo de renderizado (60 cuadros/s): fondo, animación, cámara, luces, escena 3D y al final la interfaz 2D
void draw() {
  background(18, 19, 24);
  fondoEstudio();
  if (equipo.encendido)
    giroAspas += 0.45;
  if (modo == MENU) {
    dibujarMenu();
    clic = false;
    return;
  }
  equipo.actualizar();
  monitor.actualizar();
  actualizarLuces(equipo);
  actualizarColorPantalla();
  cam.aplicar();
  guardarVista();
  luces();
  boolean sobreUI = ui.sobrePanel(mouseX, mouseY);
  hover = !arrastrando && !sobreUI && !mostrarAyuda ? equipo.buscar(cam.rayo(mouseX, mouseY)) : null;
  dibujarEscena(equipo, hover, true);
  dibujarIndicadorLuz();

  hint(DISABLE_DEPTH_TEST);
  camera();
  perspective();
  sinLuces();
  ui.dibujar();
  hint(ENABLE_DEPTH_TEST);
  clic = false;
}

// ---- Menú de modelos ----
// @dibujarMenu() · Menú inicial: cámara que gira alrededor de una laptop y una PC, y tarjetas de los 8 modelos (clic para entrar)
void dibujarMenu() {
  float a = frameCount * 0.003;
  camera(sin(a) * 1500, -650, cos(a) * 1500 + 200, 0, -150, 0, 0, 1, 0);
  perspective(PI / 3.3, width / (float) height, 5, 20000);
  guardarVista();
  luces();
  menuLaptop = menuLaptops[menuSelL];
  menuTorre = menuTorres[menuSelD];
  actualizarLuces(menuLaptop);
  dibujarMesa(false);
  pushMatrix();
  translate(-260, 0, 90);
  dibujarEscena(menuLaptop, null, false);
  popMatrix();
  pushMatrix();
  translate(250, 0, -70);
  dibujarEscena(menuTorre, null, false);
  popMatrix();

  hint(DISABLE_DEPTH_TEST);
  camera();
  perspective();
  sinLuces();
  noStroke();
  fill(10, 12, 20, 70);
  rect(0, 0, width, height);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(38);
  text("Taller de Computadoras", width / 2, 62);
  fill(180, 205, 255);
  textSize(16);
  text("Elige un equipo para desarmarlo y armarlo · al encenderlo verás tu cámara en su pantalla", width / 2, 104);
  for (int col = 0; col < 2; col++) {
    Modelo[] lista = col == 0 ? LAPTOPS : ESCRITORIOS;
    float x = col == 0 ? 26 : width - 26 - 370, w = 370;
    fill(255);
    textAlign(LEFT, CENTER);
    textSize(20);
    text(col == 0 ? "Laptops" : "PCs de escritorio", x + 4, 150);
    for (int i = 0; i < lista.length; i++) {
      Modelo m = lista[i];
      float y = 172 + i * 104, h = 96;
      boolean sobre = mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;
      if (sobre) {
        if (col == 0)
          menuSelL = i;
        else
          menuSelD = i;
      }
      boolean sel = col == 0 ? menuSelL == i : menuSelD == i;
      fill(sobre ? color(60, 110, 190, 240) : (sel ? color(40, 62, 100, 235) : color(24, 30, 44, 225)));
      rect(x, y, w, h, 10);
      fill(m.laptop ? m.chasis : m.chasis);
      rect(x + 12, y + 14, 8, h - 28, 4);
      fill(m.acento);
      rect(x + 12, y + h - 26, 8, 12, 4);
      fill(255);
      textAlign(LEFT, TOP);
      textSize(17);
      text(m.nombre, x + 32, y + 10);
      fill(255, 210, 120);
      textSize(12);
      text(m.clase, x + 32, y + 33);
      fill(205);
      textSize(12);
      text(m.resumen, x + 32, y + 50, w - 44, 40);
      if (sobre && clic)
        empezar(m);
    }
    fill(150);
    textSize(11);
    textAlign(LEFT, TOP);
    Modelo s = lista[col == 0 ? menuSelL : menuSelD];
    text("Diseño propio basado en " + s.basadoEn + ".", x + 4, 172 + 4 * 104, w, 30);
  }
  fill(170);
  textAlign(CENTER, CENTER);
  textSize(13);
  text("Clic: usar herramienta · Arrastrar: girar · Rueda: acercar · 1-4 herramientas · U pulsera · E encender · I iluminación · H ayuda", width / 2, 668);
  text("La cámara necesita la librería Video de Processing (Administrar librerías → Video Library for Processing 4)", width / 2, 692);
  hint(ENABLE_DEPTH_TEST);
}

// empezar(laptop) · Entra al taller con el modelo seleccionado en el menú
void empezar(boolean laptop) {
  empezar(laptop ? LAPTOPS[0] : ESCRITORIOS[0]);
}

// @empezar(m) · Crea el equipo del modelo m, reinicia la pantalla, la herramienta y la cámara, y entra al taller
void empezar(Modelo m) {
  boolean laptop = m.laptop;
  if (equipo.encendido)
    monitor.apagar("");
  equipo = laptop ? crearLaptop(m) : crearEscritorio(m);
  monitor.fase = APAGADA;
  monitor.diagnostico = "";
  monitor.detalle = "";
  monitor.temp = 26;
  advertencias = 0;
  pulsera = false;
  herramienta = MANO;
  mensajes.clear();
  ui.armando = false;
  ui.seleccion = null;
  encenderAlAbrir = false;
  vistaInicial();
  modo = TALLER;
  avisar(m.nombre + (laptop ? ": boca abajo sobre el tapete antiestático. Empieza por la tapa inferior." : ": antes de abrirla, desconecta el cable de corriente (parte trasera)."), INFO);
}

// vistaInicial() · Cámara inicial según el tipo y el tamaño del equipo (tecla R)
void vistaInicial() {
  Modelo m = equipo.modelo;
  if (equipo.laptop) {
    float k = m.W / 340;
    if (equipo.enUso)
      cam.vista(0.0, 0.32, 760 * k, 0, 140 * k, -60 * k);
    else
      cam.vista(0.35, 0.95, 620 * k, 0, 20, 0);
  } else {
    float k = max(m.H / 460, m.W / 450);
    cam.vista(0.25, 0.32, 1350 * k, 140 * k, m.H / 2, 0);
  }
}

// irAlMenu() · Apaga la cámara del dispositivo y regresa al menú (tecla M)
void irAlMenu() {
  if (equipo.encendido)
    monitor.apagar("");
  modo = MENU;
  equipo = menuLaptops[menuSelL];
}

// ---- Acciones ----
// alternarPulsera() · Pone o quita la pulsera antiestática (tecla U)
void alternarPulsera() {
  pulsera = !pulsera;
  avisar(pulsera ? "Pulsera antiestática puesta y conectada a tierra" : "Te quitaste la pulsera antiestática", pulsera ? BIEN : AVISO);
}

// voltear() · Voltea la laptop boca abajo o la regresa a uso normal (tecla V)
void voltear() {
  if (!equipo.laptop)
    return;
  if (equipo.encendido) {
    avisar("Apaga la laptop antes de voltearla", ERROR_);
    return;
  }
  if (equipo.volteo != 0 && equipo.volteo != 1)
    return;
  equipo.enUso = !equipo.enUso;
  vistaInicial();
}

// encenderApagar() · Enciende o apaga el equipo y arranca el diagnóstico de la pantalla (tecla E)
void encenderApagar() {
  if (equipo.encendido) {
    monitor.apagar("Apagado");
    avisar("Apagaste el equipo", INFO);
  } else {
    monitor.encender();
    if (equipo.laptop)
      vistaInicial();
  }
}

// enfocar(p) · Acerca la cámara a la pieza p (tecla F)
void enfocar(Pieza p) {
  if (p == null)
    return;
  float[] m = p.instalada ? equipo.localAMundo(p.x, p.h, p.z) : equipo.posBandeja(p);
  cam.enfocar(m[0], m[1], m[2], equipo.laptop ? 420 : 700);
  ui.seleccion = p;
}

// piezaSugerida() · Pieza del siguiente paso, para enfocarla
Pieza piezaSugerida() {
  return equipo.siguientePaso(ui.armando);
}

// ---- Cámara del dispositivo (librería Video) ----
// iniciarCamara() · Abre la cámara web con la librería Video; si no hay, sigue sin ella
void iniciarCamara() {
  try {
    if (camara == null) {
      String[] lista = Capture.list();
      if (lista == null || lista.length == 0) {
        estadoCamara = "No se encontró ninguna cámara en este dispositivo";
        avisar(estadoCamara, AVISO);
        return;
      }
      camara = new Capture(this, 640, 480, lista[0]);
    }
    camara.start();
    estadoCamara = "Abriendo la cámara…";
  }
  catch (Throwable ex) {
    camara = null;
    estadoCamara = "No se pudo abrir la cámara";
    avisar(estadoCamara + ": " + ex.getMessage(), AVISO);
  }
}

// detenerCamara() · Detiene la cámara web
void detenerCamara() {
  if (camara != null)
    camara.stop();
  camaraLista = false;
}

// captureEvent(c) · Evento de la librería Video: lee el cuadro nuevo de la cámara
void captureEvent(Capture c) {
  c.read();
  camaraLista = true;
}

// ---- Entrada: mouse y teclado ----
// @mousePressed() · Evento al presionar: guarda dónde empezó y qué botón, y toma los controles del panel de luz
void mousePressed() {
  pressX = mouseX;
  pressY = mouseY;
  arrastrando = false;
  botonPresionado = mouseButton;
  mousePresionadoLuz();
}

// @mouseDragged() · Arrastrar: gira la cámara, la desplaza (Shift o botón central) o mueve controles del panel de luz
void mouseDragged() {
  if (modo != TALLER)
    return;
  if (!arrastrando && dist(mouseX, mouseY, pressX, pressY) > 4 && !ui.sobrePanel(pressX, pressY))
    arrastrando = true;
  if (arrastrando) {
    float dx = mouseX - pmouseX, dy = mouseY - pmouseY;
    if (botonPresionado == CENTER || shift)
      cam.desplazar(dx, dy);
    else
      cam.girar(dx, dy);
  }
}

// @mouseReleased() · Si no hubo arrastre es un clic: va a la interfaz 2D o a la herramienta sobre la escena 3D
void mouseReleased() {
  if (!arrastrando) {
    if (modo == MENU || mostrarAyuda || ui.sobrePanel(mouseX, mouseY))
      clic = true;
    else if (botonPresionado == LEFT)
      equipo.usar(hover);
  }
  arrastrando = false;
  controlLuz = -1;
}

// @mouseWheel(ev) · Rueda del mouse: acerca o aleja la cámara
void mouseWheel(MouseEvent ev) {
  if (modo == TALLER)
    cam.zoom(ev.getCount());
}

// @keyPressed() · Atajos de teclado: herramientas 1-4, U, V, E, F, R, H, M, L, I, T, O, K, X (RTX) y N (sonido)
void keyPressed() {
  if (key == ESC) {
    key = 0;
    mostrarAyuda = false;
    return;
  }
  if (key == CODED) {
    if (keyCode == SHIFT)
      shift = true;
    return;
  }
  if (modo != TALLER)
    return;
  char k = Character.toLowerCase(key);
  if (k >= '1' && k <= '4')
    herramienta = k - '1';
  else if (k == 'u')
    alternarPulsera();
  else if (k == 'v')
    voltear();
  else if (k == 'e')
    encenderApagar();
  else if (k == 'f')
    enfocar(piezaSugerida());
  else if (k == 'r')
    vistaInicial();
  else if (k == 'h')
    mostrarAyuda = !mostrarAyuda;
  else if (k == 'm')
    irAlMenu();
  else if (k == 'l')
    cambiarModoLuz();
  else if (k == 'i')
    panelLuz = !panelLuz;
  else if (k == 't') {
    linterna = !linterna;
    avisar(linterna ? "Linterna encendida: apunta con el mouse" : "Linterna apagada", INFO);
  } else if (k == 'k') {
    luzTrabajo = !luzTrabajo;
    avisar(luzTrabajo ? "Lámpara de trabajo encendida" : "Lámpara de trabajo apagada", INFO);
  } else if (k == 'o') {
    luzAro = !luzAro;
    avisar(luzAro ? "Luz de aro encendida (ilumina desde la cámara)" : "Luz de aro apagada", INFO);
  } else if (k == 'x')
    alternarRTX();
  else if (k == 'n') {
    sonidoActivo = !sonidoActivo;
    avisar(sonidoActivo ? "Sonido activado" : "Sonido desactivado", INFO);
  }
}

// keyReleased() · Suelta la tecla Shift
void keyReleased() {
  if (key == CODED && keyCode == SHIFT)
    shift = false;
}

// ---- Sonido ----
boolean sonidoActivo = true;

// @sonido(nombre) · Reproduce data/sonidos/<nombre>.wav con Java Sound (sin librerías extra)
void sonido(String nombre) {
  if (!sonidoActivo)
    return;
  try {
    File f = new File(dataPath("sonidos/" + nombre + ".wav"));
    if (!f.exists())
      return;
    AudioInputStream entrada = AudioSystem.getAudioInputStream(f);
    final Clip clip = AudioSystem.getClip();
    clip.open(entrada);
    clip.addLineListener(new LineListener() {
      // update(ev) · Cierra el clip cuando termina de sonar para liberar la línea de audio
      public void update(LineEvent ev) {
        if (ev.getType() == LineEvent.Type.STOP)
          clip.close();
      }
    });
    clip.start();
  }
  catch (Exception ex) {
    sonidoActivo = false;
    println("Sin sonido: " + ex.getMessage());
  }
}
