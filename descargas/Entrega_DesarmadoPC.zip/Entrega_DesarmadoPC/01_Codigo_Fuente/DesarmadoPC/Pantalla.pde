// ============================================================
// PANTALLA SIMULADA · encendido, diagnóstico, POST, temperatura y cámara
// ============================================================

// ---- Fases ----
final static int APAGADA = 0;
final static int POST = 1;
final static int CARGANDO = 2;
final static int SISTEMA = 3;
final static int SIN_IMAGEN = 4;
final static int ERROR_ARRANQUE = 5;
final static int CALOR = 6;

// ---- Pantalla ----
// @class Pantalla · Pantalla simulada: diagnóstico, POST, carga, sistema, temperatura y cámara
class Pantalla {
  PGraphics pg;
  int fase = APAGADA, t = 0;
  float temp = 30, rpm = 0;
  String diagnostico = "", detalle = "";
  boolean errorCmos = false, pitidos = false;
  ArrayList<String> post = new ArrayList<String>();

  Pantalla() {
    pg = createGraphics(640, 400, P2D);
  }

  // e() · Equipo actual
  Equipo e() {
    return equipo;
  }

  // encendida() · true si no está apagada
  boolean encendida() {
    return fase != APAGADA;
  }

  // @hayImagen() · true si la pantalla muestra algo (sirve también para la luz que emite)
  boolean hayImagen() {
    return fase == POST || fase == CARGANDO || fase == SISTEMA || fase == ERROR_ARRANQUE || fase == CALOR;
  }

  // camaraActiva() · true si el sistema muestra la cámara web
  boolean camaraActiva() {
    return fase == SISTEMA && camara != null;
  }

  // imagen() · PGraphics con la imagen actual de la pantalla
  PImage imagen() {
    return pg;
  }

  // ---- Encender y apagar ----
  // @encender() · Revisa energía, arranque y video y decide en qué fase empieza
  void encender() {
    Equipo e = e();
    if (e.laptop && !e.enUso) {
      e.enUso = true;
      encenderAlAbrir = true;
      avisar("Volteando y abriendo la laptop…", INFO);
      return;
    }
    String falta = sinEnergia();
    if (falta != null) {
      diagnostico = "No enciende";
      detalle = falta;
      avisar("No enciende: " + falta, ERROR_);
      return;
    }
    e.encendido = true;
    t = 0;
    temp = max(temp, 32);
    pitidos = false;
    errorCmos = false;
    post.clear();
    String sinArranque = sinArranque();
    if (sinArranque != null) {
      fase = SIN_IMAGEN;
      diagnostico = "Enciende, pero no arranca";
      detalle = sinArranque;
      avisar("Los ventiladores giran pero no hay imagen: " + sinArranque, ERROR_);
      return;
    }
    String sinVideo = sinVideo();
    if (sinVideo != null) {
      fase = SIN_IMAGEN;
      diagnostico = "Sin imagen";
      detalle = sinVideo;
      avisar("Enciende pero la pantalla está negra: " + sinVideo, ERROR_);
      return;
    }
    fase = POST;
    sonido("pitido");
    diagnostico = "Arrancando";
    detalle = "Prueba de encendido (POST)";
    errorCmos = !e.puesta("cmos");
    armarPost();
    avisar("¡Encendió! Revisando componentes…", BIEN);
    if (e.laptop && !e.puesta("tapa"))
      avisar("Encendiste la laptop sin la tapa inferior: los componentes quedan expuestos", AVISO);
  }

  // apagar(motivo) · Apaga el equipo y guarda el diagnóstico
  void apagar(String motivo) {
    Equipo e = e();
    e.encendido = false;
    fase = APAGADA;
    diagnostico = motivo;
    detalle = "";
    if (camara != null)
      detenerCamara();
  }

  // ---- Revisiones: energía, arranque, video y disco ----
  // sinEnergia() · Qué impide que llegue energía (null = hay energía)
  String sinEnergia() {
    Equipo e = e();
    if (e.laptop) {
      boolean bateria = e.puesta("bateria") && conectorConectado("bateria");
      if (!bateria && !conectorConectado("cargador"))
        return "no hay energía: la batería no está conectada y el cargador tampoco";
      if (!e.puesta("placa"))
        return "falta la placa madre";
      return null;
    }
    if (!e.puesta("psu"))
      return "falta la fuente de poder";
    if (!conectorConectado("corriente"))
      return "el cable de corriente está desconectado";
    if (!e.puesta("placa"))
      return "falta la placa madre";
    if (!conectorConectado("atx24"))
      return "la placa no recibe energía: conecta el cable de 24 pines";
    return null;
  }

  // sinArranque() · Qué impide el arranque: CPU, RAM o placa
  String sinArranque() {
    Equipo e = e();
    if (!e.laptop) {
      if (!e.puesta("cpu"))
        return "falta el procesador";
      if (!conectorConectado("eps8"))
        return "el procesador no recibe energía: conecta el cable de CPU de 8 pines";
    }
    if (!hayRam()) {
      pitidos = true;
      return "no hay memoria RAM (la placa emite pitidos de error)";
    }
    return null;
  }

  // sinVideo() · Qué impide que haya imagen
  String sinVideo() {
    Equipo e = e();
    if (e.laptop) {
      if (!conectorConectado("pantalla"))
        return "el cable de pantalla (eDP) está desconectado";
      return null;
    }
    if (e.modelo.gpu > 0) {
      if (!e.puesta("gpu"))
        return "falta la tarjeta gráfica (el monitor se conecta a ella)";
      if (!conectorConectado("pcie"))
        return "la tarjeta gráfica no tiene su cable de energía PCIe";
    }
    if (!conectorConectado("video"))
      return "el cable de video del monitor está desconectado";
    return null;
  }

  // hayDisco() · true si hay una unidad de arranque conectada
  boolean hayDisco() {
    Equipo e = e();
    if (e.laptop)
      return e.puesta("ssd") || e.puesta("ssd2") || (e.puesta("hdd") && conectorConectado("sata"));
    return e.puesta("m2") || discoSata("hdd", "") || discoSata("hdd2", "2");
  }

  // discoSata(id, suf) · true si el disco SATA tiene cable de datos y de energía
  boolean discoSata(String id, String suf) {
    return e().puesta(id) && conectorConectado("sata" + suf + "_datos") && conectorConectado("sata" + suf + "_energia");
  }

  // hayRam() · true si hay memoria instalada
  boolean hayRam() {
    Equipo e = e();
    if (e.modelo.ramSoldada)
      return true;
    for (Pieza p : e.piezas)
      if ((p.tipo == T_RAM_SODIMM || p.tipo == T_RAM_DIMM) && e.puesta(p.id))
        return true;
    return false;
  }

  // modulosRam() · Cuántos módulos de RAM hay
  int modulosRam() {
    int n = 0;
    for (Pieza p : e().piezas)
      if ((p.tipo == T_RAM_SODIMM || p.tipo == T_RAM_DIMM) && e().puesta(p.id))
        n++;
    return n;
  }

  // revisarEnergia() · Apaga de golpe si se quita la energía estando encendido
  void revisarEnergia() {
    if (encendida() && sinEnergia() != null) {
      apagar("Se apagó: se quedó sin energía");
      avisar("El equipo se apagó de golpe: se quedó sin energía", AVISO);
    }
  }

  // armarPost() · Líneas del BIOS con los datos del modelo
  void armarPost() {
    Equipo e = e();
    Modelo m = e.modelo;
    post.add("SimTech BIOS  v2.47   (C) Taller Virtual   ·   " + m.nombre);
    post.add("");
    post.add("Procesador: " + m.cpu);
    if (m.ramSoldada)
      post.add("Memoria: " + m.ram + "  [OK]");
    else {
      String r = "";
      for (Pieza p : e.piezas)
        if (p.tipo == T_RAM_SODIMM || p.tipo == T_RAM_DIMM)
          r += "[" + (e.puesta(p.id) ? "OK" : "--") + "] ";
      post.add("Memoria: " + modulosRam() + " × " + m.ram + "  " + r);
    }
    if (e.laptop) {
      post.add("Almacenamiento: " + (e.puesta("ssd") ? "SSD NVMe" : "M.2 vacío") + (m.ssd2 ? " · " + (e.puesta("ssd2") ? "SSD NVMe 2" : "M.2 2 vacío") : "")
        + (m.hdd25 ? " · " + (e.puesta("hdd") && conectorConectado("sata") ? "SATA 2.5\"" : "SATA vacío") : ""));
      post.add("Red inalámbrica: " + (m.wifiSoldada ? "integrada en la placa" : (e.puesta("wifi") ? "detectada" : "no detectada")));
    } else {
      post.add("M.2: " + (e.puesta("m2") ? "SSD NVMe" : "vacío"));
      for (int i = 1; i <= m.discos; i++)
        post.add("SATA " + i + ": " + (discoSata(i == 1 ? "hdd" : "hdd2", i == 1 ? "" : "2") ? "Disco duro" : "no detectado"));
      if (m.optico)
        post.add("SATA óptico: " + (e.puesta("odd") && conectorConectado("sata_odd_datos") && conectorConectado("sata_odd_energia") ? "DVD-RW" : "no detectado"));
    }
    post.add("Video: " + m.video);
    post.add("Ventilador CPU: " + (ventiladorCpuOk() ? "OK" : "¡NO DETECTADO!"));
    if (errorCmos) {
      post.add("");
      post.add("Error de CMOS: fecha y hora restablecidas.");
      post.add("Se cargó la configuración predeterminada.");
    }
  }

  // ventiladorCpuOk() · true si el enfriamiento del CPU está completo
  boolean ventiladorCpuOk() {
    Equipo e = e();
    if (e.laptop)
      return e.puesta("disipador") && conectorConectado("ventilador") && (!e.modelo.dobleVentilador || conectorConectado("ventilador2"));
    return e.puesta("cooler") && conectorConectado("cpu_fan") && (e.modelo.cooler != 2 || e.puesta("radiador") && conectorConectado("rad_fan"));
  }

  // ---- Cada cuadro: temperatura y avance de fases ----
  // @actualizar() · Cada cuadro: temperatura, ventilador y avance de fases (POST, carga, sistema, calor)
  void actualizar() {
    Equipo e = e();
    if (encenderAlAbrir && e.laptop && e.volteo >= 1) {
      encenderAlAbrir = false;
      encender();
    }
    if (!e.encendido) {
      temp = lerp(temp, 26, 0.01);
      rpm = lerp(rpm, 0, 0.1);
      dibujarImagen();
      return;
    }
    t++;
    boolean disip = e.puesta(e.laptop ? "disipador" : "cooler");
    float meta = fase == SISTEMA ? 56 : 46;
    float rapidez = 0.003;
    if (!disip) {
      meta = 135;
      rapidez = 0.012;
    } else {
      if (e.pasta == PASTA_VIEJA)
        meta += 22;
      else if (e.pasta == PASTA_LIMPIA)
        meta += 58;
      if (!ventiladorCpuOk())
        meta += 58;
      if (!e.laptop)
        for (Pieza p : e.piezas)
          if (p.tipo == T_VENTILADOR && !(e.puesta(p.id) && ventiladorConectado(p.id)))
            meta += 5;
    }
    if (fase == SIN_IMAGEN && pitidos)
      meta = min(meta, 50);
    temp += (meta - temp) * rapidez;
    rpm = lerp(rpm, ventiladorCpuOk() ? 1100 + max(0, temp - 40) * 45 : 0, 0.05);
    if (temp >= 100 && fase != CALOR) {
      fase = CALOR;
      t = 0;
      sonido("alarma");
      avisar("¡Apagado de emergencia! El procesador llegó a " + round(temp) + " °C", ERROR_);
    }
    if (fase == CALOR && t > 200) {
      apagar("Apagado por sobrecalentamiento");
      diagnostico = "Apagado por temperatura";
      detalle = !disip ? "no tiene disipador" : (e.pasta != PASTA_NUEVA && e.pasta != PASTA_BUENA ? "le falta pasta térmica" : "el ventilador del CPU no gira");
      return;
    }
    if (fase == POST && t > (errorCmos ? 330 : 190)) {
      t = 0;
      if (hayDisco()) {
        fase = CARGANDO;
        detalle = "Cargando SimOS";
      } else {
        fase = ERROR_ARRANQUE;
        sonido("error");
        diagnostico = "Sin sistema operativo";
        detalle = "no hay unidad de almacenamiento";
        avisar("No se encontró un dispositivo de arranque: falta el " + (e.laptop ? "SSD" : "SSD o el disco duro"), ERROR_);
      }
    }
    if (fase == CARGANDO && t > 170) {
      fase = SISTEMA;
      t = 0;
      sonido("inicio");
      diagnostico = "Funcionando";
      detalle = "Cámara encendida";
      iniciarCamara();
      avisar("SimOS listo: se abrió la cámara", BIEN);
    }
    dibujarImagen();
  }

  // ---- Imagen de la pantalla ----
  // @dibujarImagen() · Pinta la imagen de la fase actual en el PGraphics de la pantalla
  void dibujarImagen() {
    pg.beginDraw();
    pg.textFont(fuenteMono);
    if (fase == POST)
      dibujarPost();
    else if (fase == CARGANDO)
      dibujarCarga();
    else if (fase == SISTEMA)
      dibujarSistema();
    else if (fase == ERROR_ARRANQUE) {
      pg.background(0);
      pg.fill(230);
      pg.textSize(16);
      pg.textAlign(LEFT, TOP);
      pg.text("No se encontró un dispositivo de arranque.\n\nInstala una unidad de almacenamiento con un\nsistema operativo y reinicia el equipo.", 30, 40);
      if (t % 60 < 30)
        pg.rect(30, 150, 10, 3);
    } else if (fase == CALOR) {
      pg.background(60, 0, 0);
      pg.fill(255);
      pg.textAlign(CENTER, CENTER);
      pg.textSize(22);
      pg.text("APAGADO DE EMERGENCIA", 320, 160);
      pg.textSize(16);
      pg.text("Temperatura crítica del procesador: " + round(temp) + " °C", 320, 205);
      pg.text("Revisa el disipador, la pasta térmica y el ventilador", 320, 235);
    } else
      pg.background(0);
    pg.endDraw();
  }

  // dibujarPost() · Pantalla del BIOS
  void dibujarPost() {
    pg.background(0);
    pg.fill(220);
    pg.textAlign(LEFT, TOP);
    pg.textSize(15);
    int n = min(post.size(), t / 14);
    for (int i = 0; i < n; i++) {
      String l = post.get(i);
      pg.fill(l.startsWith("Error") || l.contains("¡") ? color(255, 90, 80) : color(220));
      pg.text(l, 24, 24 + i * 22);
    }
    pg.fill(160);
    pg.text("Presiona SUPR para entrar a la configuración", 24, 360);
    pg.noFill();
    pg.stroke(80, 170, 255);
    pg.strokeWeight(3);
    pg.rect(520, 24, 92, 60, 8);
    pg.noStroke();
    pg.fill(80, 170, 255);
    pg.textAlign(CENTER, CENTER);
    pg.textSize(20);
    pg.text("ST", 566, 52);
  }

  // dibujarCarga() · Pantalla de carga de SimOS
  void dibujarCarga() {
    pg.background(14, 24, 48);
    pg.noStroke();
    pg.fill(90, 170, 255);
    pg.ellipse(320, 160, 70, 70);
    pg.fill(14, 24, 48);
    pg.ellipse(332, 150, 30, 30);
    pg.fill(235);
    pg.textAlign(CENTER, CENTER);
    pg.textSize(26);
    pg.text("SimOS", 320, 232);
    for (int i = 0; i < 6; i++) {
      float a = t * 0.08 + i * 0.5;
      pg.fill(235, 255 - i * 35);
      pg.ellipse(320 + cos(a) * 18, 300 + sin(a) * 18, 6, 6);
    }
  }

  // dibujarSistema() · Escritorio de SimOS con la cámara web
  void dibujarSistema() {
    for (int y = 0; y < 400; y += 8) {
      pg.noStroke();
      pg.fill(lerpColor(color(30, 70, 140), color(80, 40, 120), y / 400.0));
      pg.rect(0, y, 640, 8);
    }
    pg.fill(15, 18, 28, 235);
    pg.rect(0, 372, 640, 28);
    pg.fill(90, 170, 255);
    pg.ellipse(18, 386, 16, 16);
    pg.fill(235);
    pg.textAlign(RIGHT, CENTER);
    pg.textSize(13);
    pg.text(nf(hour(), 2) + ":" + nf(minute(), 2), 628, 386);
    Equipo e = e();
    String icons = (e.laptop ? (e.puesta("wifi") ? "Wi-Fi  " : "Sin Wi-Fi  ") : "Ethernet  ") + (e.laptop ? (conectorConectado("cargador") ? "Cargando  " : "Batería 87 %  ") : "");
    pg.text(icons, 575, 386);
    float wx = 40, wy = 18, ww = 560, wh = 342;
    pg.fill(25, 27, 34);
    pg.rect(wx, wy, ww, wh, 8);
    pg.fill(235);
    pg.textAlign(LEFT, CENTER);
    pg.text("Cámara", wx + 12, wy + 14);
    pg.fill(255, 90, 80);
    pg.ellipse(wx + ww - 20, wy + 14, 10, 10);
    float ix = wx + 6, iy = wy + 28, iw = ww - 12, ih = wh - 34;
    if (camara != null && camaraLista && camara.width > 0) {
      float ar = iw / ih, car = camara.width / (float) camara.height;
      int sx = 0, sy = 0, sw = camara.width, sh = camara.height;
      if (car > ar) {
        sw = round(camara.height * ar);
        sx = (camara.width - sw) / 2;
      } else {
        sh = round(camara.width / ar);
        sy = (camara.height - sh) / 2;
      }
      pg.pushMatrix();
      pg.translate(ix + iw, iy);
      pg.scale(-1, 1);
      pg.image(camara, 0, 0, iw, ih, sx, sy, sx + sw, sy + sh);
      pg.popMatrix();
      if (t % 60 < 30) {
        pg.fill(255, 60, 60);
        pg.ellipse(ix + 18, iy + 16, 10, 10);
      }
      pg.fill(255);
      pg.textAlign(LEFT, CENTER);
      pg.text("EN VIVO", ix + 28, iy + 16);
    } else {
      for (int y = (int) iy; y < iy + ih; y += 8)
        for (int x = (int) ix; x < ix + iw; x += 8) {
          pg.fill(random(30, 90));
          pg.rect(x, y, 8, 8);
        }
      pg.fill(0, 160);
      pg.rect(ix + 60, iy + ih / 2 - 40, iw - 120, 80, 8);
      pg.fill(240);
      pg.textAlign(CENTER, CENTER);
      pg.text(camara == null ? estadoCamara : "Esperando imagen de la cámara…", ix + iw / 2, iy + ih / 2);
    }
  }
}

// ---- Ayudas ----
// conectorConectado(id) · true si el conector id está conectado
boolean conectorConectado(String id) {
  for (Conector c : equipo.conectores)
    if (c.id.equals(id))
      return c.conectado && equipo.puesta(c.duenio) && equipo.puesta(c.destino);
  return false;
}

// ventiladorConectado(id) · true si el ventilador id está conectado
boolean ventiladorConectado(String id) {
  for (Conector c : equipo.conectores)
    if (c.duenio.equals(id))
      return c.conectado;
  return false;
}
