// ============================================================
// CATÁLOGO · los 8 modelos y la construcción de cada equipo
// ============================================================

// ---- Modelo ----
// @class Modelo · Datos de un modelo: medidas, estilo, colores y qué piezas trae
class Modelo {
  String id, nombre, clase, basadoEn, resumen;
  boolean laptop;
  int estilo;
  float W, D, H;
  float tapaGrosor = 6;
  color chasis, chasis2, tecla, leyenda, acento;
  boolean rgb, numpad, ramSoldada, wifiSoldada, ssd2, hdd25, dobleVentilador, bateriaGrande;
  String cpu, ram, disco, video, extra;
  int placa;
  int cooler;
  int gpu;
  int panel;
  int ventFrontales, discos, ramSlots = 2;
  boolean optico, sfx;
  PImage texTeclado, texLeyendas, texFondo, texTapa;
  float[][] teclas;
  String[] letras;
  float tpX0, tpZ0, tpX1, tpZ1;

  Modelo(String id, String nombre, boolean laptop, int estilo) {
    this.id = id;
    this.nombre = nombre;
    this.laptop = laptop;
    this.estilo = estilo;
  }
}

Modelo[] LAPTOPS, ESCRITORIOS;

// ---- Los 8 modelos (diseños propios basados en tipos de equipos reales) ----
// @crearCatalogo() · Define los 8 modelos (4 laptops y 4 PCs, diseños propios)
void crearCatalogo() {
  LAPTOPS = new Modelo[4];
  Modelo m = new Modelo("vortice", "Vórtice G14", true, 0);
  m.clase = "Laptop de juegos de 14\"";
  m.basadoEn = "laptops gamer compactas de 14 pulgadas";
  m.resumen = "Aluminio gris oscuro, barra RGB trasera y emblema iluminado.";
  m.W = 340;
  m.D = 234;
  m.H = 20;
  m.chasis = color(78, 80, 86);
  m.tecla = color(26, 27, 31);
  m.leyenda = color(205, 207, 212);
  m.acento = color(0, 200, 170);
  m.rgb = true;
  m.cpu = "8 núcleos @ 3.3 GHz (móvil)";
  m.ram = "SO-DIMM DDR5 de 8 GB";
  m.disco = "SSD NVMe 1 TB";
  m.video = "Gráfica dedicada 8 GB";
  LAPTOPS[0] = m;

  m = new Modelo("aero", "Aero 13", true, 1);
  m.clase = "Ultrabook de 13\"";
  m.basadoEn = "ultrabooks delgadas de aluminio";
  m.resumen = "Muy delgada y plateada. RAM y Wi-Fi soldadas, batería grande, un ventilador pequeño.";
  m.W = 300;
  m.D = 212;
  m.H = 15;
  m.tapaGrosor = 4.5;
  m.chasis = color(196, 199, 204);
  m.tecla = color(168, 171, 177);
  m.leyenda = color(40, 42, 46);
  m.acento = color(235);
  m.ramSoldada = true;
  m.wifiSoldada = true;
  m.bateriaGrande = true;
  m.cpu = "4 núcleos @ 2.4 GHz (bajo consumo)";
  m.ram = "16 GB LPDDR5 (soldada)";
  m.disco = "SSD NVMe 512 GB";
  m.video = "Gráficos integrados";
  LAPTOPS[1] = m;

  m = new Modelo("ofix", "Ofix 15", true, 2);
  m.clase = "Laptop empresarial de 15\"";
  m.basadoEn = "laptops de oficina resistentes y fáciles de reparar";
  m.resumen = "Negro mate, teclado numérico, lector de huella, tapa de cámara y bahía para disco de 2.5\".";
  m.W = 360;
  m.D = 246;
  m.H = 23;
  m.tapaGrosor = 6.5;
  m.chasis = color(44, 45, 49);
  m.tecla = color(22, 22, 25);
  m.leyenda = color(225);
  m.acento = color(70, 150, 255);
  m.numpad = true;
  m.hdd25 = true;
  m.cpu = "6 núcleos @ 2.6 GHz (empresarial)";
  m.ram = "SO-DIMM DDR4 de 8 GB";
  m.disco = "SSD NVMe 256 GB + SSD SATA 1 TB";
  m.video = "Gráficos integrados";
  LAPTOPS[2] = m;

  m = new Modelo("titan", "Titán 17", true, 3);
  m.clase = "Laptop de juegos de 17\"";
  m.basadoEn = "laptops gamer grandes que reemplazan a una PC";
  m.resumen = "Gruesa, negra con rojo, teclado RGB por tecla, tira de luz frontal y dos ventiladores.";
  m.W = 396;
  m.D = 290;
  m.H = 27;
  m.tapaGrosor = 8;
  m.chasis = color(34, 35, 40);
  m.tecla = color(18, 18, 21);
  m.leyenda = color(230);
  m.acento = color(230, 40, 50);
  m.rgb = true;
  m.numpad = true;
  m.ssd2 = true;
  m.dobleVentilador = true;
  m.cpu = "16 núcleos @ 4.0 GHz (alto rendimiento)";
  m.ram = "SO-DIMM DDR5 de 16 GB";
  m.disco = "2 × SSD NVMe 1 TB";
  m.video = "Gráfica dedicada 16 GB";
  LAPTOPS[3] = m;

  ESCRITORIOS = new Modelo[4];
  m = new Modelo("cristal", "Cristal ATX", false, 0);
  m.clase = "PC de juegos (torre mediana)";
  m.basadoEn = "torres gamer con panel de vidrio";
  m.resumen = "Vidrio templado, frente de malla con luz, cooler de torre y tarjeta gráfica de 2 ventiladores.";
  m.W = 450;
  m.H = 460;
  m.D = 210;
  m.placa = 0;
  m.cooler = 0;
  m.gpu = 2;
  m.panel = 0;
  m.ventFrontales = 1;
  m.discos = 1;
  m.chasis = color(30, 31, 35);
  m.acento = color(60, 200, 255);
  m.cpu = "8 núcleos @ 3.6 GHz";
  m.ram = "DIMM DDR4 de 8 GB";
  m.disco = "SSD NVMe 1 TB";
  m.video = "Tarjeta gráfica PCIe x16";
  ESCRITORIOS[0] = m;

  m = new Modelo("oficina", "Oficina mATX", false, 1);
  m.clase = "PC de oficina (torre compacta)";
  m.basadoEn = "PCs de oficina armadas de fábrica";
  m.resumen = "Panel lateral de acero, unidad de DVD, cooler de fábrica y video en la placa (sin tarjeta gráfica).";
  m.W = 380;
  m.H = 380;
  m.D = 180;
  m.placa = 1;
  m.cooler = 1;
  m.gpu = 0;
  m.panel = 1;
  m.ventFrontales = 0;
  m.discos = 1;
  m.optico = true;
  m.chasis = color(52, 54, 58);
  m.acento = color(90, 160, 255);
  m.cpu = "4 núcleos @ 3.2 GHz";
  m.ram = "DIMM DDR4 de 4 GB";
  m.disco = "Disco duro 1 TB";
  m.video = "Gráficos integrados (salida en la placa)";
  ESCRITORIOS[1] = m;

  m = new Modelo("cubo", "Cubo ITX", false, 2);
  m.clase = "PC compacta mini-ITX";
  m.basadoEn = "gabinetes pequeños de sala (SFF)";
  m.resumen = "Aluminio plateado con frente de madera, placa mini-ITX, fuente SFX y gráfica compacta.";
  m.W = 330;
  m.H = 320;
  m.D = 205;
  m.placa = 2;
  m.cooler = 1;
  m.gpu = 1;
  m.panel = 2;
  m.ventFrontales = 0;
  m.discos = 0;
  m.sfx = true;
  m.chasis = color(190, 192, 196);
  m.acento = color(255, 190, 120);
  m.cpu = "6 núcleos @ 3.8 GHz";
  m.ram = "DIMM DDR5 de 16 GB";
  m.disco = "SSD NVMe 2 TB";
  m.video = "Tarjeta gráfica compacta";
  ESCRITORIOS[2] = m;

  m = new Modelo("estacion", "Estación Pro", false, 3);
  m.clase = "Estación de trabajo (torre grande)";
  m.basadoEn = "estaciones de trabajo para diseño y video";
  m.resumen = "Torre grande con asas, enfriamiento líquido, 4 memorias, 2 discos y tarjeta gráfica de 3 ventiladores.";
  m.W = 520;
  m.H = 540;
  m.D = 240;
  m.placa = 0;
  m.cooler = 2;
  m.gpu = 3;
  m.panel = 0;
  m.ventFrontales = 3;
  m.discos = 2;
  m.ramSlots = 4;
  m.chasis = color(26, 27, 30);
  m.acento = color(240, 240, 245);
  m.cpu = "24 núcleos @ 3.0 GHz";
  m.ram = "DIMM DDR5 ECC de 32 GB";
  m.disco = "SSD NVMe 2 TB";
  m.video = "Tarjeta gráfica profesional PCIe x16";
  ESCRITORIOS[3] = m;

  for (Modelo l : LAPTOPS)
    crearTexturasModelo(l);
}

// ---- Laptop: escala del diseño base de 340 × 234 × 20 mm ----
float LX = 1, LZ = 1, LH = 1;
// lx(x) · Escala una coordenada x de la laptop base al ancho del modelo
float lx(float x) {
  return x * LX;
}
// lz(z) · Escala una coordenada z al fondo del modelo
float lz(float z) {
  return z * LZ;
}
// lh(h) · Escala una altura al grosor del modelo
float lh(float h) {
  return h * LH;
}
// lt(p...) · Escala una lista de puntos (x, h, z) de tornillos
float[] lt(float... p) {
  float[] r = new float[p.length];
  for (int i = 0; i + 2 < p.length; i += 3) {
    r[i] = lx(p[i]);
    r[i + 1] = lh(p[i + 1]);
    r[i + 2] = lz(p[i + 2]);
  }
  return r;
}

// crearLaptop() · Laptop del primer modelo
Equipo crearLaptop() {
  return crearLaptop(LAPTOPS[0]);
}

// @crearLaptop(m) · Construye una laptop: piezas, tornillos, cables, dependencias y orden de desarmado
Equipo crearLaptop(Modelo m) {
  Equipo e = new Equipo(m.nombre, true);
  e.modelo = m;
  LX = m.W / 340.0;
  LZ = m.D / 234.0;
  LH = m.H / 20.0;
  float ka = min(1, LH);
  color negro = color(30);
  ArrayList<String> orden = new ArrayList<String>();

  e.agregar(new Pieza("tapa", "Tapa inferior", T_TAPA_LAPTOP, 0, 1, 0, m.W, 2, m.D, m.chasis))
    .texto("Cubierta inferior que protege los componentes. Tiene rejillas para que entre aire a " + (m.dobleVentilador ? "los ventiladores." : "el ventilador."),
    "Quita los 10 tornillos y libera los clips con la púa de plástico, empezando por una esquina. Nunca uses un desarmador como palanca: rayas y rompes los clips.")
    .con(PUA)
    .tornillos(0, -1, 0, lt(-160, 0, -105, -160, 0, 0, -160, 0, 105, 160, 0, -105, 160, 0, 0, 160, 0, 105, -60, 0, -108, 60, 0, -108, -60, 0, 108, 60, 0, 108));
  orden.add("tapa");

  float bd = 64 * LZ * (m.bateriaGrande ? 1.45 : 1), bz = m.bateriaGrande ? lz(72) : lz(80);
  float bw = 260 * LX * (m.hdd25 ? 0.62 : 1), bxc = m.hdd25 ? lx(-55) : 0;
  e.agregar(new Pieza("bateria", "Batería", T_BATERIA, bxc, lh(6.5), bz, bw, 9 * ka, bd, color(38)))
    .texto("Batería de iones de litio. Da energía cuando no está conectado el cargador.",
    "Es lo PRIMERO que se desconecta al abrir la laptop: así ningún circuito tiene corriente mientras trabajas. Desconecta su cable de la placa y quita sus 4 tornillos.")
    .tras("tapa")
    .tornillos(0, -1, 0, bxc - bw / 2 + 8, lh(2), bz - bd / 2 + 6, bxc + bw / 2 - 8, lh(2), bz - bd / 2 + 6, bxc - bw / 2 + 8, lh(2), bz + bd / 2 - 6, bxc + bw / 2 - 8, lh(2), bz + bd / 2 - 6);
  orden.add("bateria");

  e.agregar(new Pieza("bocina_izq", "Bocina izquierda", T_BOCINA, lx(-151.5), lh(6), lz(86), 27, 8 * ka, 52, negro))
    .texto("Pequeña bocina para el sonido.", "Desconecta su cable de la placa y quita 2 tornillos.")
    .tras("tapa")
    .tornillos(0, -1, 0, lt(-151.5, 2, 64, -151.5, 2, 108));
  e.agregar(new Pieza("bocina_der", "Bocina derecha", T_BOCINA, lx(151.5), lh(6), lz(86), 27, 8 * ka, 52, negro))
    .texto("Pequeña bocina para el sonido.", "Desconecta su cable de la placa y quita 2 tornillos.")
    .tras("tapa")
    .tornillos(0, -1, 0, lt(151.5, 2, 64, 151.5, 2, 108));
  orden.add("bocina_izq");
  orden.add("bocina_der");

  if (!m.ramSoldada) {
    e.agregar(new Pieza("ram2", "RAM (ranura superior)", T_RAM_SODIMM, lx(25), lh(4.5), lz(-5), 70, 1.2, 30, color(20, 110, 60)))
      .texto("Módulo " + m.ram + ". Guarda temporalmente los programas en uso; se borra al apagar.",
      "Abre hacia afuera los dos seguros laterales: el módulo se levanta en ángulo y sale jalándolo. Tómalo por los bordes, sin tocar los contactos dorados.")
      .tras("tapa").sensible();
    e.agregar(new Pieza("ram1", "RAM (ranura inferior)", T_RAM_SODIMM, lx(25), lh(8.5), lz(-5), 70, 1.2, 30, color(20, 110, 60)))
      .texto("Segundo módulo " + m.ram + ", debajo del primero.",
      "Solo se alcanza después de quitar el módulo de arriba. Mismo procedimiento: abrir seguros y sacar en ángulo.")
      .tras("tapa", "ram2").sensible();
    orden.add("ram2");
    orden.add("ram1");
  }

  e.agregar(new Pieza("ssd", "Unidad SSD M.2", T_M2, lx(-110), lh(11), lz(12), 80, 2.5, 22, color(20)))
    .texto("Unidad de estado sólido NVMe M.2 2280. Aquí está el sistema operativo y tus archivos.",
    "Quita su único tornillo: la tarjeta se levanta sola unos 20°. Sácala jalando en línea recta.")
    .tras("tapa").sensible()
    .tornillos(0, -1, 0, lt(-152, 9.6, 12));
  orden.add("ssd");
  if (m.ssd2) {
    e.agregar(new Pieza("ssd2", "Segunda unidad SSD M.2", T_M2, lx(-110), lh(11), lz(36), 80, 2.5, 22, color(20)))
      .texto("Segunda unidad NVMe para juegos y archivos grandes.", "Igual que la primera: un tornillo y sale en ángulo.")
      .tras("tapa").sensible()
      .tornillos(0, -1, 0, lt(-152, 9.6, 36));
    orden.add("ssd2");
  }
  if (m.hdd25) {
    float hx = lx(120), hz = lz(20);
    e.agregar(new Pieza("hdd", "Unidad SATA de 2.5\"", T_HDD25, hx, lh(6), hz, 100, 7, 70, color(170)))
      .texto("Unidad SATA de 2.5 pulgadas en su bahía. Las laptops empresariales la traen para guardar más archivos.",
      "Quita los 4 tornillos de su marco, desliza la unidad para separarla del conector SATA y levántala.")
      .tras("tapa").sensible()
      .tornillos(0, -1, 0, hx - 44, lh(2), hz - 30, hx + 44, lh(2), hz - 30, hx - 44, lh(2), hz + 30, hx + 44, lh(2), hz + 30);
    orden.add("hdd");
  }
  if (!m.wifiSoldada) {
    e.agregar(new Pieza("wifi", "Tarjeta Wi-Fi", T_WIFI, lx(-45), lh(11), lz(20), 30, 2.5, 22, color(20, 90, 60)))
      .texto("Tarjeta inalámbrica M.2 2230 (Wi-Fi y Bluetooth). Sus antenas van por la bisagra hasta la tapa.",
      "Desconecta los dos cables de antena levantándolos en vertical (son muy frágiles) y quita su tornillo.")
      .tras("tapa").sensible()
      .tornillos(0, -1, 0, lt(-62, 9.6, 20));
    orden.add("wifi");
  }

  e.agregar(new Pieza("cmos", "Pila CMOS", T_CMOS, lx(-120), lh(11.5), lz(-85), 20, 3, 20, color(195)))
    .texto("Pila de botón CR2032. Mantiene la fecha, la hora y la configuración del BIOS cuando no hay corriente.",
    "Se saca con la mano o con la púa. Si la quitas, el BIOS vuelve a su configuración de fábrica.")
    .tras("tapa");
  orden.add("cmos");

  float cx = lx(-40), cz = lz(-60);
  float dx = cx + 87.5, dz = cz - 10;
  Pieza dis = e.agregar(new Pieza("disipador", m.dobleVentilador ? "Disipador y ventiladores" : "Disipador y ventilador", T_DISIPADOR_LAPTOP, dx, lh(8.25), dz, 225, 8.5 * ka, 70, color(190, 110, 70)))
    .texto(m.dobleVentilador ? "Dos tubos de calor de cobre y dos ventiladores tipo turbina: uno para el procesador y otro para la gráfica."
    : (m.estilo == 1 ? "Disipador delgado con un ventilador pequeño: en una ultrabook el espacio es mínimo." : "Placa de cobre sobre el procesador, tubo de calor y ventilador tipo turbina. Saca el calor por la rejilla."),
    "Desconecta el cable del ventilador. Afloja los tornillos de la placa de cobre en orden cruzado y quita los de " + (m.dobleVentilador ? "los ventiladores." : "el ventilador."))
    .tras("tapa")
    .tornillos(0, -1, 0, cx - 18, lh(4), cz - 20, cx + 18, lh(4), cz + 20, cx + 18, lh(4), cz - 20, cx - 18, lh(4), cz + 20, dx + 52.5, lh(4), dz - 28, dx + 104.5, lh(4), dz + 28);
  dis.variante = m.dobleVentilador ? 1 : (m.estilo == 1 ? 2 : 0);
  if (m.dobleVentilador)
    dis.tornillos(0, -1, 0, dx - 165, lh(4), dz - 28);
  orden.add("disipador");

  e.agregar(new Pieza("cpu", "Procesador (CPU)", T_CPU, cx, lh(12.6), cz, 30, 1.2, 26, color(30, 90, 50)))
    .texto("El cerebro del equipo (" + m.cpu + "). En las laptops va soldado a la placa (BGA).",
    "va soldado a la placa (BGA). Solo se limpia la pasta vieja y se pone nueva (tecla 4).")
    .tras("disipador").fija().sensible();

  ArrayList<String> sobrePlaca = new ArrayList<String>();
  sobrePlaca.add("tapa");
  for (String id : new String[] {"ram1", "ram2", "ssd", "ssd2", "wifi", "disipador", "cmos", "hdd"})
    if (e.pieza(id) != null)
      sobrePlaca.add(id);
  e.agregar(new Pieza("placa", "Placa madre", T_PLACA_LAPTOP, lx(-40), lh(13.8), lz(-37.5), 240 * LX, 1.6, 145 * LZ, color(25, 95, 55)))
    .texto("Tarjeta principal: une todos los componentes." + (m.ramSoldada ? " En este modelo la RAM y el Wi-Fi van soldados en ella." : " En laptops trae el procesador y el chip de video soldados."),
    "Retira primero todo lo que va montado en ella, desconecta pantalla, teclado, touchpad, batería y bocinas, y quita sus 6 tornillos.")
    .tras(sobrePlaca.toArray(new String[0])).sensible()
    .tornillos(0, -1, 0, lt(-155, 13, -105, -40, 13, -105, 75, 13, -105, -155, 13, 30, -95, 13, 30, 75, 13, 30));
  orden.add("placa");
  for (String id : sobrePlaca)
    if (!id.equals("tapa"))
      e.base(id, "placa");

  // ---- Cables y conectores ----
  Pieza bat = e.pieza("bateria");
  e.agregar(new Conector("bateria", "Cable de la batería", bat.x, lh(9), bat.z - bat.d / 2 - 7, 24, 3.5, 7))
    .une("bateria", "placa").tras("tapa").salida(0, 0, 1).tono(color(240))
    .cable(color(30), 4, bat.x, lh(7), bat.z - bat.d / 2 - 1)
    .texto("Desconéctalo antes de tocar cualquier otra cosa dentro de la laptop.");
  e.agregar(new Conector("ventilador", "Cable del ventilador", lx(88), lh(10), lz(-28), 8, 3, 5))
    .une("disipador", "placa").tras("tapa").salida(0, -1, 0).tono(color(240))
    .cable(color(200, 40, 40), 2, dx + 52.5, lh(8), dz + 30);
  if (m.dobleVentilador)
    e.agregar(new Conector("ventilador2", "Cable del segundo ventilador", lx(-75), lh(10), lz(-28), 8, 3, 5))
      .une("disipador", "placa").tras("tapa").salida(0, -1, 0).tono(color(240))
      .cable(color(200, 40, 40), 2, dx - 140, lh(8), dz + 30);
  e.agregar(new Conector("bocina_izq", "Cable de la bocina izquierda", lx(-145), lh(10), lz(28), 8, 3, 5))
    .une("bocina_izq", "placa").tras("tapa").salida(0, -1, 0).tono(color(240))
    .cable(color(30), 2, lt(-150, 6, 60));
  e.agregar(new Conector("bocina_der", "Cable de la bocina derecha", lx(72), lh(10), lz(28), 8, 3, 5))
    .une("bocina_der", "placa").tras("tapa").salida(0, -1, 0).tono(color(240))
    .cable(color(30), 2, lt(140, 6, 40, 150, 6, 60));
  if (!m.wifiSoldada) {
    e.agregar(new Conector("antena1", "Antena Wi-Fi principal", lx(-52), lh(9.2), lz(26), 4, 2, 4))
      .une("", "wifi").tras("tapa").salida(0, -1, 0).tono(color(220, 180, 70))
      .cable(color(25), 1.5, lt(-52, 8, 40, -163, 8, 40, -163, 8, -112, -150, 8, -117));
    e.agregar(new Conector("antena2", "Antena Wi-Fi auxiliar", lx(-40), lh(9.2), lz(26), 4, 2, 4))
      .une("", "wifi").tras("tapa").salida(0, -1, 0).tono(color(220, 180, 70))
      .cable(color(235), 1.5, lt(-40, 8, 42, -161, 8, 42, -161, 8, -110, -146, 8, -117));
  }
  if (m.hdd25) {
    Pieza hd = e.pieza("hdd");
    e.agregar(new Conector("sata", "Conector SATA de la bahía", hd.x + 10, lh(6), hd.z - 39, 18, 5, 4))
      .une("hdd", "placa").tras("tapa").salida(0, 0, -1).tono(color(30))
      .cable(color(200, 150, 60), 5, hd.x + 10, lh(10), hd.z - 46, lx(60), lh(12), lz(-20))
      .texto("Cinta flexible que une la bahía de 2.5\" con la placa.");
  }
  e.agregar(new Conector("pantalla", "Cable de pantalla (eDP)", lx(-125), lh(12), lz(-100), 26, 2.5, 7))
    .une("", "placa").tras("tapa").salida(0, -1, 0).tono(color(30))
    .cable(color(60), 5, lt(-125, 11, -108, -140, 11, -117))
    .texto("Lleva la imagen a la pantalla. Se jala de la cinta en línea recta, nunca de los cables.");
  e.agregar(new Conector("teclado", "Cinta del teclado", lx(-60), lh(12.2), lz(31), 24, 1.5, 5))
    .une("", "placa").tras("tapa").salida(0, -1, 0).tono(color(240))
    .cable(color(200, 150, 60), 6, lt(-60, 14, 40));
  e.agregar(new Conector("touchpad", "Cinta del touchpad", lx(40), lh(12.2), lz(31), 14, 1.5, 5))
    .une("", "placa").tras("tapa").salida(0, -1, 0).tono(color(240))
    .cable(color(200, 150, 60), 5, lt(40, 14, 45));
  Conector cargador = e.agregar(new Conector("cargador", "Cargador", -m.W / 2 - 6, lh(8), lz(-60), 12, 5, 7))
    .une("", "").salida(-1, 0, 0).tono(color(25))
    .texto("Alimenta la laptop y carga la batería. Con cargador la laptop enciende aunque no tenga batería.");
  cargador.conectado = false;

  e.orden = orden.toArray(new String[0]);
  acomodarBandeja(e);
  return e;
}

// ---- Escritorio ----
// crearEscritorio() · PC del primer modelo
Equipo crearEscritorio() {
  return crearEscritorio(ESCRITORIOS[0]);
}

// @crearEscritorio(m) · Construye una PC: posiciones calculadas desde el gabinete y la placa madre
Equipo crearEscritorio(Modelo m) {
  Equipo e = new Equipo(m.nombre, false);
  e.modelo = m;
  float x0 = -m.W / 2, x1 = m.W / 2, zb = -m.D / 2, zf = m.D / 2, H = m.H;
  float bw = m.placa == 2 ? 170 : 244, bhh = m.placa == 0 ? 305 : (m.placa == 1 ? 244 : 170);
  float btop = H - (m.cooler == 2 ? 110 : 35), bzc = zb + 16;
  float bxL = x0 + 10;
  float pbx = bxL + bw / 2, pbh = btop - bhh / 2;
  boolean itx = m.placa == 2;
  ArrayList<String> orden = new ArrayList<String>();
  color negro = color(25);
  String[] nombresPlaca = {"ATX", "micro-ATX", "mini-ITX"};

  String[] panelNombre = {"Panel lateral de vidrio", "Panel lateral de acero", "Panel lateral de malla"};
  Pieza panel = e.agregar(new Pieza("panel", panelNombre[m.panel], T_PANEL, 0, H / 2, zf - 1, m.W, H, 4, color(150, 190, 220)))
    .texto(m.panel == 0 ? "Tapa lateral de vidrio templado. Deja ver el interior y protege los componentes."
    : (m.panel == 1 ? "Tapa lateral de acero con rejilla de ventilación. Es la típica de las PCs de oficina." : "Tapa de malla de aluminio: deja pasar mucho aire, ideal en gabinetes pequeños."),
    "Afloja sus 2 tornillos de mano (aquí: clic con el destornillador) y retira el panel sosteniéndolo con las dos manos.")
    .tornillos(0, 0, 1, x0 + 20, 40, zf + 1, x0 + 20, H - 40, zf + 1);
  panel.variante = m.panel;
  panel.acostar = true;
  for (Tornillo t : panel.tornillos)
    t.grande = true;
  orden.add("panel");

  float cpuRx = itx ? 85 : 120, cpuRy = itx ? 70 : 95;
  float cpx = bxL + cpuRx, cph = btop - cpuRy;
  if (m.gpu > 0) {
    float gw = m.gpu == 1 ? 190 : (m.gpu == 2 ? 300 : 320), ga = m.gpu == 3 ? 55 : 40;
    float gry = itx ? 175 : (m.placa == 1 ? 175 : 205);
    float gh = btop - gry, gz = -33 + (m.D - 210) / 2 * 0;
    Pieza g = e.agregar(new Pieza("gpu", "Tarjeta gráfica", T_GPU, bxL + gw / 2, gh, gz, gw, ga, 110, color(40)))
      .texto("Procesa las imágenes y las envía al monitor (" + m.video + "). Tiene su propio procesador (GPU), memoria y ventiladores.",
      "Desconecta el cable de video y el de energía PCIe. Quita los 2 tornillos del soporte trasero, presiona el seguro de la ranura PCIe y jálala hacia afuera.")
      .tras("panel").sensible()
      .tornillos(0, 0, 1, x0 + 6, gh + 24, gz + 57, x0 + 6, gh + 6, gz + 57);
    g.variante = m.gpu;
    orden.add("gpu");
  }
  int nram = m.ramSlots;
  for (int i = nram; i >= 1; i--) {
    float rx = itx ? 140 + (i - 1) * 12 : 173 + (i - 1) * 12 + (nram == 2 ? 12 : 0);
    Pieza r = e.agregar(new Pieza("ram" + i, "Memoria RAM " + i, T_RAM_DIMM, bxL + rx, btop - 92.5 + (itx ? 6 : 0), -72 + (m.D - 210) / 2 * 0, 2, 133, 33, color(20, 110, 60)))
      .texto("Módulo " + m.ram + ".", "Empuja hacia abajo los seguros de los extremos y jala el módulo derecho hacia afuera, sin doblarlo.")
      .tras("panel").sensible();
    r.deLado = true;
    orden.add("ram" + i);
  }
  if (m.cooler == 2) {
    float rx = pbx + 40, rh = H - 30;
    Pieza rad = e.agregar(new Pieza("radiador", "Radiador (enfriamiento líquido)", T_RADIADOR, rx, rh, -5, 312, 52, 140, color(30)))
      .texto("Radiador de 280 mm con dos ventiladores. El líquido caliente que viene de la bomba se enfría aquí.",
      "Desconecta el cable de sus ventiladores (RAD_FAN) y quita los 4 tornillos del techo del gabinete. Sostenlo: queda unido a la bomba por las mangueras.")
      .tras("panel")
      .tornillos(0, 1, 0, rx - 120, H + 1, -55, rx + 120, H + 1, -55, rx - 120, H + 1, 45, rx + 120, H + 1, 45);
    orden.add("radiador");
  }
  String[] nombresCooler = {"Disipador de torre (cooler)", "Disipador de fábrica", "Bomba del enfriamiento líquido"};
  Pieza cool;
  if (m.cooler == 0)
    cool = e.agregar(new Pieza("cooler", nombresCooler[0], T_COOLER, cpx - 12.5, cph, -11 + (zb + 105) * 0, 135, 124, 150, color(200)))
      .texto("Disipador de aletas con tubos de calor y ventilador de 120 mm. Saca el calor del procesador.",
      "Desconecta su cable del conector CPU_FAN y afloja los 4 tornillos en orden cruzado. Gíralo un poco antes de levantarlo para despegar la pasta.")
      .tras("panel")
      .tornillos(0, 0, 1, cpx - 30, cph - 68, bzc + 11, cpx + 30, cph + 68, bzc + 11, cpx + 30, cph - 68, bzc + 11, cpx - 30, cph + 68, bzc + 11);
  else if (m.cooler == 1)
    cool = e.agregar(new Pieza("cooler", nombresCooler[1], T_COOLER, cpx, cph, bzc + 30, 96, 96, 44, color(170)))
      .texto("Disipador redondo de aluminio con ventilador encima: el que viene en la caja del procesador.",
      "Desconecta su cable (CPU_FAN) y gira los 4 seguros de plástico un cuarto de vuelta (aquí: clic con el destornillador). Gíralo un poco y levántalo.")
      .tras("panel")
      .tornillos(0, 0, 1, cpx - 37, cph - 37, bzc + 9, cpx + 37, cph + 37, bzc + 9, cpx + 37, cph - 37, bzc + 9, cpx - 37, cph + 37, bzc + 9);
  else
    cool = e.agregar(new Pieza("cooler", nombresCooler[2], T_COOLER, cpx, cph, bzc + 24, 62, 62, 32, color(30)))
      .texto("Bloque de la bomba: mueve el líquido por las mangueras hasta el radiador. Su base de cobre toca el procesador.",
      "Primero retira el radiador. Desconecta su cable (CPU_FAN) y afloja los 4 tornillos en orden cruzado.")
      .tras("panel", "radiador")
      .tornillos(0, 0, 1, cpx - 34, cph - 34, bzc + 9, cpx + 34, cph + 34, bzc + 9, cpx + 34, cph - 34, bzc + 9, cpx - 34, cph + 34, bzc + 9);
  cool.variante = m.cooler;
  cool.acostar = m.cooler > 0;
  orden.add("cooler");

  Pieza cpu = e.agregar(new Pieza("cpu", "Procesador (CPU)", T_CPU, cpx, cph, bzc + 2, 40, 40, 4, color(30, 100, 55)))
    .texto("El cerebro del equipo: " + m.cpu + ".",
    "Levanta la palanca del zócalo y abre el marco. Sácalo en vertical tomándolo por los bordes; no toques los contactos.")
    .tras("cooler").sensible();
  cpu.acostar = true;
  orden.add("cpu");

  float m2rx = itx ? 45 : 95, m2ry = itx ? 112 : (m.placa == 1 ? 215 : 264);
  Pieza m2 = e.agregar(new Pieza("m2", "Unidad SSD M.2", T_M2, bxL + m2rx, btop - m2ry, bzc + 1.5, 80, 22, 2.5, color(20)))
    .texto("Unidad NVMe (" + (m.disco.indexOf("NVMe") >= 0 ? m.disco : "SSD NVMe 256 GB") + "). Guarda el sistema operativo y los archivos.",
    "Quita su tornillo; se levanta en ángulo. Sácala en línea recta.")
    .tras("panel").sensible()
    .tornillos(0, 0, 1, bxL + m2rx + 42, btop - m2ry, bzc + 3);
  m2.acostar = true;
  if (m.gpu > 0 && !itx)
    m2.tras("panel", "gpu");
  orden.add("m2");

  float cmrx = itx ? 22 : 195, cmry = itx ? 22 : bhh - 20;
  Pieza cmos = e.agregar(new Pieza("cmos", "Pila CMOS", T_CMOS, bxL + cmrx, btop - cmry, bzc + 2, 20, 20, 3, color(195)))
    .texto("Pila CR2032: conserva fecha, hora y configuración del BIOS.", "Presiona el seguro metálico y la pila salta.")
    .tras("panel");
  cmos.acostar = true;
  orden.add("cmos");

  for (int i = 1; i <= m.discos; i++) {
    String id = i == 1 ? "hdd" : "hdd" + i;
    float hh = 40 + (i - 1) * 36, hx = x1 - 95;
    e.agregar(new Pieza(id, i == 1 ? "Disco duro de 3.5\"" : "Segundo disco de 3.5\"", T_HDD, hx, hh, 0, 147, 26, 102, color(195)))
      .texto("Disco mecánico. Más lento que un SSD pero con mucho espacio. Es sensible a golpes.",
      "Desconecta los cables SATA de datos y de energía y quita sus 2 tornillos. Deslízalo fuera de la bahía.")
      .tras("panel")
      .tornillos(0, 0, 1, hx - 40, hh, 52, hx + 40, hh, 52);
    orden.add(id);
  }
  if (m.optico) {
    float ox = x1 - 82, oh = H - 50;
    e.agregar(new Pieza("odd", "Unidad de DVD", T_OPTICO, ox, oh, 0, 148, 42, 146, color(40)))
      .texto("Lector y grabador de DVD en la bahía de 5.25\". Hoy casi no se usa, pero muchas PCs de oficina la traen.",
      "Desconecta sus cables SATA y quita sus 2 tornillos laterales. Sácala deslizándola hacia el frente.")
      .tras("panel")
      .tornillos(0, 0, 1, ox - 50, oh, 74, ox + 40, oh, 74);
    orden.add("odd");
  }
  e.agregar(new Pieza("fan_trasero", "Ventilador trasero", T_VENTILADOR, x0 + 15, btop - 55, -10, 22, 120, 120, color(28)))
    .texto("Ventilador de 120 mm que saca el aire caliente por la parte trasera.",
    "Desconecta su cable (SYS_FAN1) y quita los 4 tornillos desde atrás del gabinete.")
    .tras("panel")
    .tornillos(-1, 0, 0, x0, btop - 3, -62, x0, btop - 3, 42, x0, btop - 107, -62, x0, btop - 107, 42);
  orden.add("fan_trasero");
  for (int i = 0; i < m.ventFrontales; i++) {
    String id = i == 0 ? "fan_frontal" : "fan_frontal" + (i + 1);
    float fh = m.ventFrontales == 1 ? 250 : 150 + i * 130;
    e.agregar(new Pieza(id, m.ventFrontales == 1 ? "Ventilador frontal" : "Ventilador frontal " + (i + 1), T_VENTILADOR, x1 - 15, fh, -10, 22, 120, 120, color(28)))
      .texto("Ventilador de 120 mm que mete aire fresco por el frente.",
      "Desconecta su cable y quita los 4 tornillos desde el frente.")
      .tras("panel")
      .tornillos(1, 0, 0, x1, fh + 52, -62, x1, fh + 52, 42, x1, fh - 52, -62, x1, fh - 52, 42);
    orden.add(id);
  }
  float pw = m.sfx ? 125 : 160, pa = m.sfx ? 64 : 86, pd = m.sfx ? 100 : 150;
  float psx = x0 + 5 + pw / 2 + (m.sfx ? 0 : 0), psh = pa / 2 + 4.5, psz = -15;
  e.agregar(new Pieza("psu", m.sfx ? "Fuente de poder SFX" : "Fuente de poder", T_PSU, psx, psh, psz, pw, pa, pd, color(32)))
    .texto(m.sfx ? "Fuente SFX: más pequeña que una ATX, para gabinetes compactos. Convierte 127 V en 12 V, 5 V y 3.3 V."
    : "Convierte la corriente de la pared (127 V) en 12 V, 5 V y 3.3 V para los componentes.",
    "Desconecta el cable de corriente y TODOS sus cables. Quita los 4 tornillos traseros. Nunca abras la fuente: guarda carga peligrosa.")
    .tras("panel")
    .tornillos(-1, 0, 0, x0, psh - pa / 2 + 12, psz - pd / 2 + 10, x0, psh + pa / 2 - 10, psz - pd / 2 + 10, x0, psh - pa / 2 + 12, psz + pd / 2 - 10, x0, psh + pa / 2 - 10, psz + pd / 2 - 10);
  e.pieza("psu").variante = m.sfx ? 1 : 0;
  orden.add("psu");

  ArrayList<String> sobre = new ArrayList<String>();
  sobre.add("panel");
  for (Pieza p : e.piezas)
    if (p.tipo == T_GPU || p.tipo == T_RAM_DIMM || p.tipo == T_COOLER || p.tipo == T_CPU || p.tipo == T_M2 || p.tipo == T_CMOS || p.tipo == T_RADIADOR)
      sobre.add(p.id);
  float[] gx = itx ? new float[] {10, bw - 10} : new float[] {10, bw / 2, bw - 10};
  float[] gy = itx ? new float[] {10, bhh - 10} : new float[] {10, bhh / 2 - 7.5, bhh - 10};
  float[] ts = new float[gx.length * gy.length * 3];
  int k = 0;
  for (float a : gy)
    for (float b : gx) {
      ts[k++] = bxL + b;
      ts[k++] = btop - a;
      ts[k++] = bzc + 3;
    }
  Pieza placa = e.agregar(new Pieza("placa", "Placa madre", T_PLACA_ATX, pbx, pbh, bzc, bw, bhh, 6, color(32)))
    .texto("Tarjeta principal " + nombresPlaca[m.placa] + ". Une procesador, memoria, almacenamiento y fuente." + (m.gpu == 0 ? " En este equipo el video sale de su puerto trasero." : ""),
    "Retira primero todo lo montado en ella y desconecta todos sus cables. Quita sus " + (ts.length / 3) + " tornillos y sácala inclinándola.")
    .tras(sobre.toArray(new String[0])).sensible()
    .tornillos(0, 0, 1, ts);
  placa.acostar = true;
  placa.variante = m.placa;
  orden.add("placa");
  for (String id : sobre)
    if (!id.equals("panel") && !id.equals("cooler") && !id.equals("radiador"))
      e.base(id, "placa");
  e.base("cpu", "placa");
  e.base("cooler", "cpu");
  if (m.cooler == 2)
    e.base("radiador", "cooler");

  // ---- Cables ----
  Pieza psu = e.pieza("psu");
  float pTop = psu.h + psu.alto / 2;
  float chh = m.sfx ? psu.h : psu.h - 17.5, chz = m.sfx ? psu.z : psu.z + 45;
  e.agregar(new Conector("corriente", "Cable de corriente", x0 - 7, chh, chz, 10, 16, 26))
    .une("", "psu").salida(-1, 0, 0).tono(negro)
    .cable(negro, 6, x0 - 35, chh, chz, -m.W / 2 - 80, 0, 120, -m.W / 2 - 200, 0, 300)
    .texto("Desconéctalo SIEMPRE antes de abrir el equipo y apaga el interruptor de la fuente.");
  float ax = bxL + bw - 7, ah = btop - (itx ? 60 : 95);
  e.agregar(new Conector("atx24", "Cable de 24 pines (placa)", ax, ah, bzc + 7, 8, 50, 10))
    .une("psu", "placa").tras("panel").salida(0, 0, 1).tono(negro)
    .cable(negro, 10, ax + 18, ah, bzc + 29, ax + 30, pTop + 60, -50, psu.x + 40, pTop + 10, -40);
  float ex = bxL + 25, eh = btop - 7;
  e.agregar(new Conector("eps8", "Cable de CPU de 8 pines", ex, eh, bzc + 6, 16, 8, 10))
    .une("psu", "placa").tras("panel").salida(0, 0, 1).tono(negro)
    .cable(negro, 6, ex, eh + 22, bzc + 19, x0 + 20, eh + 22, -40, x0 + 20, pTop + 40, -60, psu.x + 20, pTop + 10, -40);
  Pieza gpu = e.pieza("gpu");
  if (gpu != null) {
    float qx = gpu.x + gpu.w / 2 - 45;
    e.agregar(new Conector("pcie", "Cable de energía PCIe (gráfica)", qx, gpu.h, gpu.z + 57, 20, 8, 6))
      .une("psu", "gpu").tras("panel").salida(0, 0, 1).tono(negro)
      .cable(negro, 6, qx, gpu.h - 5, gpu.z + 73, qx - 10, pTop + 40, 40, psu.x + 60, pTop + 10, 30);
    e.agregar(new Conector("video", "Cable de video (DisplayPort)", x0 - 4, gpu.h - 10, gpu.z + 3, 8, 10, 14))
      .une("", "gpu").salida(-1, 0, 0).tono(negro)
      .cable(negro, 4, x0 - 25, gpu.h - 10, gpu.z + 3, x0 - 35, 0, -150, 300, 0, -330, 470, 60, -260)
      .texto("Va de la tarjeta gráfica al monitor. Si lo conectas a la placa, no habrá imagen.");
  } else {
    float vh = btop - 70;
    e.agregar(new Conector("video", "Cable de video (HDMI de la placa)", x0 - 4, vh, bzc + 30, 8, 10, 16))
      .une("", "placa").salida(-1, 0, 0).tono(negro)
      .cable(negro, 4, x0 - 25, vh, bzc + 30, x0 - 35, 0, -150, 300, 0, -330, 470, 60, -260)
      .texto("Este equipo no tiene tarjeta gráfica: el monitor se conecta al puerto de video de la placa.");
  }
  e.agregar(new Conector("cpu_fan", m.cooler == 2 ? "Cable de la bomba (CPU_FAN)" : "Cable del ventilador del CPU (CPU_FAN)", bxL + (itx ? 120 : 155), btop - 5, bzc + 5, 8, 4, 5))
    .une("cooler", "placa").tras("panel").salida(0, 0, 1).tono(color(240))
    .cable(color(30), 2, cpx - 20, cph + 40, bzc + 40, bxL + (itx ? 120 : 155), btop - 20, bzc + 15);
  if (m.cooler == 2) {
    Pieza rad = e.pieza("radiador");
    e.agregar(new Conector("rad_fan", "Cable de los ventiladores del radiador", bxL + 135, btop - 5, bzc + 5, 8, 4, 5))
      .une("radiador", "placa").tras("panel").salida(0, 0, 1).tono(color(240))
      .cable(color(30), 2, rad.x - 100, rad.h - 30, -40, bxL + 135, btop - 15, bzc + 15);
  }
  Pieza ft = e.pieza("fan_trasero");
  e.agregar(new Conector("sys_fan1", "Cable del ventilador trasero (SYS_FAN1)", bxL + 65, btop - 1, bzc + 5, 8, 4, 5))
    .une("fan_trasero", "placa").tras("panel").salida(0, 0, 1).tono(color(240))
    .cable(color(30), 2, ft.x + 10, ft.h + 40, -40, ft.x + 15, ft.h + 20, -20);
  for (int i = 0; i < m.ventFrontales; i++) {
    String id = i == 0 ? "fan_frontal" : "fan_frontal" + (i + 1);
    Pieza f = e.pieza(id);
    float hx = bxL + 175 - i * 22, hh = btop - bhh + 21;
    e.agregar(new Conector("sys_fan" + (i + 2), "Cable del ventilador frontal" + (m.ventFrontales > 1 ? " " + (i + 1) : "") + " (SYS_FAN" + (i + 2) + ")", hx, hh, bzc + 5, 8, 4, 5))
      .une(id, "placa").tras("panel").salida(0, 0, 1).tono(color(240))
      .cable(color(30), 2, hx, hh + 19, bzc + 29, f.x - 30, f.h - 20, -60, f.x - 5, f.h - 20, -40);
  }
  float pfx = bxL + (itx ? 150 : 210), pfh = btop - bhh + 4;
  e.agregar(new Conector("panel_frontal", "Conectores del panel frontal", pfx, pfh, bzc + 5, 16, 6, 8))
    .une("", "placa").tras("panel").salida(0, 0, 1).tono(color(30))
    .cable(color(200, 60, 60), 2, pfx + 30, pfh - 10, -60, x1 - 10, pfh, -60);
  for (int i = 1; i <= m.discos; i++) {
    String id = i == 1 ? "hdd" : "hdd" + i;
    String suf = i == 1 ? "" : "" + i;
    Pieza hd = e.pieza(id);
    float sx = hd.x - 78;
    e.agregar(new Conector("sata" + suf + "_datos", "Cable SATA de datos" + (i > 1 ? " (disco 2)" : ""), sx, hd.h + 6, -22, 6, 6, 10))
      .une("placa", id).tras("panel").salida(-1, 0, 0).tono(color(200, 40, 40))
      .cable(color(200, 40, 40), 3, sx - 22, hd.h + 20, -40, bxL + bw - 20, btop - bhh + 30, -80);
    e.agregar(new Conector("sata" + suf + "_energia", "Cable SATA de energía" + (i > 1 ? " (disco 2)" : ""), sx, hd.h - 4, 22, 6, 6, 14))
      .une("psu", id).tras("panel").salida(-1, 0, 0).tono(negro)
      .cable(negro, 4, sx - 22, hd.h - 4, 30, psu.x + 85, pTop + 12, 40);
  }
  if (m.optico) {
    Pieza od = e.pieza("odd");
    float sx = od.x - 76;
    e.agregar(new Conector("sata_odd_datos", "Cable SATA de datos (DVD)", sx, od.h + 8, -30, 6, 6, 10))
      .une("placa", "odd").tras("panel").salida(-1, 0, 0).tono(color(200, 40, 40))
      .cable(color(200, 40, 40), 3, sx - 20, od.h + 8, -50, bxL + bw - 20, btop - bhh + 40, -80);
    e.agregar(new Conector("sata_odd_energia", "Cable SATA de energía (DVD)", sx, od.h - 8, 30, 6, 6, 14))
      .une("psu", "odd").tras("panel").salida(-1, 0, 0).tono(negro)
      .cable(negro, 4, sx - 20, od.h - 8, 40, x1 - 180, pTop + 60, 40, psu.x + 85, pTop + 12, 40);
  }

  e.orden = orden.toArray(new String[0]);
  acomodarBandeja(e);
  return e;
}

// ---- Lugar de cada pieza en la mesa ----
// acomodarBandeja(e) · Reparte los lugares de la mesa por filas para las piezas retiradas
void acomodarBandeja(Equipo e) {
  Modelo m = e.modelo;
  float mesaX = 870, z0 = -440, z1 = 440;
  float ew = m.W / 2 + 45, ed = m.D / 2 + 45;
  ArrayList<float[]> zonas = new ArrayList<float[]>();
  if (e.laptop) {
    zonas.add(new float[] {ew, z0 + 120, mesaX, z1, 0});
    zonas.add(new float[] {-mesaX, -175, -ew, z1, 0});
    zonas.add(new float[] {-ew, ed, ew, z1, 0});
  } else {
    zonas.add(new float[] {-mesaX, z0, -ew, z1, 1});
    zonas.add(new float[] {-ew, ed, mesaX, z1, 0});
    zonas.add(new float[] {ew, -120, mesaX, ed, 1});
    zonas.add(new float[] {-ew, z0, 250, -ed, 0});
  }
  ArrayList<Pieza> lista = new ArrayList<Pieza>();
  for (Pieza p : e.piezas)
    if (p.removible)
      lista.add(p);
  for (int i = 0; i < lista.size(); i++)
    for (int j = i + 1; j < lista.size(); j++) {
      float[] a = lista.get(i).tamBandeja(), b = lista.get(j).tamBandeja();
      if (b[0] * b[2] > a[0] * a[2]) {
        Pieza t = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, t);
      }
    }
  float sep = 22;
  float[][] cursor = new float[zonas.size()][3];
  for (int i = 0; i < zonas.size(); i++)
    cursor[i] = new float[] {zonas.get(i)[0] + sep, zonas.get(i)[1] + sep, 0};
  for (Pieza p : lista) {
    float[] s = p.tamBandeja();
    float w = s[0] + sep, d = s[2] + sep;
    boolean puesta = false;
    for (int i = 0; i < zonas.size() && !puesta; i++) {
      float[] zn = zonas.get(i), c = cursor[i];
      if (zn[4] > 0 && s[1] > 30)
        continue;
      if (c[0] + w > zn[2]) {
        c[0] = zn[0] + sep;
        c[1] += c[2];
        c[2] = 0;
      }
      if (c[0] + w <= zn[2] + 0.1 && c[1] + d <= zn[3] + 0.1) {
        p.bx = c[0] + s[0] / 2;
        p.bz = c[1] + s[2] / 2;
        c[0] += w;
        c[2] = max(c[2], d);
        puesta = true;
      }
    }
    if (!puesta) {
      p.bx = mesaX - s[0] / 2;
      p.bz = z1 - s[2] / 2;
    }
  }
}
