// ============================================================
// LUCES RGB · barra trasera, emblema, tira frontal, luces de la tapa y retroiluminación
// ============================================================

// ---- Modos y estado ----
final static int L_OLA = 0, L_RESPIRA = 1, L_COMETA = 2, L_TEMPERATURA = 3, L_APAGADA = 4;
String[] NOMBRES_LUZ = {"Ola arcoíris", "Respiración", "Cometa", "Temperatura", "Apagada"};
int modoLuz = L_OLA;
final static int SEGMENTOS = 30;
PMatrix3D matVista;

// @guardarVista() · Guarda la matriz de la cámara para restaurar las luces después de noLights()
void guardarVista() {
  matVista = (PMatrix3D) getMatrix();
}

// @restaurarLuces() · Vuelve a poner las luces con la matriz de la cámara (no hace nada en la pasada de sombra)
void restaurarLuces() {
  if (modoSombra)
    return;
  pushMatrix();
  setMatrix(matVista);
  luces();
  popMatrix();
}

// @sinLuces() · noLights() y quita el shader RTX: para pantallas, LEDs, sombras e interfaz
void sinLuces() {
  noLights();
  sinRTX();
}

// cambiarModoLuz() · Cambia el efecto RGB (tecla L)
void cambiarModoLuz() {
  modoLuz = (modoLuz + 1) % NOMBRES_LUZ.length;
  avisar("Iluminación: " + NOMBRES_LUZ[modoLuz], INFO);
}

// actualizarLuces(e) · Brillo de los LEDs: suben al encender y bajan al apagar
void actualizarLuces(Equipo e) {
  boolean activo = e.encendido || e.demoLuces;
  if (activo && !e.ledActivo)
    e.inicioLed = frameCount;
  e.ledActivo = activo;
  e.brilloLed = lerp(e.brilloLed, activo ? 1 : 0, 0.08);
}

// @colorLed(e, i, n, anillo) · Color de cada LED según el efecto (con barrido blanco al encender)
color colorLed(Equipo e, int i, int n, boolean anillo) {
  float t = frameCount / 60.0;
  float k = e.brilloLed;
  color c;
  int modo = modoLuz;
  switch (modo) {
  case L_OLA: {
    float h = ((i / (float) n) + t * 0.25) % 1;
    c = java.awt.Color.HSBtoRGB(h, 0.85, 1);
    break;
  }
  case L_RESPIRA: {
    float r = (sin(t * 2.2) + 1) / 2;
    c = lerpColor(color(0, 25, 40), color(40, 210, 255), 0.15 + 0.85 * r * r);
    break;
  }
  case L_COMETA: {
    float p = anillo ? (t * 9) % n : (sin(t * 1.7) + 1) / 2 * (n - 1);
    float dd = abs(i - p);
    if (anillo)
      dd = min(dd, n - dd);
    float f = exp(-dd * 0.45);
    c = lerpColor(color(10, 0, 18), color(255, 60, 170), f);
    break;
  }
  case L_TEMPERATURA: {
    float temp = constrain((monitor.temp - 30) / 55.0, 0, 1);
    color frio = color(40, 130, 255), tibio = color(255, 190, 40), caliente = color(255, 40, 30);
    c = temp < 0.5 ? lerpColor(frio, tibio, temp * 2) : lerpColor(tibio, caliente, (temp - 0.5) * 2);
    float pulso = 0.75 + 0.25 * sin(t * (2 + temp * 8) + i * 0.15);
    c = lerpColor(color(0), c, pulso);
    break;
  }
  default:
    c = color(0);
  }
  float tb = (frameCount - e.inicioLed) / 70.0;
  if (tb < 1.6 && e.ledActivo) {
    float pos = anillo ? i / (float) n : abs(i - (n - 1) / 2.0) / ((n - 1) / 2.0);
    if (tb < 1)
      c = lerpColor(color(0), color(255), constrain(tb * 1.4 - pos, 0, 1));
    else
      c = lerpColor(c, color(255), 1 - (tb - 1) / 0.6);
  }
  return lerpColor(color(0), c, k);
}

// promedio(cs) · Color promedio de una lista
color promedio(color[] cs) {
  float r = 0, g = 0, b = 0;
  for (color c : cs) {
    r += red(c);
    g += green(c);
    b += blue(c);
  }
  return color(r / cs.length, g / cs.length, b / cs.length);
}

// ---- Brillo aditivo ----
// empezarBrillo() · Prepara el brillo aditivo: sin luces, sin escribir profundidad, blendMode(ADD)
void empezarBrillo() {
  sinLuces();
  noStroke();
  hint(DISABLE_DEPTH_MASK);
  blendMode(ADD);
  textureMode(NORMAL);
}

// terminarBrillo() · Regresa a la mezcla normal y restaura las luces
void terminarBrillo() {
  blendMode(BLEND);
  hint(ENABLE_DEPTH_MASK);
  noTint();
  restaurarLuces();
}

// halo(x, h, z, w, l, plano, c, fuerza) · Resplandor suave con textura sobre un plano
void halo(float x, float h, float z, float w, float l, int plano, color c, float fuerza) {
  tint(red(c) * fuerza, green(c) * fuerza, blue(c) * fuerza);
  beginShape(QUADS);
  texture(texBrillo);
  if (plano == 0) {
    vertex(x - w / 2, -h - l / 2, z, 0, 0);
    vertex(x + w / 2, -h - l / 2, z, 1, 0);
    vertex(x + w / 2, -h + l / 2, z, 1, 1);
    vertex(x - w / 2, -h + l / 2, z, 0, 1);
  } else {
    vertex(x - w / 2, -h, z - l / 2, 0, 0);
    vertex(x + w / 2, -h, z - l / 2, 1, 0);
    vertex(x + w / 2, -h, z + l / 2, 1, 1);
    vertex(x - w / 2, -h, z + l / 2, 0, 1);
  }
  endShape();
}

// ---- Luces de cada laptop ----
// dibujarBarraTrasera(e) · Barra de LEDs trasera de la laptop Vórtice
void dibujarBarraTrasera(Equipo e) {
  Modelo m = e.modelo;
  float zr = -m.D / 2, hb = m.H * 0.23;
  color[] cs = new color[SEGMENTOS];
  for (int i = 0; i < SEGMENTOS; i++)
    cs[i] = colorLed(e, i, SEGMENTOS, false);
  float ancho = m.W * 0.66, x0 = -ancho / 2, paso = ancho / SEGMENTOS;
  noStroke();
  c(0, hb, zr - 0.3, ancho + 4, 3.2, 0.8, color(28, 30, 34));
  if (e.brilloLed < 0.02)
    return;
  if (modoSombra)
    return;
  empezarBrillo();
  for (int i = 0; i < SEGMENTOS; i++) {
    fill(cs[i]);
    c(x0 + paso * (i + 0.5), hb, zr - 0.75, paso - 0.25, 2.2, 0.2);
  }
  for (int i = 0; i < SEGMENTOS; i++)
    halo(x0 + paso * (i + 0.5), hb, zr - 1.2, paso * 3.2, 14, 0, cs[i], 0.55);
  if (e.volteo > 0.95 && e.enUso)
    for (int g = 0; g < 6; g++) {
      color[] grupo = new color[5];
      for (int j = 0; j < 5; j++)
        grupo[j] = cs[g * 5 + j];
      halo(x0 + paso * (g * 5 + 2.5), 1.45, zr - 33, paso * 9, 90, 1, promedio(grupo), 0.45 * e.brilloLed);
    }
  terminarBrillo();
}

// dibujarTiraFrontal(e) · Tira de LEDs frontal de la laptop Titán
void dibujarTiraFrontal(Equipo e) {
  Modelo m = e.modelo;
  int n = 36;
  float ancho = m.W - 70, x0 = -ancho / 2, paso = ancho / n, zf = m.D / 2, hb = m.H * 0.3;
  noStroke();
  c(0, hb, zf + 0.3, ancho + 4, 2.4, 0.6, color(22));
  if (e.brilloLed < 0.02 || modoLuz == L_APAGADA)
    return;
  if (modoSombra)
    return;
  empezarBrillo();
  color[] cs = new color[n];
  for (int i = 0; i < n; i++) {
    cs[i] = colorLed(e, i, n, false);
    fill(cs[i]);
    c(x0 + paso * (i + 0.5), hb, zf + 0.7, paso - 0.2, 1.6, 0.2);
  }
  for (int i = 0; i < n; i += 2)
    halo(x0 + paso * (i + 1), hb, zf + 1.1, paso * 4, 10, 0, cs[i], 0.5);
  if (e.volteo > 0.95 && e.enUso)
    for (int g = 0; g < 6; g++)
      halo(x0 + paso * (g * 6 + 3), 1.45, zf + 26, paso * 9, 60, 1, cs[g * 6 + 3], 0.4 * e.brilloLed);
  terminarBrillo();
}

// dibujarLucesTapaTitan(e) · Franjas de luz en la tapa de la Titán
void dibujarLucesTapaTitan(Equipo e) {
  Modelo m = e.modelo;
  float W = m.W, D = m.D, h = m.tapaGrosor + 0.1;
  int n = 14;
  noStroke();
  if (e.brilloLed < 0.02 || modoLuz == L_APAGADA)
    return;
  if (modoSombra)
    return;
  empezarBrillo();
  for (int s = -1; s <= 1; s += 2) {
    float xa = s * (W / 2 - 34 * W / 1024), za = 6, xb = s * 40 * W / 1024, zb = D - 46 * D / 704;
    for (int i = 0; i < n; i++) {
      float t0 = i / (float) n, t1 = (i + 0.85) / n;
      color col = colorLed(e, s < 0 ? i : n - 1 - i + n, 2 * n, false);
      fill(col);
      float nx = (zb - za), nz = -(xb - xa), l = sqrt(nx * nx + nz * nz);
      nx = nx / l * 1.4;
      nz = nz / l * 1.4;
      float ax = lerp(xa, xb, t0), az = lerp(za, zb, t0), bx = lerp(xa, xb, t1), bz = lerp(za, zb, t1);
      beginShape(QUADS);
      vertex(ax - nx, -h, az - nz);
      vertex(bx - nx, -h, bz - nz);
      vertex(bx + nx, -h, bz + nz);
      vertex(ax + nx, -h, az + nz);
      endShape();
      if (i % 2 == 0)
        halo((ax + bx) / 2, h + 0.05, (az + bz) / 2, 26, 26, 1, col, 0.45);
    }
  }
  terminarBrillo();
}

// dibujarEmblema(e) · Emblema hexagonal iluminado de la tapa
void dibujarEmblema(Equipo e) {
  int n = 18;
  float r0 = 20, r1 = 25, h = e.modelo.tapaGrosor + 0.12, cz = e.modelo.D / 2;
  noStroke();
  fill(32, 34, 38);
  beginShape(QUADS);
  for (int i = 0; i < 6; i++)
    cuadEmblema(i / 6.0, (i + 1) / 6.0, r0 - 1, r1 + 1, h - 0.02, cz);
  endShape();
  if (e.brilloLed < 0.02)
    return;
  if (modoSombra)
    return;
  empezarBrillo();
  color[] cs = new color[n];
  for (int i = 0; i < n; i++) {
    cs[i] = colorLed(e, i, n, true);
    fill(cs[i]);
    beginShape(QUADS);
    cuadEmblema((i + 0.08) / n, (i + 0.92) / n, r0, r1, h + 0.05, cz);
    endShape();
  }
  fill(lerpColor(color(0), color(235), e.brilloLed));
  beginShape(TRIANGLES);
  vertex(0, -h - 0.06, cz - 9);
  vertex(8, -h - 0.06, cz + 6);
  vertex(-8, -h - 0.06, cz + 6);
  endShape();
  halo(0, h + 0.1, cz, 110, 110, 1, promedio(cs), 0.5 * e.brilloLed);
  terminarBrillo();
}

// cuadEmblema(a, b, r0, r1, h, cz) · Un tramo del anillo hexagonal
void cuadEmblema(float a, float b, float r0, float r1, float h, float cz) {
  float[] p0 = puntoHex(a, r0), p1 = puntoHex(b, r0), q1 = puntoHex(b, r1), q0 = puntoHex(a, r1);
  vertex(p0[0], -h, cz + p0[1]);
  vertex(p1[0], -h, cz + p1[1]);
  vertex(q1[0], -h, cz + q1[1]);
  vertex(q0[0], -h, cz + q0[1]);
}

// puntoHex(f, r) · Punto sobre un hexágono (f de 0 a 1)
float[] puntoHex(float f, float r) {
  f = ((f % 1) + 1) % 1;
  int lado = int(f * 6);
  float t = f * 6 - lado;
  float a0 = TWO_PI * lado / 6 - HALF_PI, a1 = TWO_PI * (lado + 1) / 6 - HALF_PI;
  return new float[] {lerp(cos(a0), cos(a1), t) * r, lerp(sin(a0), sin(a1), t) * r};
}

// dibujarRetroiluminacion(e) · Retroiluminación del teclado: RGB o blanca
void dibujarRetroiluminacion(Equipo e) {
  Modelo m = e.modelo;
  boolean rgb = m.rgb && modoLuz != L_APAGADA;
  if (!(e.encendido || e.demoLuces && m.rgb) || e.brilloLed < 0.02 || (m.rgb && modoLuz == L_APAGADA))
    return;
  MT = m;
  float xa = 100000, xb = -100000, za = 100000, zb = -100000;
  for (float[] t : m.teclas) {
    xa = min(xa, t[0] - 3);
    xb = max(xb, t[2] + 3);
    za = min(za, t[1] - 3);
    zb = max(zb, t[3] + 3);
  }
  float hk = m.H + (m.estilo == 1 ? 0.95 : 1.35);
  if (modoSombra)
    return;
  empezarBrillo();
  int tiras = 12;
  for (int s = 0; s < tiras; s++) {
    float x0 = lerp(xa, xb, s / (float) tiras), x1 = lerp(xa, xb, (s + 1) / (float) tiras);
    color c = rgb ? lerpColor(colorLed(e, round(s * (SEGMENTOS - 1) / (float) (tiras - 1)), SEGMENTOS, false), color(255), 0.35) : color(235, 240, 255);
    float k = rgb ? 0.8 : 0.55 * e.brilloLed;
    tint(red(c) * k, green(c) * k, blue(c) * k);
    beginShape(QUADS);
    texture(m.texLeyendas);
    vertex(x0, -hk, za, txX(x0) / 1024, txZ(za) / 704);
    vertex(x1, -hk, za, txX(x1) / 1024, txZ(za) / 704);
    vertex(x1, -hk, zb, txX(x1) / 1024, txZ(zb) / 704);
    vertex(x0, -hk, zb, txX(x0) / 1024, txZ(zb) / 704);
    endShape();
  }
  terminarBrillo();
}
