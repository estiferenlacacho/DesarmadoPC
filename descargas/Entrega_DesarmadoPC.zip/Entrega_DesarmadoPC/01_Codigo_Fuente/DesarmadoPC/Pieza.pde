// ============================================================
// PIEZAS · Tornillo, Conector y Pieza (mm: x derecha, h arriba, z hacia el usuario)
// ============================================================

// ---- Herramientas ----
final static int MANO = 0;
final static int DESTORNILLADOR = 1;
final static int PUA = 2;
final static int PASTA = 3;

// ---- Tornillo ----
// class Tornillo · Posición, dirección y si está puesto
class Tornillo {
  float x, h, z, nx, nh, nz;
  boolean puesto = true;
  float anim = 0;
  boolean grande = false;

  Tornillo(float x, float h, float z, float nx, float nh, float nz) {
    this.x = x;
    this.h = h;
    this.z = z;
    this.nx = nx;
    this.nh = nh;
    this.nz = nz;
  }
}

// ---- Conector: enchufe y su cable ----
// class Conector · Enchufe que une dos piezas y el recorrido de su cable
class Conector {
  String id, nombre, info;
  float x, h, z, w, alto, d;
  float nx, nh, nz;
  String duenio = "", destino = "";
  String[] requiere = {};
  boolean conectado = true;
  color col = color(30);
  float[] cable = {};
  color colCable = color(40);
  float grosor = 3;

  Conector(String id, String nombre, float x, float h, float z, float w, float alto, float d) {
    this.id = id;
    this.nombre = nombre;
    this.x = x;
    this.h = h;
    this.z = z;
    this.w = w;
    this.alto = alto;
    this.d = d;
    nh = 1;
  }

  // salida(nx, nh, nz) · Dirección en la que sale el enchufe
  Conector salida(float nx, float nh, float nz) {
    this.nx = nx;
    this.nh = nh;
    this.nz = nz;
    return this;
  }
  // une(duenio, destino) · Piezas que conecta
  Conector une(String duenio, String destino) {
    this.duenio = duenio;
    this.destino = destino;
    return this;
  }
  // tras(r...) · Piezas que hay que quitar antes
  Conector tras(String... r) {
    requiere = r;
    return this;
  }
  // cable(c, g, pts...) · Color, grosor y puntos del cable
  Conector cable(color c, float g, float... pts) {
    colCable = c;
    grosor = g;
    cable = pts;
    return this;
  }
  // texto(t) · Descripción del conector
  Conector texto(String t) {
    info = t;
    return this;
  }
  // tono(c) · Color del enchufe
  Conector tono(color c) {
    col = c;
    return this;
  }

  // separacion() · Cuánto se separa el enchufe al desconectarlo
  float separacion() {
    return conectado ? 0 : 9;
  }
}

// ---- Pieza ----
// @class Pieza · Componente del equipo: tamaño, tornillos, dependencias, herramienta y animación
class Pieza {
  String id, nombre, info, comoQuitar;
  int tipo;
  float x, h, z, w, alto, d;
  color col;
  String[] requiere = {};
  boolean removible = true, sensible = false;
  int herramienta = MANO;
  ArrayList<Tornillo> tornillos = new ArrayList<Tornillo>();
  boolean instalada = true;
  float anim = 1;
  boolean haciaBandeja = false;
  float bx, bz;
  boolean acostar = false;
  boolean deLado = false;
  int variante = 0;
  float sx, sh, sz;

  Pieza(String id, String nombre, int tipo, float x, float h, float z, float w, float alto, float d, color col) {
    this.id = id;
    this.nombre = nombre;
    this.tipo = tipo;
    this.x = x;
    this.h = h;
    this.z = z;
    this.w = w;
    this.alto = alto;
    this.d = d;
    this.col = col;
  }

  // tras(r...) · Piezas que hay que quitar antes
  Pieza tras(String... r) {
    requiere = r;
    return this;
  }
  // texto(info, como) · Descripción y cómo se quita
  Pieza texto(String info, String como) {
    this.info = info;
    this.comoQuitar = como;
    return this;
  }
  // bandeja(bx, bz) · Lugar en la mesa
  Pieza bandeja(float bx, float bz) {
    this.bx = bx;
    this.bz = bz;
    return this;
  }
  // sensible() · Marca la pieza como sensible a la estática
  Pieza sensible() {
    sensible = true;
    return this;
  }
  // fija() · Marca la pieza como no removible
  Pieza fija() {
    removible = false;
    return this;
  }
  // con(herramienta) · Herramienta que necesita
  Pieza con(int herramienta) {
    this.herramienta = herramienta;
    return this;
  }
  // tornillos(nx, nh, nz, p...) · Agrega tornillos con su dirección
  Pieza tornillos(float nx, float nh, float nz, float... p) {
    for (int i = 0; i + 2 < p.length; i += 3)
      tornillos.add(new Tornillo(p[i], p[i + 1], p[i + 2], nx, nh, nz));
    return this;
  }

  // tornillosPuestos() · Cuántos tornillos quedan puestos
  int tornillosPuestos() {
    int n = 0;
    for (Tornillo t : tornillos)
      if (t.puesto)
        n++;
    return n;
  }

  // enReposo() · true si terminó su animación
  boolean enReposo() {
    return anim >= 1;
  }

  // tamBandeja() · Tamaño que ocupa en la mesa según cómo se apoya
  float[] tamBandeja() {
    if (acostar)
      return new float[] {w, d, alto};
    if (deLado)
      return new float[] {alto, w, d};
    return new float[] {w, alto, d};
  }
}
